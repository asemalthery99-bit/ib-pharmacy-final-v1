import { z } from "zod";

/**
 * Comprehensive Zod Validation Schemas
 * Used for both client and server validation
 */

// ============ USER VALIDATION ============
export const userSchema = z.object({
  id: z.number(),
  openId: z.string(),
  name: z.string().nullable().optional(),
  email: z.string().email().nullable().optional(),
  role: z.enum(["user", "admin"]),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export const createUserSchema = z.object({
  name: z.string().min(2, "الاسم يجب أن يكون على الأقل حرفين"),
  email: z.string().email("البريد الإلكتروني غير صحيح"),
  password: z.string().min(8, "كلمة المرور يجب أن تكون على الأقل 8 أحرف"),
});

// ============ MEDICINE VALIDATION ============
export const medicineSchema = z.object({
  id: z.number(),
  name: z.string(),
  arabicName: z.string(),
  category: z.string(),
  price: z.number().positive("السعر يجب أن يكون موجب"),
  description: z.string().nullable().optional(),
  arabicDescription: z.string().nullable().optional(),
  dosage: z.string().nullable().optional(),
  imageUrl: z.string().url().nullable().optional(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export const createMedicineSchema = z.object({
  name: z.string().min(2, "اسم الدواء يجب أن يكون على الأقل حرفين"),
  arabicName: z.string().min(2, "الاسم العربي يجب أن يكون على الأقل حرفين"),
  category: z.string().min(1, "يجب اختيار فئة"),
  price: z.number().positive("السعر يجب أن يكون موجب"),
  description: z.string().optional(),
  arabicDescription: z.string().optional(),
  dosage: z.string().optional(),
  sideEffects: z.string().optional(),
  arabicSideEffects: z.string().optional(),
  usage: z.string().optional(),
  arabicUsage: z.string().optional(),
  imageUrl: z.string().url().optional(),
});

// ============ ORDER VALIDATION ============
export const orderSchema = z.object({
  id: z.number(),
  userId: z.number(),
  totalPrice: z.number().positive(),
  status: z.enum(["pending", "preparing", "ready", "completed", "cancelled"]),
  paymentStatus: z.enum(["unpaid", "paid", "failed"]),
  notes: z.string().nullable().optional(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export const createOrderSchema = z.object({
  items: z.array(z.object({
    medicineId: z.number().positive("معرف الدواء غير صحيح"),
    quantity: z.number().positive("الكمية يجب أن تكون موجبة"),
  })).min(1, "يجب أن يكون هناك على الأقل منتج واحد"),
  notes: z.string().max(500, "الملاحظات يجب ألا تتجاوز 500 حرف").optional(),
});

export const updateOrderStatusSchema = z.object({
  id: z.number(),
  status: z.enum(["pending", "preparing", "ready", "completed", "cancelled"]),
  notes: z.string().optional(),
});

// ============ PRESCRIPTION VALIDATION ============
export const prescriptionSchema = z.object({
  id: z.number(),
  userId: z.number(),
  status: z.enum(["pending", "reviewed", "quoted", "completed", "rejected"]),
  userNotes: z.string().nullable().optional(),
  pharmacistNotes: z.string().nullable().optional(),
  quotedPrice: z.number().nullable().optional(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export const createPrescriptionSchema = z.object({
  imageUrl: z.string().url("رابط الصورة غير صحيح"),
  userNotes: z.string().max(500, "الملاحظات يجب ألا تتجاوز 500 حرف").optional(),
});

export const reviewPrescriptionSchema = z.object({
  prescriptionId: z.number(),
  status: z.enum(["reviewed", "quoted", "rejected"]),
  pharmacistNotes: z.string().max(1000, "الملاحظات يجب ألا تتجاوز 1000 حرف").optional(),
  quotedPrice: z.number().positive("السعر يجب أن يكون موجب").optional(),
  quotedMedicines: z.array(z.string()).optional(),
});

// ============ CART VALIDATION ============
export const cartItemSchema = z.object({
  medicineId: z.number().positive("معرف الدواء غير صحيح"),
  quantity: z.number().positive("الكمية يجب أن تكون موجبة").int("الكمية يجب أن تكون رقم صحيح"),
});

export const addToCartSchema = z.object({
  medicineId: z.number().positive("معرف الدواء غير صحيح"),
  quantity: z.number().positive("الكمية يجب أن تكون موجبة").int("الكمية يجب أن تكون رقم صحيح"),
});

export const updateCartItemSchema = z.object({
  medicineId: z.number().positive("معرف الدواء غير صحيح"),
  quantity: z.number().nonnegative("الكمية يجب أن تكون موجبة أو صفر").int("الكمية يجب أن تكون رقم صحيح"),
});

// ============ RATING VALIDATION ============
export const rateMedicineSchema = z.object({
  medicineId: z.number().positive("معرف الدواء غير صحيح"),
  rating: z.number().min(1, "التقييم يجب أن يكون على الأقل 1").max(5, "التقييم يجب ألا يتجاوز 5"),
  review: z.string().max(500, "التعليق يجب ألا يتجاوز 500 حرف").optional(),
  title: z.string().max(100, "العنوان يجب ألا يتجاوز 100 حرف").optional(),
});

export const rateServiceSchema = z.object({
  orderId: z.number().positive("معرف الطلب غير صحيح"),
  rating: z.number().min(1).max(5),
  review: z.string().max(500).optional(),
  deliveryRating: z.number().min(1).max(5).optional(),
  pharmacistRating: z.number().min(1).max(5).optional(),
});

// ============ PAYMENT VALIDATION ============
export const paymentSchema = z.object({
  orderId: z.number().positive("معرف الطلب غير صحيح"),
  amount: z.number().positive("المبلغ يجب أن يكون موجب"),
  paymentMethod: z.enum(["stripe", "paypal", "cash"]),
});

// ============ INVENTORY VALIDATION ============
export const updateInventorySchema = z.object({
  medicineId: z.number().positive("معرف الدواء غير صحيح"),
  quantity: z.number().nonnegative("الكمية يجب أن تكون موجبة أو صفر").int("الكمية يجب أن تكون رقم صحيح"),
});

// ============ SEARCH VALIDATION ============
export const searchMedicinesSchema = z.object({
  query: z.string().min(1, "يجب إدخال كلمة البحث").max(100),
  category: z.string().optional(),
  minPrice: z.number().nonnegative().optional(),
  maxPrice: z.number().nonnegative().optional(),
  limit: z.number().positive().default(20),
  offset: z.number().nonnegative().default(0),
});

// ============ PAGINATION VALIDATION ============
export const paginationSchema = z.object({
  limit: z.number().positive().default(20),
  offset: z.number().nonnegative().default(0),
});

// Type exports for TypeScript
export type User = z.infer<typeof userSchema>;
export type CreateUser = z.infer<typeof createUserSchema>;
export type Medicine = z.infer<typeof medicineSchema>;
export type CreateMedicine = z.infer<typeof createMedicineSchema>;
export type Order = z.infer<typeof orderSchema>;
export type CreateOrder = z.infer<typeof createOrderSchema>;
export type UpdateOrderStatus = z.infer<typeof updateOrderStatusSchema>;
export type Prescription = z.infer<typeof prescriptionSchema>;
export type CreatePrescription = z.infer<typeof createPrescriptionSchema>;
export type ReviewPrescription = z.infer<typeof reviewPrescriptionSchema>;
export type CartItem = z.infer<typeof cartItemSchema>;
export type AddToCart = z.infer<typeof addToCartSchema>;
export type UpdateCartItem = z.infer<typeof updateCartItemSchema>;
export type RateMedicine = z.infer<typeof rateMedicineSchema>;
export type RateService = z.infer<typeof rateServiceSchema>;
export type Payment = z.infer<typeof paymentSchema>;
export type UpdateInventory = z.infer<typeof updateInventorySchema>;
export type SearchMedicines = z.infer<typeof searchMedicinesSchema>;
export type Pagination = z.infer<typeof paginationSchema>;
