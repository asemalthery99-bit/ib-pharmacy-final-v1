import { eq, and, gte, lte, like, desc, asc, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, medicines, inventory, orders, orderItems, prescriptions, prescriptionImages, carts, Medicine, InsertMedicine, Inventory, InsertInventory, Order, InsertOrder, OrderItem, InsertOrderItem, Prescription, InsertPrescription, PrescriptionImage, InsertPrescriptionImage, Cart, InsertCart } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// Fixed export for modules that expect a constant db instance
export const db = drizzle(process.env.DATABASE_URL || "mysql://localhost:3306/db");

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ MEDICINES QUERIES ============

export async function getAllMedicines() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(medicines);
}

export async function getMedicineById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(medicines).where(eq(medicines.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getMedicinesByIds(ids: number[]) {
  const db = await getDb();
  if (!db) return [];
  if (ids.length === 0) return [];
  return db.select().from(medicines).where(inArray(medicines.id, ids));
}

export async function getMedicinesByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(medicines).where(eq(medicines.category, category));
}

export async function searchMedicines(query: string, category?: string, minPrice?: number, maxPrice?: number) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [like(medicines.name, `%${query}%`)];
  if (category) conditions.push(eq(medicines.category, category));
  if (minPrice !== undefined) conditions.push(gte(medicines.price, minPrice.toString()));
  if (maxPrice !== undefined) conditions.push(lte(medicines.price, maxPrice.toString()));
  
  return db.select().from(medicines).where(and(...conditions));
}

export async function createMedicine(data: InsertMedicine) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(medicines).values(data);
}

export async function updateMedicine(id: number, data: Partial<InsertMedicine>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(medicines).set(data).where(eq(medicines.id, id));
}

// ============ INVENTORY QUERIES ============

export async function getInventoryByMedicineId(medicineId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(inventory).where(eq(inventory.medicineId, medicineId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createInventory(data: InsertInventory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(inventory).values(data);
}

export async function updateInventoryQuantity(medicineId: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(inventory).set({ quantity }).where(eq(inventory.medicineId, medicineId));
}

export async function getLowStockMedicines(threshold?: number) {
  const db = await getDb();
  if (!db) return [];
  const minThreshold = threshold || 10;
  return db.select().from(inventory).where(lte(inventory.quantity, minThreshold));
}

// ============ ORDERS QUERIES ============

export async function createOrder(data: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(orders).values(data);
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

export async function updateOrderStatus(id: number, status: string, paymentStatus?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: any = { status };
  if (paymentStatus) updateData.paymentStatus = paymentStatus;
  return db.update(orders).set(updateData).where(eq(orders.id, id));
}

export async function updateOrderPaymentStatus(id: number, paymentStatus: string, stripePaymentId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: any = { paymentStatus };
  if (stripePaymentId) updateData.stripePaymentId = stripePaymentId;
  return db.update(orders).set(updateData).where(eq(orders.id, id));
}

// ============ ORDER ITEMS QUERIES ============

export async function createOrderItem(data: InsertOrderItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(orderItems).values(data);
}

export async function getOrderItems(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
}

// ============ PRESCRIPTIONS QUERIES ============

export async function createPrescription(data: InsertPrescription) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(prescriptions).values(data);
}

export async function getPrescriptionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(prescriptions).where(eq(prescriptions.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserPrescriptions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(prescriptions).where(eq(prescriptions.userId, userId)).orderBy(desc(prescriptions.createdAt));
}

export async function getPendingPrescriptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(prescriptions).where(eq(prescriptions.status, "pending")).orderBy(asc(prescriptions.createdAt));
}

export async function updatePrescriptionStatus(id: number, status: string, data?: Partial<InsertPrescription>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: any = { status, reviewedAt: new Date() };
  if (data) Object.assign(updateData, data);
  return db.update(prescriptions).set(updateData).where(eq(prescriptions.id, id));
}

// ============ PRESCRIPTION IMAGES QUERIES ============

export async function createPrescriptionImage(data: InsertPrescriptionImage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(prescriptionImages).values(data);
}

export async function getPrescriptionImages(prescriptionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(prescriptionImages).where(eq(prescriptionImages.prescriptionId, prescriptionId));
}

// ============ CART QUERIES ============

export async function addToCart(userId: number, medicineId: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Check if item already in cart
  const existing = await db.select().from(carts).where(and(eq(carts.userId, userId), eq(carts.medicineId, medicineId)));
  
  if (existing.length > 0) {
    // Update quantity
    return db.update(carts).set({ quantity: existing[0].quantity + quantity }).where(and(eq(carts.userId, userId), eq(carts.medicineId, medicineId)));
  } else {
    // Create new cart item
    return db.insert(carts).values({ userId, medicineId, quantity });
  }
}

export async function getUserCart(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(carts).where(eq(carts.userId, userId));
}

export async function updateCartItemQuantity(userId: number, medicineId: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (quantity <= 0) {
    return db.delete(carts).where(and(eq(carts.userId, userId), eq(carts.medicineId, medicineId)));
  }
  
  return db.update(carts).set({ quantity }).where(and(eq(carts.userId, userId), eq(carts.medicineId, medicineId)));
}

export async function clearUserCart(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(carts).where(eq(carts.userId, userId));
}

export async function removeFromCart(userId: number, medicineId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(carts).where(and(eq(carts.userId, userId), eq(carts.medicineId, medicineId)));
}
