import { useState } from "react";
import {
  Gift,
  Zap,
  TrendingUp,
  Crown,
  Copy,
  CheckCircle2,
  Lock,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

interface LoyaltyDashboardProps {
  userId?: string;
  totalPoints?: number;
  tier?: "bronze" | "silver" | "gold" | "platinum";
  totalSpent?: number;
}

const TIER_INFO = {
  bronze: {
    name: "برونزي",
    color: "from-amber-700 to-amber-600",
    icon: "🥉",
    benefits: ["1 نقطة لكل ريال", "مكافأة عيد ميلاد: 50 نقطة", "مكافأة إحالة: 100 نقطة"],
  },
  silver: {
    name: "فضي",
    color: "from-slate-400 to-slate-300",
    icon: "🥈",
    benefits: [
      "1.1 نقطة لكل ريال",
      "مكافأة عيد ميلاد: 100 نقطة",
      "مكافأة إحالة: 150 نقطة",
    ],
  },
  gold: {
    name: "ذهبي",
    color: "from-yellow-500 to-yellow-400",
    icon: "🥇",
    benefits: [
      "1.25 نقطة لكل ريال",
      "مكافأة عيد ميلاد: 200 نقطة",
      "مكافأة إحالة: 250 نقطة",
    ],
  },
  platinum: {
    name: "بلاتيني",
    color: "from-blue-500 to-purple-500",
    icon: "💎",
    benefits: [
      "1.5 نقطة لكل ريال",
      "مكافأة عيد ميلاد: 500 نقطة",
      "مكافأة إحالة: 500 نقطة",
    ],
  },
};

const REWARDS = [
  {
    id: 1,
    name: "خصم 10%",
    points: 100,
    icon: "🏷️",
    color: "bg-blue-50",
  },
  {
    id: 2,
    name: "خصم 20%",
    points: 250,
    icon: "🏷️",
    color: "bg-blue-100",
  },
  {
    id: 3,
    name: "توصيل مجاني",
    points: 150,
    icon: "🚚",
    color: "bg-green-50",
  },
  {
    id: 4,
    name: "منتج مجاني",
    points: 200,
    icon: "🎁",
    color: "bg-pink-50",
  },
  {
    id: 5,
    name: "خصم 30%",
    points: 500,
    icon: "🏷️",
    color: "bg-red-50",
  },
  {
    id: 6,
    name: "500 نقطة إضافية",
    points: 300,
    icon: "⚡",
    color: "bg-yellow-50",
  },
];

export default function LoyaltyDashboard({
  userId = "USER-001",
  totalPoints = 450,
  tier = "silver",
  totalSpent = 750,
}: LoyaltyDashboardProps) {
  const [copiedCode, setCopiedCode] = useState(false);
  const referralCode = `REF-${userId}-2026`;

  const tierInfo = TIER_INFO[tier];
  const nextTierThresholds = {
    bronze: 0,
    silver: 500,
    gold: 1500,
    platinum: 3000,
  };

  const nextTier = tier === "platinum" ? null : Object.keys(nextTierThresholds)[Object.values(nextTierThresholds).indexOf(Math.max(...Object.values(nextTierThresholds).filter((v) => v > nextTierThresholds[tier])))];
  const nextTierSpent = nextTier ? nextTierThresholds[nextTier as keyof typeof nextTierThresholds] : null;
  const remainingSpent = nextTierSpent ? nextTierSpent - totalSpent : 0;

  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    toast.success("تم نسخ الكود!");
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Tier Card */}
      <Card className={`bg-gradient-to-r ${tierInfo.color} text-white`}>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">المستوى الحالي</p>
              <h2 className="text-3xl font-bold text-arabic-bold">
                {tierInfo.icon} {tierInfo.name}
              </h2>
              <p className="text-sm opacity-75 mt-2">
                أنت في أعلى المستويات! استمتع بالمزايا الحصرية.
              </p>
            </div>
            <Crown className="w-16 h-16 opacity-50" />
          </div>
        </CardContent>
      </Card>

      {/* Points Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Current Points */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <Zap className="w-8 h-8 mx-auto mb-2 text-primary" />
              <p className="text-sm text-gray-600 mb-1">النقاط الحالية</p>
              <p className="text-3xl font-bold text-arabic-bold">
                {totalPoints}
              </p>
              <p className="text-xs text-gray-500 mt-2">
                نقطة متاحة للاستبدال
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Total Spent */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-sm text-gray-600 mb-1">إجمالي الإنفاق</p>
              <p className="text-3xl font-bold text-arabic-bold">
                {totalSpent} ر.ي
              </p>
              <p className="text-xs text-gray-500 mt-2">منذ الانضمام</p>
            </div>
          </CardContent>
        </Card>

        {/* Next Tier */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <Crown className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
              <p className="text-sm text-gray-600 mb-1">المستوى التالي</p>
              {nextTier ? (
                <>
                  <p className="text-3xl font-bold text-arabic-bold">
                    {remainingSpent} ر.ي
                  </p>
                  <p className="text-xs text-gray-500 mt-2">
                    للوصول إلى {TIER_INFO[nextTier as keyof typeof TIER_INFO].name}
                  </p>
                </>
              ) : (
                <>
                  <p className="text-2xl font-bold text-primary">🏆</p>
                  <p className="text-xs text-gray-500 mt-2">أنت في أعلى مستوى!</p>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      {nextTier && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-arabic">
                  التقدم نحو المستوى التالي
                </span>
                <span className="text-sm text-gray-600">
                  {Math.round((totalSpent / nextTierSpent!) * 100)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-primary to-blue-600 h-full transition-all duration-500"
                  style={{
                    width: `${Math.min((totalSpent / nextTierSpent!) * 100, 100)}%`,
                  }}
                ></div>
              </div>
              <p className="text-xs text-gray-600 text-arabic">
                أنفق {remainingSpent} ريال إضافي للوصول إلى مستوى{" "}
                {TIER_INFO[nextTier as keyof typeof TIER_INFO].name}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabs */}
      <Tabs defaultValue="rewards" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="rewards">المكافآت</TabsTrigger>
          <TabsTrigger value="benefits">المزايا</TabsTrigger>
          <TabsTrigger value="referral">الإحالة</TabsTrigger>
        </TabsList>

        {/* Rewards Tab */}
        <TabsContent value="rewards" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {REWARDS.map((reward) => (
              <Card key={reward.id} className={reward.color}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="text-2xl mb-2">{reward.icon}</p>
                      <h4 className="font-semibold text-arabic-bold">
                        {reward.name}
                      </h4>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 bg-white px-3 py-1 rounded-full">
                        <Zap className="w-4 h-4 text-primary" />
                        <span className="font-bold text-primary">
                          {reward.points}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    className="w-full bg-primary hover:bg-primary/90 text-white text-arabic-bold"
                    disabled={totalPoints < reward.points}
                  >
                    {totalPoints >= reward.points ? "استبدل الآن" : "نقاط غير كافية"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Benefits Tab */}
        <TabsContent value="benefits">
          <Card>
            <CardHeader>
              <CardTitle className="text-arabic-bold">
                مزايا مستوى {tierInfo.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {tierInfo.benefits.map((benefit, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg"
                  >
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <p className="text-arabic">{benefit}</p>
                  </div>
                ))}
              </div>

              {/* Tier Comparison */}
              <div className="mt-6 pt-6 border-t">
                <h4 className="font-semibold text-arabic-bold mb-4">
                  مقارنة المستويات
                </h4>
                <div className="space-y-2 text-sm">
                  {Object.entries(TIER_INFO).map(([tierKey, tierData]) => (
                    <div
                      key={tierKey}
                      className={`p-3 rounded-lg ${
                        tier === tierKey
                          ? "bg-primary/10 border border-primary"
                          : "bg-gray-50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-arabic">
                          {tierData.icon} {tierData.name}
                        </span>
                        {tier === tierKey && (
                          <span className="text-xs bg-primary text-white px-2 py-1 rounded">
                            حالياً
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Referral Tab */}
        <TabsContent value="referral">
          <Card>
            <CardHeader>
              <CardTitle className="text-arabic-bold">
                برنامج الإحالة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Referral Info */}
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-arabic-bold mb-2">
                  كيف يعمل برنامج الإحالة؟
                </h4>
                <ol className="space-y-2 text-sm text-arabic">
                  <li>1. شارك كودك مع أصدقائك</li>
                  <li>2. عندما يشتري صديقك باستخدام الكود، تحصل على نقاط</li>
                  <li>3. كلما زاد مستواك، زادت النقاط التي تحصل عليها</li>
                </ol>
              </div>

              {/* Referral Code */}
              <div className="space-y-3">
                <label className="block text-sm font-semibold text-arabic-bold">
                  كود الإحالة الخاص بك
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 px-4 py-3 bg-gray-100 rounded-lg font-mono text-center text-arabic-bold">
                    {referralCode}
                  </div>
                  <Button
                    onClick={copyReferralCode}
                    className={`${
                      copiedCode
                        ? "bg-green-600 hover:bg-green-700"
                        : "bg-primary hover:bg-primary/90"
                    } text-white`}
                  >
                    {copiedCode ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 ml-2" />
                        تم النسخ
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 ml-2" />
                        نسخ
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Referral Stats */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-green-50">
                  <CardContent className="pt-4">
                    <p className="text-sm text-gray-600 mb-1">الأصدقاء المُحالون</p>
                    <p className="text-2xl font-bold text-green-600">3</p>
                  </CardContent>
                </Card>
                <Card className="bg-blue-50">
                  <CardContent className="pt-4">
                    <p className="text-sm text-gray-600 mb-1">النقاط المكتسبة</p>
                    <p className="text-2xl font-bold text-blue-600">450</p>
                  </CardContent>
                </Card>
              </div>

              {/* Share Options */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-arabic-bold">
                  شارك عبر
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    className="text-arabic-bold"
                    onClick={() => {
                      const text = `انضم إلى برنامج الولاء في صيدلية إب الرقمية باستخدام كودي: ${referralCode}`;
                      window.open(
                        `https://wa.me/?text=${encodeURIComponent(text)}`
                      );
                    }}
                  >
                    WhatsApp
                  </Button>
                  <Button
                    variant="outline"
                    className="text-arabic-bold"
                    onClick={() => {
                      const text = `انضم إلى برنامج الولاء في صيدلية إب الرقمية باستخدام كودي: ${referralCode}`;
                      window.open(
                        `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`
                      );
                    }}
                  >
                    Twitter
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
