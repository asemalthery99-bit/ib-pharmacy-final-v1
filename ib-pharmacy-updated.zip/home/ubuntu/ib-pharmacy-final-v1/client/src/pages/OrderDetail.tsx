import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Package, Truck, MapPin, Clock, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { toast } from "sonner";

export default function OrderDetail() {
  const [, navigate] = useLocation();
  const [orderId, setOrderId] = useState<number | null>(null);

  // Get orderId from URL
  useEffect(() => {
    const match = window.location.pathname.match(/\/orders\/(\d+)/);
    if (match) {
      setOrderId(parseInt(match[1]));
    }
  }, []);

  const { data: order } = trpc.orders.getById.useQuery(
    { id: orderId! },
    { enabled: !!orderId }
  );

  const { data: delivery } = trpc.delivery.getByOrderId.useQuery(
    { orderId: orderId! },
    { enabled: !!orderId }
  );

  const { data: stages = [] } = trpc.delivery.getStages.useQuery(
    { trackingId: delivery?.id! },
    { enabled: !!delivery?.id }
  );

  if (!orderId || !order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card>
          <CardContent className="text-center py-12">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">جاري تحميل تفاصيل الطلب...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusSteps = [
    { status: "pending", label: "قيد الانتظار", icon: Clock },
    { status: "confirmed", label: "مؤكد", icon: CheckCircle },
    { status: "preparing", label: "جاري التحضير", icon: Package },
    { status: "ready", label: "جاهز", icon: Package },
    { status: "shipped", label: "قيد التوصيل", icon: Truck },
    { status: "delivered", label: "تم التسليم", icon: CheckCircle },
  ];

  const currentStepIndex = statusSteps.findIndex(step => step.status === order.status);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container max-w-6xl mx-auto px-4 py-4">
          <Button variant="outline" onClick={() => navigate("/orders")} className="mb-4">
            العودة للطلبات
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">تفاصيل الطلب #{order.id}</h1>
        </div>
      </div>

      <div className="container max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Status Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>حالة الطلب</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {statusSteps.map((step, index) => {
                    const StepIcon = step.icon;
                    const isCompleted = index <= currentStepIndex;
                    const isCurrent = index === currentStepIndex;

                    return (
                      <div key={step.status} className="flex items-center gap-4">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                            isCompleted
                              ? "bg-green-600 text-white"
                              : "bg-gray-200 text-gray-600"
                          }`}
                        >
                          <StepIcon className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <p
                            className={`font-semibold ${
                              isCurrent ? "text-green-600" : isCompleted ? "text-gray-900" : "text-gray-500"
                            }`}
                          >
                            {step.label}
                          </p>
                          {isCurrent && (
                            <p className="text-sm text-gray-600">الحالة الحالية</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Delivery Tracking */}
            {delivery && (
              <Card>
                <CardHeader>
                  <CardTitle>تتبع التوصيل</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">حالة التوصيل</p>
                      <p className="font-semibold text-lg capitalize">{delivery.currentStatus}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">السائق</p>
                      <p className="font-semibold text-lg">
                        {delivery.driverId ? `السائق #${delivery.driverId}` : "لم يتم التعيين"}
                      </p>
                    </div>
                  </div>

                  {delivery.estimatedDeliveryTime && (
                    <div>
                      <p className="text-sm text-gray-600">الوقت المتوقع للتوصيل</p>
                      <p className="font-semibold">
                        {format(new Date(delivery.estimatedDeliveryTime), "d MMMM yyyy, HH:mm", {
                          locale: ar,
                        })}
                      </p>
                    </div>
                  )}

                  {delivery.actualDeliveryTime && (
                    <div>
                      <p className="text-sm text-gray-600">وقت التسليم الفعلي</p>
                      <p className="font-semibold">
                        {format(new Date(delivery.actualDeliveryTime), "d MMMM yyyy, HH:mm", {
                          locale: ar,
                        })}
                      </p>
                    </div>
                  )}

                  {/* Delivery Stages */}
                  {stages.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <h3 className="font-semibold mb-4">مراحل التوصيل</h3>
                      <div className="space-y-3">
                        {stages.map((stage) => (
                          <div key={stage.id} className="flex gap-3">
                            <div className="w-2 h-2 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                            <div className="flex-1">
                              <p className="font-medium">{stage.stage}</p>
                              {stage.description && (
                                <p className="text-sm text-gray-600">{stage.description}</p>
                              )}
                              {stage.completedAt && (
                                <p className="text-xs text-gray-500 mt-1">
                                  {format(new Date(stage.completedAt), "d MMMM yyyy, HH:mm", {
                                    locale: ar,
                                  })}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Order Items */}
            <Card>
              <CardHeader>
                <CardTitle>عناصر الطلب</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {order.items && order.items.length > 0 ? (
                    order.items.map((item: any) => (
                      <div key={item.id} className="flex justify-between items-center py-2 border-b border-gray-200 last:border-0">
                        <div>
                          <p className="font-medium">الدواء #{item.medicineId}</p>
                          <p className="text-sm text-gray-600">الكمية: {item.quantity}</p>
                        </div>
                        <p className="font-semibold">
                          {(parseFloat(item.priceAtTime as any) * item.quantity).toFixed(2)} ر.ي
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500">لا توجد عناصر</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>ملخص الطلب</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-b border-gray-200 pb-4">
                  <p className="text-sm text-gray-600">رقم الطلب</p>
                  <p className="font-semibold text-lg">#{order.id}</p>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <p className="text-sm text-gray-600">تاريخ الطلب</p>
                  <p className="font-semibold">
                    {format(new Date(order.createdAt), "d MMMM yyyy", { locale: ar })}
                  </p>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <p className="text-sm text-gray-600">حالة الدفع</p>
                  <p className={`font-semibold ${
                    order.paymentStatus === "paid" ? "text-green-600" : "text-yellow-600"
                  }`}>
                    {order.paymentStatus === "paid" ? "مدفوع" : "قيد الانتظار"}
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">الإجمالي</span>
                    <span className="font-semibold">{parseFloat(order.totalPrice as any).toFixed(2)} ر.ي</span>
                  </div>
                  {order.discountAmount && parseFloat(order.discountAmount as any) > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>الخصم</span>
                      <span>-{parseFloat(order.discountAmount as any).toFixed(2)} ر.ي</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold border-t border-gray-200 pt-2">
                    <span>الإجمالي النهائي</span>
                    <span className="text-green-600">
                      {(parseFloat(order.totalPrice as any) - (parseFloat(order.discountAmount as any) || 0)).toFixed(2)} ر.ي
                    </span>
                  </div>
                </div>

                {order.status === "delivered" && (
                  <Button
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => navigate(`/orders/${order.id}/rate`)}
                  >
                    تقييم الطلب
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
