import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Phone, MapPin, Send, CheckCircle, Pill, ShoppingCart } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

/**
 * صفحة التواصل - صيدلية إب الرقمية
 * تصميم: أخضر وأبيض، تخطيط متوازن، نموذج اتصال احترافي
 */

export default function Contact() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast.error("الرجاء ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    
    try {
      // محاكاة إرسال النموذج
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      setIsSuccess(true);
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
      });
      
      toast.success("تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.");
      
      setTimeout(() => setIsSuccess(false), 3000);
    } catch (error) {
      toast.error("حدث خطأ أثناء إرسال الرسالة");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <Pill className="w-8 h-8 text-emerald-600" />
            <span className="text-2xl font-bold text-emerald-600">صيدلية إب</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Button variant="ghost" onClick={() => navigate("/catalog")}>
                  الكتالوج
                </Button>
                <Button variant="ghost" onClick={() => navigate("/orders")}>
                  طلباتي
                </Button>
                <Button variant="ghost" onClick={() => navigate("/cart")}>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  السلة
                </Button>
                <Button variant="ghost" onClick={() => navigate("/")}>
                  الرئيسية
                </Button>
              </>
            ) : (
              <>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate("/")}
                >
                  الرئيسية
                </Button>
                <Button
                  onClick={() => window.location.href = getLoginUrl()}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  تسجيل الدخول
                </Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-16 md:py-24 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-72 h-72 bg-emerald-400 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-20 w-96 h-96 bg-emerald-300 rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-emerald-900 mb-4">
              تواصل معنا
            </h1>
            <p className="text-lg text-emerald-700 mb-8">
              نحن هنا للإجابة على جميع استفساراتك. تواصل معنا عبر أي من القنوات المتاحة أو أرسل لنا رسالة مباشرة.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section id="contact" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {/* Contact Info Cards */}
            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <Phone className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-emerald-900 mb-2">الهاتف</h3>
              <p className="text-emerald-700 mb-4">اتصل بنا مباشرة للحصول على الدعم الفوري</p>
              <a
                href="tel:+966912345678"
                className="text-emerald-600 font-semibold hover:text-emerald-700 transition"
              >
                +966 9 1234 5678
              </a>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <Mail className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-emerald-900 mb-2">البريد الإلكتروني</h3>
              <p className="text-emerald-700 mb-4">أرسل لنا بريداً إلكترونياً وسنرد عليك قريباً</p>
              <a
                href="mailto:info@ibpharmacy.com"
                className="text-emerald-600 font-semibold hover:text-emerald-700 transition"
              >
                info@ibpharmacy.com
              </a>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <MapPin className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-emerald-900 mb-2">الموقع</h3>
              <p className="text-emerald-700 mb-4">زرنا في مقرنا الرئيسي</p>
              <p className="text-emerald-600 font-semibold">مدينة إب، اليمن</p>
            </div>
          </div>

          {/* Contact Form and Map */}
          <div className="grid md:grid-cols-2 gap-12">
            {/* Form */}
            <div>
              <h2 className="text-3xl font-bold text-emerald-900 mb-8">أرسل لنا رسالة</h2>
              
              {isSuccess && (
                <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                  <p className="text-emerald-700">تم إرسال رسالتك بنجاح!</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-emerald-900 mb-2">
                      الاسم *
                    </label>
                    <Input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="أدخل اسمك"
                      className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-emerald-900 mb-2">
                      البريد الإلكتروني *
                    </label>
                    <Input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="بريدك الإلكتروني"
                      className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-emerald-900 mb-2">
                    رقم الهاتف
                  </label>
                  <Input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="رقم هاتفك"
                    className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-emerald-900 mb-2">
                    الموضوع
                  </label>
                  <Input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="موضوع الرسالة"
                    className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-emerald-900 mb-2">
                    الرسالة *
                  </label>
                  <Textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="اكتب رسالتك هنا..."
                    rows={5}
                    className="border-emerald-200 focus:border-emerald-500 focus:ring-emerald-500 resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-lg transition flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      جاري الإرسال...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      إرسال الرسالة
                    </>
                  )}
                </Button>
              </form>
            </div>

            {/* Map and Additional Info */}
            <div className="space-y-8">
              <div className="bg-white rounded-xl shadow-lg overflow-hidden h-96">
                <div className="w-full h-full bg-gradient-to-br from-emerald-100 to-emerald-50 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
                    <p className="text-emerald-700 font-semibold">خريطة الموقع</p>
                    <p className="text-emerald-600 text-sm mt-2">مدينة إب، اليمن</p>
                  </div>
                </div>
              </div>

              {/* Business Hours */}
              <div className="bg-emerald-50 rounded-xl p-6 border border-emerald-200">
                <h3 className="text-lg font-bold text-emerald-900 mb-4">ساعات العمل</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-emerald-700">
                    <span>السبت - الخميس</span>
                    <span className="font-semibold">8:00 ص - 10:00 م</span>
                  </div>
                  <div className="flex justify-between text-emerald-700">
                    <span>الجمعة</span>
                    <span className="font-semibold">2:00 م - 10:00 م</span>
                  </div>
                  <div className="flex justify-between text-emerald-700">
                    <span>الأحد</span>
                    <span className="font-semibold">8:00 ص - 6:00 م</span>
                  </div>
                </div>
              </div>

              {/* Why Contact Us */}
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-lg font-bold text-emerald-900 mb-4">لماذا تتواصل معنا؟</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                    <span className="text-emerald-700">دعم عملاء متاح 24/7</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                    <span className="text-emerald-700">استجابة سريعة لاستفساراتك</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                    <span className="text-emerald-700">فريق متخصص وودود</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">لم تجد ما تبحث عنه؟</h2>
          <p className="text-emerald-100 mb-8 max-w-2xl mx-auto">
            تصفح موقعنا الكامل أو اتصل بنا مباشرة للحصول على المساعدة التي تحتاجها
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => navigate("/")}
              className="bg-white text-emerald-600 hover:bg-emerald-50 font-semibold"
            >
              العودة للرئيسية
            </Button>
            <Button 
              onClick={() => navigate("/catalog")}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold border border-emerald-500"
            >
              تصفح الأدوية
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Pill className="w-6 h-6 text-emerald-400" />
                <span className="text-xl font-bold">صيدلية إب</span>
              </div>
              <p className="text-gray-400">صيدليتك الموثوقة للحصول على الأدوية بسهولة وأمان</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">الروابط السريعة</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" onClick={() => navigate("/")} className="hover:text-emerald-400 transition">الرئيسية</a></li>
                <li><a href="#" onClick={() => navigate("/catalog")} className="hover:text-emerald-400 transition">الكتالوج</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition">عن الصيدلية</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition">تواصل معنا</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">المعلومات</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-emerald-400 transition">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition">شروط الاستخدام</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition">سياسة الاسترجاع</a></li>
                <li><a href="#" className="hover:text-emerald-400 transition">الأسئلة الشائعة</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">تواصل معنا</h4>
              <ul className="space-y-2 text-gray-400">
                <li>📞 +966 9 1234 5678</li>
                <li>📧 info@ibpharmacy.com</li>
                <li>📍 مدينة إب، اليمن</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
            <p>&copy; 2026 صيدلية إب الرقمية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
