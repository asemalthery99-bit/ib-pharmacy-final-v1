/**
 * Cache Service
 * Implements in-memory caching strategy for improved performance
 * Can be extended to use Redis for distributed caching
 */

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

class CacheService {
  private cache: Map<string, CacheEntry<any>> = new Map();
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor() {
    // Start cleanup interval to remove expired entries
    this.startCleanupInterval();
  }

  /**
   * Set a value in cache with TTL
   * @param key - Cache key
   * @param value - Value to cache
   * @param ttlSeconds - Time to live in seconds (default: 1 hour)
   */
  set<T>(key: string, value: T, ttlSeconds: number = 3600): void {
    const expiresAt = Date.now() + ttlSeconds * 1000;
    this.cache.set(key, { value, expiresAt });
    console.log(`[CacheService] Set cache key: ${key} (expires in ${ttlSeconds}s)`);
  }

  /**
   * Get a value from cache
   * @param key - Cache key
   * @returns Cached value or null if expired/not found
   */
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);

    if (!entry) {
      return null;
    }

    // Check if expired
    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return entry.value as T;
  }

  /**
   * Check if key exists in cache
   * @param key - Cache key
   * @returns True if key exists and not expired
   */
  has(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) return false;

    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return false;
    }

    return true;
  }

  /**
   * Delete a cache entry
   * @param key - Cache key
   */
  delete(key: string): boolean {
    return this.cache.delete(key);
  }

  /**
   * Clear all cache entries
   */
  clear(): void {
    this.cache.clear();
    console.log("[CacheService] Cache cleared");
  }

  /**
   * Get cache statistics
   * @returns Cache stats
   */
  getStats() {
    return {
      size: this.cache.size,
      entries: Array.from(this.cache.entries()).map(([key, entry]) => ({
        key,
        expiresIn: Math.max(0, entry.expiresAt - Date.now()),
      })),
    };
  }

  /**
   * Cache medicines list
   * @param medicines - Array of medicines
   * @param ttlSeconds - TTL in seconds
   */
  cacheMedicines(medicines: any[], ttlSeconds: number = 1800): void {
    this.set("medicines:all", medicines, ttlSeconds);
  }

  /**
   * Get cached medicines list
   * @returns Cached medicines or null
   */
  getCachedMedicines(): any[] | null {
    return this.get("medicines:all");
  }

  /**
   * Cache medicine by ID
   * @param medicineId - Medicine ID
   * @param medicine - Medicine data
   * @param ttlSeconds - TTL in seconds
   */
  cacheMedicineById(medicineId: number, medicine: any, ttlSeconds: number = 1800): void {
    this.set(`medicine:${medicineId}`, medicine, ttlSeconds);
  }

  /**
   * Get cached medicine by ID
   * @param medicineId - Medicine ID
   * @returns Cached medicine or null
   */
  getCachedMedicineById(medicineId: number): any | null {
    return this.get(`medicine:${medicineId}`);
  }

  /**
   * Cache inventory data
   * @param medicineId - Medicine ID
   * @param inventory - Inventory data
   * @param ttlSeconds - TTL in seconds
   */
  cacheInventory(medicineId: number, inventory: any, ttlSeconds: number = 900): void {
    this.set(`inventory:${medicineId}`, inventory, ttlSeconds);
  }

  /**
   * Get cached inventory
   * @param medicineId - Medicine ID
   * @returns Cached inventory or null
   */
  getCachedInventory(medicineId: number): any | null {
    return this.get(`inventory:${medicineId}`);
  }

  /**
   * Invalidate cache by pattern
   * @param pattern - Pattern to match (e.g., "medicine:*")
   */
  invalidateByPattern(pattern: string): number {
    let count = 0;
    const regex = new RegExp(pattern.replace("*", ".*"));

    const keys = Array.from(this.cache.keys());
    for (const key of keys) {
      if (regex.test(key)) {
        this.cache.delete(key);
        count++;
      }
    }

    console.log(`[CacheService] Invalidated ${count} cache entries matching pattern: ${pattern}`);
    return count;
  }

  /**
   * Start cleanup interval to remove expired entries
   */
  private startCleanupInterval(): void {
    this.cleanupInterval = setInterval(() => {
      let expiredCount = 0;
      const now = Date.now();

      const entries = Array.from(this.cache.entries());
      for (const [key, entry] of entries) {
        if (now > entry.expiresAt) {
          this.cache.delete(key);
          expiredCount++;
        }
      }

      if (expiredCount > 0) {
        console.log(`[CacheService] Cleaned up ${expiredCount} expired cache entries`);
      }
    }, 60000); // Run every minute
  }

  /**
   * Stop cleanup interval
   */
  stopCleanupInterval(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }
}

export const cacheService = new CacheService();
