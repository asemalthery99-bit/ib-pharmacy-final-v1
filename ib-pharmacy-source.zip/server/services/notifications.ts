import { notifyOwner } from "../_core/notification";

/**
 * Notification Service
 * Handles all notifications for orders, prescriptions, and inventory
 */

export interface NotificationPayload {
  type: "order" | "prescription" | "inventory" | "payment";
  title: string;
  content: string;
  userId?: number;
  orderId?: number;
  prescriptionId?: number;
  metadata?: Record<string, any>;
}

/**
 * Send notification to owner (pharmacist)
 */
export async function sendOwnerNotification(payload: NotificationPayload) {
  try {
    const result = await notifyOwner({
      title: payload.title,
      content: payload.content,
    });
    
    console.log(`[Notification] Owner notification sent: ${payload.type}`, result);
    return result;
  } catch (error) {
    console.error(`[Notification] Failed to send owner notification:`, error);
    return false;
  }
}

/**
 * Trigger notification for new order
 */
export async function notifyNewOrder(orderId: number, totalPrice: string, itemCount: number) {
  return sendOwnerNotification({
    type: "order",
    title: "🛒 طلب جديد",
    content: `تم استقبال طلب جديد #${orderId}

الإجمالي: ${totalPrice} ريال
عدد العناصر: ${itemCount}`,
    orderId,
    metadata: { totalPrice, itemCount },
  });
}

/**
 * Trigger notification for new prescription
 */
export async function notifyNewPrescription(prescriptionId: number, patientName?: string, medicineCount?: number) {
  return sendOwnerNotification({
    type: "prescription",
    title: "📋 روشتة طبية جديدة",
    content: `تم استقبال روشتة طبية جديدة #${prescriptionId}

المريض: ${patientName || "غير محدد"}
عدد الأدوية: ${medicineCount || "قيد المعالجة"}`,
    prescriptionId,
    metadata: { patientName, medicineCount },
  });
}

/**
 * Trigger notification for low inventory
 */
export async function notifyLowInventory(medicineName: string, currentQuantity: number, threshold: number) {
  return sendOwnerNotification({
    type: "inventory",
    title: "⚠️ تنبيه: مخزون منخفض",
    content: `الدواء: ${medicineName}

الكمية الحالية: ${currentQuantity}
الحد الأدنى: ${threshold}

يرجى إعادة الطلب في أقرب وقت.`,
    metadata: { medicineName, currentQuantity, threshold },
  });
}

/**
 * Trigger notification for successful payment
 */
export async function notifyPaymentSuccess(orderId: number, totalPrice: string, paymentMethod: string) {
  return sendOwnerNotification({
    type: "payment",
    title: "✅ دفع ناجح",
    content: `تم استقبال دفعة بنجاح للطلب #${orderId}

المبلغ: ${totalPrice} ريال
طريقة الدفع: ${paymentMethod}`,
    orderId,
    metadata: { totalPrice, paymentMethod },
  });
}

/**
 * Trigger notification for payment failure
 */
export async function notifyPaymentFailure(orderId: number, reason: string) {
  return sendOwnerNotification({
    type: "payment",
    title: "❌ فشل الدفع",
    content: `فشلت عملية الدفع للطلب #${orderId}

السبب: ${reason}`,
    orderId,
    metadata: { reason },
  });
}

/**
 * Trigger notification for order status update
 */
export async function notifyOrderStatusUpdate(orderId: number, status: string, statusArabic: string) {
  const statusEmoji: Record<string, string> = {
    pending: "⏳",
    preparing: "👨‍⚕️",
    ready: "✅",
    completed: "🎉",
    cancelled: "❌",
  };

  return sendOwnerNotification({
    type: "order",
    title: `${statusEmoji[status] || "📦"} تحديث حالة الطلب`,
    content: `تم تحديث حالة الطلب #${orderId}

الحالة الجديدة: ${statusArabic}`,
    orderId,
    metadata: { status, statusArabic },
  });
}

/**
 * Trigger notification for prescription status update
 */
export async function notifyPrescriptionStatusUpdate(prescriptionId: number, status: string, statusArabic: string) {
  const statusEmoji: Record<string, string> = {
    pending: "⏳",
    approved: "✅",
    rejected: "❌",
    completed: "🎉",
  };

  return sendOwnerNotification({
    type: "prescription",
    title: `${statusEmoji[status] || "📋"} تحديث حالة الروشتة`,
    content: `تم تحديث حالة الروشتة #${prescriptionId}

الحالة الجديدة: ${statusArabic}`,
    prescriptionId,
    metadata: { status, statusArabic },
  });
}

/**
 * Batch notification for multiple low inventory items
 */
export async function notifyMultipleLowInventory(items: Array<{ name: string; quantity: number; threshold: number }>) {
  if (items.length === 0) return true;

  const itemsList = items
    .map(item => `• ${item.name}: ${item.quantity} (الحد الأدنى: ${item.threshold})`)
    .join("");

  return sendOwnerNotification({
    type: "inventory",
    title: "⚠️ تنبيهات: مخزون منخفض",
    content: `تم اكتشاف ${items.length} أدوية بمخزون منخفض:

${itemsList}`,
    metadata: { itemCount: items.length, items },
  });
}
