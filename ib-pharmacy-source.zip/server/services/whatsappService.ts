import axios from "axios";

/**
 * WhatsApp Service
 * Handles sending WhatsApp messages via Twilio
 * Supports order notifications, prescription updates, and customer alerts
 */

interface WhatsAppMessage {
  to: string; // Phone number in E.164 format (e.g., +966501234567)
  message: string;
}

interface OrderNotificationData {
  customerPhone: string;
  customerName: string;
  orderId: number;
  totalPrice: number;
  orderStatus: string;
}

interface PrescriptionNotificationData {
  customerPhone: string;
  customerName: string;
  prescriptionId: number;
  status: string;
  quotedPrice?: number;
}

class WhatsAppService {
  private twilioAccountSid: string | undefined;
  private twilioAuthToken: string | undefined;
  private twilioPhoneNumber: string | undefined;
  private isConfigured: boolean;

  constructor() {
    this.twilioAccountSid = process.env.TWILIO_ACCOUNT_SID;
    this.twilioAuthToken = process.env.TWILIO_AUTH_TOKEN;
    this.twilioPhoneNumber = process.env.TWILIO_WHATSAPP_NUMBER;

    this.isConfigured = !!(this.twilioAccountSid && this.twilioAuthToken && this.twilioPhoneNumber);

    if (!this.isConfigured) {
      console.warn("[WhatsAppService] Twilio credentials not configured. WhatsApp service disabled.");
    }
  }

  private getTwilioUrl(): string {
    return `https://api.twilio.com/2010-04-01/Accounts/${this.twilioAccountSid}/Messages.json`;
  }

  private getBasicAuth(): string {
    const credentials = `${this.twilioAccountSid}:${this.twilioAuthToken}`;
    return "Basic " + Buffer.from(credentials).toString("base64");
  }

  async sendMessage(data: WhatsAppMessage): Promise<boolean> {
    if (!this.isConfigured) {
      console.warn("[WhatsAppService] WhatsApp service not configured");
      return false;
    }

    try {
      const response = await axios.post(
        this.getTwilioUrl(),
        {
          From: `whatsapp:${this.twilioPhoneNumber}`,
          To: `whatsapp:${data.to}`,
          Body: data.message,
        },
        {
          headers: {
            Authorization: this.getBasicAuth(),
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      console.log(`[WhatsAppService] Message sent successfully to ${data.to}. SID: ${response.data.sid}`);
      return true;
    } catch (error) {
      console.error("[WhatsAppService] Failed to send message:", error);
      return false;
    }
  }

  async sendOrderConfirmation(data: OrderNotificationData): Promise<boolean> {
    const message = `
🎉 تأكيد الطلب
السلام عليكم ${data.customerName}

تم استقبال طلبك بنجاح!

📦 رقم الطلب: #${data.orderId}
💰 الإجمالي: ${data.totalPrice} ريال
📍 الحالة: ${this.getStatusInArabic(data.orderStatus)}

سيتم إخطارك بتحديثات الطلب.

 صيدلية إب الرقمية
    `.trim();

    return this.sendMessage({
      to: data.customerPhone,
      message,
    });
  }

  async sendOrderStatusUpdate(data: OrderNotificationData): Promise<boolean> {
    const message = `
📢 تحديث حالة الطلب

📦 رقم الطلب: #${data.orderId}
📍 الحالة الجديدة: ${this.getStatusInArabic(data.orderStatus)}

شكراً لتعاملك معنا!

 صيدلية إب الرقمية
    `.trim();

    return this.sendMessage({
      to: data.customerPhone,
      message,
    });
  }

  async sendPrescriptionQuote(data: PrescriptionNotificationData): Promise<boolean> {
    const message = `
💊 عرض سعر الروشتة

السلام عليكم ${data.customerName}

تم مراجعة روشتتك الطبية!

📋 رقم الروشتة: #${data.prescriptionId}
💰 السعر المقترح: ${data.quotedPrice || "قيد المراجعة"} ريال

يمكنك الموافقة أو طلب تعديل من خلال التطبيق.

 صيدلية إب الرقمية
    `.trim();

    return this.sendMessage({
      to: data.customerPhone,
      message,
    });
  }

  async sendPrescriptionStatus(data: PrescriptionNotificationData): Promise<boolean> {
    const statusMessages: Record<string, string> = {
      pending: "قيد الانتظار",
      reviewed: "تمت المراجعة",
      quoted: "تم عرض السعر",
      completed: "مكتملة",
      rejected: "مرفوضة",
    };

    const message = `
📋 تحديث حالة الروشتة

🔔 رقم الروشتة: #${data.prescriptionId}
📍 الحالة: ${statusMessages[data.status] || data.status}

شكراً لتعاملك معنا!

 صيدلية إب الرقمية
    `.trim();

    return this.sendMessage({
      to: data.customerPhone,
      message,
    });
  }

  async sendLoyaltyPointsNotification(customerPhone: string, points: number, totalPoints: number): Promise<boolean> {
    const message = `
🎁 نقاط الولاء

تم إضافة ${points} نقطة لحسابك!

⭐ إجمالي نقاطك: ${totalPoints} نقطة

يمكنك استبدال النقاط بمكافآت حصرية.

 صيدلية إب الرقمية
    `.trim();

    return this.sendMessage({
      to: customerPhone,
      message,
    });
  }

  async sendDeliveryNotification(customerPhone: string, orderId: number, deliveryTime: string): Promise<boolean> {
    const message = `
🚚 إشعار التوصيل

طلبك في الطريق إليك!

📦 رقم الطلب: #${orderId}
⏰ الوقت المتوقع: ${deliveryTime}

شكراً لتعاملك معنا!

 صيدلية إب الرقمية
    `.trim();

    return this.sendMessage({
      to: customerPhone,
      message,
    });
  }

  private getStatusInArabic(status: string): string {
    const statusMap: Record<string, string> = {
      pending: "قيد الانتظار",
      preparing: "جاري التحضير",
      ready: "جاهز للاستلام",
      completed: "مكتمل",
      cancelled: "ملغى",
    };
    return statusMap[status] || status;
  }
}

export const whatsappService = new WhatsAppService();

