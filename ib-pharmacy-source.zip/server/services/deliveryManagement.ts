import { db } from "../db";
import { eq, and } from "drizzle-orm";

/**
 * Driver Management Service
 * Handles driver registration, status updates, and delivery assignments
 */

export interface Driver {
  id: string;
  name: string;
  phone: string;
  email: string;
  vehicle: string;
  licensePlate: string;
  status: "active" | "inactive" | "on_delivery" | "offline";
  latitude: number;
  longitude: number;
  rating: number;
  totalDeliveries: number;
  createdAt: Date;
}

export interface DeliveryAssignment {
  id: string;
  orderId: string;
  driverId: string;
  status: "pending" | "assigned" | "in_transit" | "delivered" | "failed";
  estimatedTime: number; // minutes
  actualTime?: number;
  pickupLocation: { lat: number; lng: number };
  deliveryLocation: { lat: number; lng: number };
  createdAt: Date;
  completedAt?: Date;
}

/**
 * Register a new driver
 */
export async function registerDriver(driverData: Omit<Driver, "id" | "createdAt" | "rating" | "totalDeliveries">): Promise<Driver> {
  const newDriver: Driver = {
    id: `DRV-${Date.now()}`,
    ...driverData,
    rating: 5.0,
    totalDeliveries: 0,
    createdAt: new Date(),
  };

  // In production, save to database
  console.log("Driver registered:", newDriver);

  return newDriver;
}

/**
 * Update driver location
 */
export async function updateDriverLocation(
  driverId: string,
  latitude: number,
  longitude: number
): Promise<void> {
  console.log(`Driver ${driverId} location updated to: ${latitude}, ${longitude}`);
  // In production, update in database
}

/**
 * Update driver status
 */
export async function updateDriverStatus(
  driverId: string,
  status: Driver["status"]
): Promise<void> {
  console.log(`Driver ${driverId} status updated to: ${status}`);
  // In production, update in database
}

/**
 * Assign delivery to nearest driver
 */
export async function assignDeliveryToNearestDriver(
  orderId: string,
  customerLocation: { lat: number; lng: number },
  pharmacyLocation: { lat: number; lng: number }
): Promise<DeliveryAssignment> {
  // In production, calculate distance and find nearest available driver
  const estimatedTime = Math.round(Math.random() * 30 + 15); // 15-45 minutes

  const assignment: DeliveryAssignment = {
    id: `DLV-${Date.now()}`,
    orderId,
    driverId: `DRV-${Math.floor(Math.random() * 1000)}`, // Mock driver ID
    status: "assigned",
    estimatedTime,
    pickupLocation: pharmacyLocation,
    deliveryLocation: customerLocation,
    createdAt: new Date(),
  };

  console.log("Delivery assigned:", assignment);
  return assignment;
}

/**
 * Update delivery status
 */
export async function updateDeliveryStatus(
  deliveryId: string,
  status: DeliveryAssignment["status"]
): Promise<void> {
  console.log(`Delivery ${deliveryId} status updated to: ${status}`);
  // In production, update in database
}

/**
 * Calculate distance between two coordinates (Haversine formula)
 */
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
}

/**
 * Estimate delivery time based on distance
 */
export function estimateDeliveryTime(distanceKm: number): number {
  // Assume average speed of 30 km/h in city
  const timeMinutes = Math.round((distanceKm / 30) * 60);
  return Math.max(timeMinutes, 15); // Minimum 15 minutes
}

/**
 * Get driver statistics
 */
export async function getDriverStats(driverId: string): Promise<{
  totalDeliveries: number;
  completedDeliveries: number;
  failedDeliveries: number;
  averageRating: number;
  totalEarnings: number;
}> {
  // In production, fetch from database
  return {
    totalDeliveries: 150,
    completedDeliveries: 148,
    failedDeliveries: 2,
    averageRating: 4.8,
    totalEarnings: 2500,
  };
}

/**
 * Get active drivers
 */
export async function getActiveDrivers(): Promise<Driver[]> {
  // In production, fetch from database
  const mockDrivers: Driver[] = [
    {
      id: "DRV-001",
      name: "محمد علي",
      phone: "967123456789",
      email: "driver1@ibpharmacy.com",
      vehicle: "Toyota Corolla",
      licensePlate: "YM-1234",
      status: "active",
      latitude: 15.3694,
      longitude: 44.2039,
      rating: 4.9,
      totalDeliveries: 150,
      createdAt: new Date(),
    },
    {
      id: "DRV-002",
      name: "فاطمة حسن",
      phone: "967987654321",
      email: "driver2@ibpharmacy.com",
      vehicle: "Hyundai i10",
      licensePlate: "YM-5678",
      status: "on_delivery",
      latitude: 15.3750,
      longitude: 44.2100,
      rating: 4.7,
      totalDeliveries: 120,
      createdAt: new Date(),
    },
  ];

  return mockDrivers;
}

/**
 * Track delivery in real-time
 */
export async function trackDelivery(deliveryId: string): Promise<{
  status: DeliveryAssignment["status"];
  driverName: string;
  driverPhone: string;
  currentLocation: { lat: number; lng: number };
  estimatedArrival: Date;
  distance: number;
}> {
  // In production, fetch real-time data from database
  return {
    status: "in_transit",
    driverName: "محمد علي",
    driverPhone: "967123456789",
    currentLocation: { lat: 15.3720, lng: 44.2070 },
    estimatedArrival: new Date(Date.now() + 20 * 60000), // 20 minutes from now
    distance: 2.5, // km
  };
}
