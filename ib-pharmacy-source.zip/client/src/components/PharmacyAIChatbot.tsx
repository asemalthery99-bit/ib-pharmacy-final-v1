import { useState, useRef, useEffect } from "react";
import { Send, MessageCircle, X, AlertCircle, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  disclaimer?: string;
}

interface PharmacyAIChatbotProps {
  medicines?: string[];
  allergies?: string[];
  conditions?: string[];
}

export default function PharmacyAIChatbot({
  medicines = [],
  allergies = [],
  conditions = [],
}: PharmacyAIChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "مرحباً! أنا مساعدك الصيدلاني الذكي. يمكنني مساعدتك بمعلومات عن الأدوية والجرعات والآثار الجانبية. كيف يمكنني مساعدتك اليوم؟",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    try {
      // Call the API to get pharmaceutical advice
      // In a real implementation, this would call a tRPC endpoint
      const response = await fetch("/api/pharmacy-ai/advice", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: inputValue,
          context: {
            medicines,
            allergies,
            conditions,
          },
        }),
      });

      if (!response.ok) {
        throw new Error("فشل في الحصول على الرد");
      }

      const data = await response.json();

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.response,
        timestamp: new Date(),
        disclaimer: data.disclaimer,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 2).toString(),
        role: "assistant",
        content:
          "عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى أو استشارة الصيدلي مباشرة.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-br from-primary to-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center hover:scale-110"
          title="فتح المساعد الصيدلاني"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 z-50 w-96 h-[600px] flex flex-col shadow-2xl border-primary/20">
          {/* Header */}
          <div className="bg-gradient-to-r from-primary to-blue-600 text-white p-4 rounded-t-lg flex items-center justify-between">
            <div>
              <h3 className="font-bold text-lg text-arabic-bold">
                المساعد الصيدلاني الذكي
              </h3>
              <p className="text-xs text-blue-100">
                متاح 24/7 للاستشارات الدوائية
              </p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-white/20 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-xs p-3 rounded-lg ${
                    message.role === "user"
                      ? "bg-primary text-white rounded-br-none"
                      : "bg-white border border-gray-200 text-foreground rounded-bl-none"
                  }`}
                >
                  <p className="text-sm text-arabic">{message.content}</p>

                  {/* Disclaimer */}
                  {message.disclaimer && (
                    <div className="mt-2 pt-2 border-t border-gray-300">
                      <div className="flex items-start gap-2 text-xs text-yellow-700 bg-yellow-50 p-2 rounded">
                        <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                        <p>{message.disclaimer}</p>
                      </div>
                    </div>
                  )}

                  <span className="text-xs opacity-70 mt-1 block">
                    {message.timestamp.toLocaleTimeString("ar-SA", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 text-foreground p-3 rounded-lg rounded-bl-none">
                  <div className="flex items-center gap-2">
                    <Loader className="w-4 h-4 animate-spin text-primary" />
                    <p className="text-sm text-gray-600">جاري معالجة طلبك...</p>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-gray-200 p-4 bg-white rounded-b-lg">
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="اسأل عن الأدوية والجرعات..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !isLoading) {
                    handleSendMessage();
                  }
                }}
                disabled={isLoading}
                className="text-arabic"
              />
              <Button
                onClick={handleSendMessage}
                disabled={isLoading || !inputValue.trim()}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>

            {/* Quick Actions */}
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                onClick={() =>
                  setInputValue("ما هي الآثار الجانبية للأسبرين؟")
                }
                className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded hover:bg-blue-100 transition"
              >
                الآثار الجانبية
              </button>
              <button
                onClick={() =>
                  setInputValue("ما هي الجرعة الموصى بها للبنادول؟")
                }
                className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded hover:bg-blue-100 transition"
              >
                الجرعات
              </button>
              <button
                onClick={() =>
                  setInputValue("هل هناك تعارض بين الأسبرين والوارفارين؟")
                }
                className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded hover:bg-blue-100 transition"
              >
                التعارضات
              </button>
            </div>
          </div>
        </Card>
      )}
    </>
  );
}
