import React, { createContext, useContext, useState, useCallback, useEffect } from "react";

export interface Prescription {
  id: string;
  userId: string;
  imageUrl: string;
  notes: string;
  status: "pending" | "reviewed" | "quoted" | "completed" | "rejected";
  uploadedAt: Date;
  reviewedAt?: Date;
  pharmacistNotes?: string;
  quotedPrice?: number;
  quotedMedicines?: string[];
}

interface PrescriptionContextType {
  prescriptions: Prescription[];
  uploadPrescription: (imageUrl: string, notes: string) => void;
  updatePrescriptionStatus: (id: string, status: Prescription["status"]) => void;
  addPharmacistReview: (id: string, notes: string, price: number, medicines: string[]) => void;
  getPrescriptionById: (id: string) => Prescription | undefined;
  getUserPrescriptions: (userId: string) => Prescription[];
  getPendingPrescriptions: () => Prescription[];
}

const PrescriptionContext = createContext<PrescriptionContextType | undefined>(undefined);

export function PrescriptionProvider({ children }: { children: React.ReactNode }) {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(() => {
    try {
      const saved = localStorage.getItem("prescriptions");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // حفظ الروشتات في localStorage عند كل تغيير
  useEffect(() => {
    localStorage.setItem("prescriptions", JSON.stringify(prescriptions));
  }, [prescriptions]);

  const uploadPrescription = useCallback((imageUrl: string, notes: string) => {
    const newPrescription: Prescription = {
      id: `rx_${Date.now()}`,
      userId: "user_1", // سيتم تحديثه عند إضافة نظام المستخدمين
      imageUrl,
      notes,
      status: "pending",
      uploadedAt: new Date(),
    };

    setPrescriptions((prev) => [...prev, newPrescription]);
  }, []);

  const updatePrescriptionStatus = useCallback((id: string, status: Prescription["status"]) => {
    setPrescriptions((prev) =>
      prev.map((rx) =>
        rx.id === id
          ? { ...rx, status, reviewedAt: new Date() }
          : rx
      )
    );
  }, []);

  const addPharmacistReview = useCallback(
    (id: string, notes: string, price: number, medicines: string[]) => {
      setPrescriptions((prev) =>
        prev.map((rx) =>
          rx.id === id
            ? {
                ...rx,
                status: "quoted",
                pharmacistNotes: notes,
                quotedPrice: price,
                quotedMedicines: medicines,
                reviewedAt: new Date(),
              }
            : rx
        )
      );
    },
    []
  );

  const getPrescriptionById = useCallback((id: string) => {
    return prescriptions.find((rx) => rx.id === id);
  }, [prescriptions]);

  const getUserPrescriptions = useCallback((userId: string) => {
    return prescriptions.filter((rx) => rx.userId === userId);
  }, [prescriptions]);

  const getPendingPrescriptions = useCallback(() => {
    return prescriptions.filter((rx) => rx.status === "pending");
  }, [prescriptions]);

  const value: PrescriptionContextType = {
    prescriptions,
    uploadPrescription,
    updatePrescriptionStatus,
    addPharmacistReview,
    getPrescriptionById,
    getUserPrescriptions,
    getPendingPrescriptions,
  };

  return (
    <PrescriptionContext.Provider value={value}>
      {children}
    </PrescriptionContext.Provider>
  );
}

export function usePrescription() {
  const context = useContext(PrescriptionContext);
  if (context === undefined) {
    throw new Error("usePrescription must be used within a PrescriptionProvider");
  }
  return context;
}
