import React, { useState } from 'react';
import { MessageCircle, X, Send, Phone } from 'lucide-react';

interface SupportTicket {
  id: string;
  subject: string;
  message: string;
  category: 'order' | 'payment' | 'delivery' | 'product' | 'other';
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: Date;
  responses: SupportResponse[];
}

interface SupportResponse {
  id: string;
  message: string;
  sender: 'user' | 'support';
  createdAt: Date;
}

const SupportWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'whatsapp' | 'ticket'>('whatsapp');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketCategory, setTicketCategory] = useState<'order' | 'payment' | 'delivery' | 'product' | 'other'>('other');
  const [ticketSubject, setTicketSubject] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const whatsappNumber = '+967XXXXXXXXX'; // استبدل برقمك الفعلي
  const whatsappMessage = encodeURIComponent(
    'مرحباً، أنا بحاجة إلى مساعدة في صيدلية إب الرقمية'
  );

  const handleWhatsAppClick = () => {
    window.open(
      `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${whatsappMessage}`,
      '_blank'
    );
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // إرسال التذكرة إلى الخادم
      const response = await fetch('/api/support/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subject: ticketSubject,
          message: ticketMessage,
          category: ticketCategory,
        }),
      });

      if (response.ok) {
        setSubmitSuccess(true);
        setTicketMessage('');
        setTicketSubject('');
        setTicketCategory('other');

        // إخفاء رسالة النجاح بعد 3 ثواني
        setTimeout(() => {
          setSubmitSuccess(false);
          setIsOpen(false);
        }, 3000);
      }
    } catch (error) {
      console.error('Error submitting ticket:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110"
          aria-label="فتح نافذة الدعم"
        >
          <MessageCircle size={24} />
        </button>
      )}

      {/* Support Widget */}
      {isOpen && (
        <div className="bg-white rounded-lg shadow-2xl w-96 max-h-[600px] flex flex-col animate-in fade-in slide-in-from-bottom-4">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 flex justify-between items-center rounded-t-lg">
            <h3 className="font-bold text-lg">الدعم الفني</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-blue-700 p-1 rounded transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex border-b">
            <button
              onClick={() => setActiveTab('whatsapp')}
              className={`flex-1 py-3 px-4 text-center font-semibold transition-colors ${
                activeTab === 'whatsapp'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Phone size={18} className="inline mr-2" />
              WhatsApp
            </button>
            <button
              onClick={() => setActiveTab('ticket')}
              className={`flex-1 py-3 px-4 text-center font-semibold transition-colors ${
                activeTab === 'ticket'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <MessageCircle size={18} className="inline mr-2" />
              تذكرة
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4">
            {activeTab === 'whatsapp' ? (
              <div className="space-y-4">
                <p className="text-gray-700 text-sm">
                  تواصل معنا مباشرة عبر WhatsApp للحصول على دعم فوري
                </p>
                <button
                  onClick={handleWhatsAppClick}
                  className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Phone size={20} />
                  فتح WhatsApp
                </button>
                <div className="bg-blue-50 p-3 rounded-lg text-sm text-gray-700">
                  <p className="font-semibold mb-2">ساعات الدعم:</p>
                  <p>السبت - الخميس: 9:00 ص - 9:00 م</p>
                  <p>الجمعة: 2:00 م - 9:00 م</p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmitTicket} className="space-y-4">
                {submitSuccess && (
                  <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
                    ✓ تم إرسال تذكرتك بنجاح. سنرد عليك قريباً.
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    الموضوع
                  </label>
                  <input
                    type="text"
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    placeholder="مثال: مشكلة في الطلب"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    الفئة
                  </label>
                  <select
                    value={ticketCategory}
                    onChange={(e) => setTicketCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="order">الطلبات</option>
                    <option value="payment">الدفع</option>
                    <option value="delivery">التوصيل</option>
                    <option value="product">المنتجات</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    الرسالة
                  </label>
                  <textarea
                    value={ticketMessage}
                    onChange={(e) => setTicketMessage(e.target.value)}
                    placeholder="اشرح مشكلتك بالتفصيل..."
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-blue-500 hover:bg-blue-600 disabled:bg-gray-400 text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Send size={18} />
                  {isSubmitting ? 'جاري الإرسال...' : 'إرسال التذكرة'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SupportWidget;
