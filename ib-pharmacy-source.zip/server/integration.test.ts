import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

describe("API Binding Integration Tests", () => {
  describe("Medicines API Binding", () => {
    it("should list all medicines", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      expect(Array.isArray(medicines)).toBe(true);
      expect(medicines.length).toBeGreaterThan(0);
    });

    it("should get medicines by IDs", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      const medicineIds = medicines.slice(0, 2).map(m => m.id);
      
      const medicinesByIds = await caller.medicines.getByIds({ ids: medicineIds });
      expect(Array.isArray(medicinesByIds)).toBe(true);
      expect(medicinesByIds.length).toBe(medicineIds.length);
    });

    it("should search medicines", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.medicines.search({ query: "بنادول" });
      expect(Array.isArray(result)).toBe(true);
    });

    it("should filter medicines by category", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.medicines.getByCategory({ category: "pain-relief" });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("Inventory API Binding", () => {
    it("should get inventory for medicines", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      if (medicines.length > 0) {
        const inv = await caller.inventory.getByMedicineId({ medicineId: medicines[0].id });
        if (inv) {
          expect(inv.medicineId).toBe(medicines[0].id);
          expect(inv.quantity).toBeGreaterThanOrEqual(0);
        }
      }
    });

    it("should get low stock medicines", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const lowStock = await caller.inventory.getLowStock({ threshold: 50 });
      expect(Array.isArray(lowStock)).toBe(true);
    });
  });

  describe("Frontend-API Binding Verification", () => {
    it("should verify medicines data structure for frontend", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      expect(medicines.length).toBeGreaterThan(0);

      // Verify each medicine has required fields for frontend
      medicines.forEach(medicine => {
        expect(medicine).toHaveProperty("id");
        expect(medicine).toHaveProperty("name");
        expect(medicine).toHaveProperty("arabicName");
        expect(medicine).toHaveProperty("price");
        expect(medicine).toHaveProperty("imageUrl");
        expect(medicine).toHaveProperty("category");
      });
    });

    it("should verify getByIds returns correct structure", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      if (medicines.length > 0) {
        const ids = [medicines[0].id];
        const result = await caller.medicines.getByIds({ ids });
        
        expect(result.length).toBe(1);
        expect(result[0].id).toBe(medicines[0].id);
      }
    });
  });
});
