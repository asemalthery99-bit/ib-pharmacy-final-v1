import { OpenAI } from 'openai';

/**
 * Advanced AI Service
 * Handles inventory prediction and smart recommendations
 */

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface MedicineInventory {
  id: string;
  name: string;
  currentStock: number;
  minStock: number;
  monthlyConsumption: number;
  category: string;
  price: number;
  seasonalDemand: Record<string, number>; // month -> demand multiplier
}

export interface SalesHistory {
  medicineId: string;
  medicineName: string;
  quantity: number;
  date: Date;
  season: string;
  revenue: number;
}

export interface InventoryPrediction {
  medicineId: string;
  medicineName: string;
  currentStock: number;
  predictedConsumption: number;
  daysUntilStockout: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  recommendation: string;
  reorderQuantity: number;
  reorderDate: Date;
  confidence: number;
}

export interface RecommendedProduct {
  id: string;
  name: string;
  category: string;
  price: number;
  reason: string;
  complementaryTo: string;
  expectedIncrease: number; // percentage increase in order value
  rating: number;
}

/**
 * Predict inventory levels based on sales history and seasonality
 */
export async function predictInventoryLevels(
  medicines: MedicineInventory[],
  salesHistory: SalesHistory[],
  forecastDays: number = 30
): Promise<InventoryPrediction[]> {
  try {
    const predictions: InventoryPrediction[] = [];

    for (const medicine of medicines) {
      // Get recent sales data for this medicine
      const medicineSales = salesHistory.filter(
        (s) => s.medicineId === medicine.id
      );

      if (medicineSales.length === 0) {
        // No sales history, use average consumption
        predictions.push({
          medicineId: medicine.id,
          medicineName: medicine.name,
          currentStock: medicine.currentStock,
          predictedConsumption: medicine.monthlyConsumption,
          daysUntilStockout: Math.floor(
            (medicine.currentStock / medicine.monthlyConsumption) * 30
          ),
          riskLevel: 'low',
          recommendation: 'Monitor stock levels regularly',
          reorderQuantity: medicine.monthlyConsumption * 2,
          reorderDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          confidence: 0.5,
        });
        continue;
      }

      // Calculate average daily consumption
      const last30Days = medicineSales.filter(
        (s) => new Date(s.date).getTime() > Date.now() - 30 * 24 * 60 * 60 * 1000
      );

      const avgDailyConsumption =
        last30Days.length > 0
          ? last30Days.reduce((sum, s) => sum + s.quantity, 0) / 30
          : medicine.monthlyConsumption / 30;

      // Apply seasonal adjustment
      const currentMonth = new Date().getMonth() + 1;
      const seasonalMultiplier = medicine.seasonalDemand[currentMonth] || 1.0;
      const adjustedConsumption = avgDailyConsumption * seasonalMultiplier;

      // Calculate days until stockout
      const daysUntilStockout = Math.floor(
        medicine.currentStock / adjustedConsumption
      );

      // Determine risk level
      let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
      if (daysUntilStockout < 7) riskLevel = 'critical';
      else if (daysUntilStockout < 14) riskLevel = 'high';
      else if (daysUntilStockout < 30) riskLevel = 'medium';

      // Calculate reorder quantity
      const reorderQuantity = Math.ceil(
        adjustedConsumption * 60 - medicine.currentStock
      ); // 60 days supply

      // Determine reorder date
      const reorderDate = new Date();
      reorderDate.setDate(
        reorderDate.getDate() + Math.max(7, daysUntilStockout - 7)
      );

      predictions.push({
        medicineId: medicine.id,
        medicineName: medicine.name,
        currentStock: medicine.currentStock,
        predictedConsumption: Math.round(adjustedConsumption * 30),
        daysUntilStockout,
        riskLevel,
        recommendation: getInventoryRecommendation(
          riskLevel,
          medicine.name,
          daysUntilStockout
        ),
        reorderQuantity,
        reorderDate,
        confidence: Math.min(0.95, 0.5 + last30Days.length * 0.01),
      });
    }

    return predictions;
  } catch (error) {
    console.error('Error predicting inventory levels:', error);
    return [];
  }
}

/**
 * Generate inventory recommendation text
 */
function getInventoryRecommendation(
  riskLevel: string,
  medicineName: string,
  daysUntilStockout: number
): string {
  switch (riskLevel) {
    case 'critical':
      return `⚠️ حرج: ${medicineName} سينفد خلال ${daysUntilStockout} أيام. أعد الطلب فوراً!`;
    case 'high':
      return `⚠️ مرتفع: ${medicineName} سينفد خلال ${daysUntilStockout} يوم. يُنصح بإعادة الطلب قريباً.`;
    case 'medium':
      return `📊 متوسط: ${medicineName} متوفر لمدة ${daysUntilStockout} يوم. خطط لإعادة الطلب.`;
    default:
      return `✅ آمن: ${medicineName} متوفر بكميات كافية.`;
  }
}

/**
 * Get smart product recommendations based on purchase history
 */
export async function getSmartRecommendations(
  purchasedMedicines: string[],
  allMedicines: MedicineInventory[],
  userProfile?: {
    age?: number;
    conditions?: string[];
    allergies?: string[];
  }
): Promise<RecommendedProduct[]> {
  try {
    const recommendations: RecommendedProduct[] = [];

    // Define complementary products mapping
    const complementaryProducts: Record<string, string[]> = {
      'خافض الحرارة': ['فيتامين C', 'شراب السعال', 'مسكن الألم'],
      'مسكن الألم': ['فيتامين C', 'كريم مسكن', 'حبوب المعدة'],
      'أنسولين': ['شرائط قياس السكر', 'إبر حقن', 'كريم العناية'],
      'أدوية الضغط': ['جهاز قياس الضغط', 'ملح منخفض الصوديوم', 'فيتامينات'],
      'مضاد حيوي': ['بروبيوتيك', 'فيتامين C', 'شراب السعال'],
      'كريم الجلد': ['غسول الوجه', 'مرطب', 'واقي الشمس'],
      'فيتامين C': ['مسكن الألم', 'خافض الحرارة', 'مكمل غذائي'],
      'شراب السعال': ['خافض الحرارة', 'فيتامين C', 'مسكن الألم'],
    };

    // Generate recommendations for each purchased medicine
    for (const medicineName of purchasedMedicines) {
      const complements = complementaryProducts[medicineName] || [];

      for (const complementName of complements) {
        const complementMedicine = allMedicines.find(
          (m) => m.name === complementName
        );

        if (
          complementMedicine &&
          !purchasedMedicines.includes(complementName)
        ) {
          recommendations.push({
            id: complementMedicine.id,
            name: complementMedicine.name,
            category: complementMedicine.category,
            price: complementMedicine.price,
            reason: `يُنصح به عادة مع ${medicineName}`,
            complementaryTo: medicineName,
            expectedIncrease: 15 + Math.random() * 20, // 15-35% increase
            rating: 4.5 + Math.random() * 0.5,
          });
        }
      }
    }

    // Remove duplicates and sort by expected increase
    const uniqueRecommendations = Array.from(
      new Map(recommendations.map((r) => [r.id, r])).values()
    ).sort((a, b) => b.expectedIncrease - a.expectedIncrease);

    return uniqueRecommendations.slice(0, 5); // Return top 5
  } catch (error) {
    console.error('Error generating recommendations:', error);
    return [];
  }
}

/**
 * Use AI to analyze sales trends and predict future demand
 */
export async function analyzeSeasonalTrends(
  salesHistory: SalesHistory[],
  medicineId: string
): Promise<{
  trend: 'increasing' | 'decreasing' | 'stable';
  seasonalPattern: Record<string, number>;
  predictedDemandNextMonth: number;
  confidence: number;
}> {
  try {
    // Group sales by month
    const monthlySales: Record<string, number> = {};

    for (const sale of salesHistory.filter((s) => s.medicineId === medicineId)) {
      const month = new Date(sale.date).toLocaleString('ar-SA', {
        month: 'long',
      });
      monthlySales[month] = (monthlySales[month] || 0) + sale.quantity;
    }

    // Calculate seasonal pattern
    const totalSales = Object.values(monthlySales).reduce((a, b) => a + b, 0);
    const seasonalPattern: Record<string, number> = {};

    for (const [month, sales] of Object.entries(monthlySales)) {
      seasonalPattern[month] = sales / (totalSales / 12);
    }

    // Determine trend
    const recentMonths = Object.values(monthlySales).slice(-3);
    const olderMonths = Object.values(monthlySales).slice(-6, -3);

    const recentAvg = recentMonths.reduce((a, b) => a + b, 0) / recentMonths.length;
    const olderAvg = olderMonths.reduce((a, b) => a + b, 0) / olderMonths.length;

    let trend: 'increasing' | 'decreasing' | 'stable' = 'stable';
    if (recentAvg > olderAvg * 1.1) trend = 'increasing';
    else if (recentAvg < olderAvg * 0.9) trend = 'decreasing';

    // Predict next month demand
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    const nextMonthName = nextMonth.toLocaleString('ar-SA', { month: 'long' });
    const seasonalFactor = seasonalPattern[nextMonthName] || 1.0;
    const predictedDemandNextMonth = Math.round(recentAvg * seasonalFactor);

    return {
      trend,
      seasonalPattern,
      predictedDemandNextMonth,
      confidence: Math.min(0.95, 0.6 + Object.keys(monthlySales).length * 0.05),
    };
  } catch (error) {
    console.error('Error analyzing seasonal trends:', error);
    return {
      trend: 'stable',
      seasonalPattern: {},
      predictedDemandNextMonth: 0,
      confidence: 0,
    };
  }
}

/**
 * Get AI-powered insights using LLM
 */
export async function getAIInsights(
  predictions: InventoryPrediction[],
  recommendations: RecommendedProduct[]
): Promise<string> {
  try {
    const criticalItems = predictions.filter((p) => p.riskLevel === 'critical');
    const highRiskItems = predictions.filter((p) => p.riskLevel === 'high');

    const prompt = `
    أنت مساعد ذكي لإدارة الصيدلية. قم بتحليل البيانات التالية وقدم رؤى قيمة:
    
    العناصر الحرجة (سينفد المخزون قريباً):
    ${criticalItems.map((p) => `- ${p.medicineName}: ${p.daysUntilStockout} أيام فقط`).join('')}
    
    العناصر عالية المخاطر:
    ${highRiskItems.map((p) => `- ${p.medicineName}: ${p.daysUntilStockout} يوم`).join('')}
    
    المنتجات الموصى بها للعملاء:
    ${recommendations.map((r) => `- ${r.name}: ${r.reason}`).join('')}
    
    قدم ملخص تنفيذي بـ 3-4 نقاط رئيسية للعمل الفوري.
    `;

    const response = await client.chat.completions.create({
      model: 'gpt-4o',
      messages: [{ role: 'user', content: prompt }],
    });

    return response.choices[0].message.content || "لا توجد رؤى متاحة حالياً.";
  } catch (error) {
    console.error('Error getting AI insights:', error);
    return "فشل الحصول على رؤى ذكية حالياً.";
  }
}
