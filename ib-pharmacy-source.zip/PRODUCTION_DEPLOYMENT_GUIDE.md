# دليل نشر صيدلية إب الرقمية على الإنتاج
## Production Deployment Guide - v5.0

---

## 📋 المتطلبات الأساسية

### الحسابات والخدمات المطلوبة:
1. **Vercel** - لنشر الواجهة الأمامية (Frontend)
2. **DigitalOcean** أو **AWS** - لنشر الخادم (Backend)
3. **PlanetScale** أو **TiDB Cloud** - لقاعدة البيانات MySQL السحابية
4. **SendGrid** - لخدمة البريد الإلكتروني
5. **Twilio** - لخدمات WhatsApp و SMS
6. **Stripe** - لمعالجة الدفع
7. **AWS S3** - لتخزين الصور والملفات
8. **OpenAI** - لتحليل الروشتات الطبية

---

## 🚀 خطوات النشر

### المرحلة 1: إعداد قاعدة البيانات السحابية

#### 1.1 استخدام PlanetScale
```bash
# 1. إنشاء حساب على PlanetScale (https://planetscale.com)
# 2. إنشاء database جديد: ibpharmacy_prod
# 3. الحصول على connection string
# 4. تحديث DATABASE_URL في .env.production

DATABASE_URL=mysql://username:password@aws.connect.psdb.cloud/ibpharmacy_prod?sslAccept=strict
```

#### 1.2 تشغيل Migrations
```bash
# نسخ ملف البيئة
cp .env.production.example .env.production

# تحديث DATABASE_URL
# ثم تشغيل migrations
pnpm run db:push
```

---

### المرحلة 2: نشر الخادم (Backend)

#### 2.1 على DigitalOcean

**الخطوة 1: إنشاء Droplet**
```bash
# 1. اذهب إلى DigitalOcean وأنشئ Droplet جديد
# 2. اختر Ubuntu 22.04
# 3. اختر حجم مناسب (2GB RAM minimum)
# 4. أضف SSH key
```

**الخطوة 2: إعداد الخادم**
```bash
# الاتصال بـ Droplet
ssh root@your_droplet_ip

# تحديث النظام
apt update && apt upgrade -y

# تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs

# تثبيت Docker و Docker Compose
apt install -y docker.io docker-compose
usermod -aG docker $USER

# تثبيت Nginx
apt install -y nginx
```

**الخطوة 3: نسخ المشروع**
```bash
# نسخ المشروع إلى الخادم
git clone https://github.com/yourusername/ibpharmacy.git /app
cd /app

# تثبيت التبعيات
pnpm install

# نسخ ملف البيئة
cp .env.production.example .env.production

# تحديث القيم الحساسة في .env.production
nano .env.production
```

**الخطوة 4: إعداد Docker Compose**
```bash
# تشغيل المشروع باستخدام Docker Compose
docker-compose -f docker-compose.production.yml up -d

# التحقق من حالة الخدمات
docker-compose -f docker-compose.production.yml ps
```

**الخطوة 5: إعداد Nginx كـ Reverse Proxy**
```bash
# إنشاء ملف إعدادات Nginx
sudo nano /etc/nginx/sites-available/ibpharmacy

# أضف المحتوى التالي:
server {
    listen 80;
    server_name api.ibpharmacy.com;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# تفعيل الموقع
sudo ln -s /etc/nginx/sites-available/ibpharmacy /etc/nginx/sites-enabled/

# اختبار الإعدادات
sudo nginx -t

# إعادة تشغيل Nginx
sudo systemctl restart nginx
```

**الخطوة 6: إعداد SSL Certificate (Let's Encrypt)**
```bash
# تثبيت Certbot
sudo apt install -y certbot python3-certbot-nginx

# الحصول على شهادة SSL
sudo certbot --nginx -d api.ibpharmacy.com

# تجديد تلقائي
sudo systemctl enable certbot.timer
```

---

### المرحلة 3: نشر الواجهة الأمامية (Frontend)

#### 3.1 على Vercel

**الخطوة 1: ربط المشروع**
```bash
# 1. اذهب إلى Vercel.com
# 2. اختر "Import Project"
# 3. اختر repository من GitHub
# 4. اختر المشروع ibpharmacy
```

**الخطوة 2: إعداد متغيرات البيئة**
```
VITE_API_URL=https://api.ibpharmacy.com
VITE_APP_ID=your_app_id_here
VITE_OAUTH_PORTAL_URL=https://oauth.ibpharmacy.com
VITE_STRIPE_PUBLIC_KEY=pk_live_your_key_here
```

**الخطوة 3: تكوين النطاق (Domain)**
```
# 1. في Vercel، اذهب إلى Settings > Domains
# 2. أضف نطاقك: ibpharmacy.com
# 3. حدّث DNS records عند مسجل النطاق
```

---

### المرحلة 4: إعداد الخدمات الخارجية

#### 4.1 SendGrid (البريد الإلكتروني)
```bash
# 1. اذهب إلى SendGrid.com
# 2. أنشئ حساب وتحقق من النطاق
# 3. احصل على API Key
# 4. أضف في .env.production:
SMTP_USER=apikey
SMTP_PASSWORD=SG.your_api_key_here
```

#### 4.2 Twilio (WhatsApp/SMS)
```bash
# 1. اذهب إلى Twilio.com
# 2. أنشئ حساب
# 3. احصل على Account SID و Auth Token
# 4. أضف رقم WhatsApp Business
# 5. أضف في .env.production:
TWILIO_ACCOUNT_SID=your_sid_here
TWILIO_AUTH_TOKEN=your_token_here
TWILIO_WHATSAPP_NUMBER=+966501234567
```

#### 4.3 Stripe (الدفع)
```bash
# 1. اذهب إلى Stripe.com
# 2. أنشئ حساب تاجر
# 3. احصل على Secret Key و Public Key
# 4. أضف في .env.production:
STRIPE_SECRET_KEY=sk_live_your_key_here
STRIPE_PUBLIC_KEY=pk_live_your_key_here
```

#### 4.4 AWS S3 (تخزين الملفات)
```bash
# 1. اذهب إلى AWS Console
# 2. أنشئ S3 bucket: ibpharmacy-prod-bucket
# 3. أنشئ IAM user مع صلاحيات S3
# 4. احصل على Access Key و Secret Key
# 5. أضف في .env.production:
AWS_ACCESS_KEY_ID=your_access_key_here
AWS_SECRET_ACCESS_KEY=your_secret_key_here
AWS_S3_BUCKET=ibpharmacy-prod-bucket
```

---

## 🔒 إجراءات الأمان

### 1. تفعيل HTTPS
```bash
# تأكد من أن جميع الاتصالات تستخدم HTTPS
# في Nginx:
return 301 https://$server_name$request_uri;
```

### 2. تعيين رؤوس الأمان
```bash
# في Nginx:
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "DENY" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
```

### 3. تفعيل WAF (Web Application Firewall)
```bash
# استخدم AWS WAF أو Cloudflare
# لحماية من هجمات DDoS والثغرات الشائعة
```

### 4. تشفير البيانات الحساسة
```bash
# تأكد من تعيين ENCRYPTION_KEY في .env.production
# جميع بيانات المرضى ستكون مشفرة تلقائياً
```

---

## 📊 المراقبة والصيانة

### 1. إعداد المراقبة
```bash
# استخدم Sentry لتتبع الأخطاء
# استخدم New Relic لمراقبة الأداء
# استخدم Datadog للمراقبة الشاملة
```

### 2. النسخ الاحتياطية
```bash
# تفعيل النسخ الاحتياطية التلقائية لـ PlanetScale
# تفعيل النسخ الاحتياطية لـ AWS S3
```

### 3. التحديثات
```bash
# تحديث التبعيات بانتظام
pnpm update

# اختبار قبل النشر
pnpm test

# نشر التحديثات
git push origin main
```

---

## 🧪 اختبار الإنتاج

### 1. اختبار الاتصال
```bash
# اختبر الاتصال بقاعدة البيانات
curl https://api.ibpharmacy.com/health

# يجب أن تحصل على:
{"status": "ok", "database": "connected"}
```

### 2. اختبار البريد الإلكتروني
```bash
# أرسل بريد اختبار
curl -X POST https://api.ibpharmacy.com/test/email \\
  -H "Authorization: Bearer your_token" \\
  -H "Content-Type: application/json" \\
  -d '{"to": "test@example.com"}'
```

### 3. اختبار الدفع
```bash
# استخدم بطاقات اختبار Stripe
# رقم البطاقة: 4242 4242 4242 4242
# الصلاحية: أي تاريخ مستقبلي
# CVC: أي 3 أرقام
```

---

## 📞 استكشاف الأخطاء

### المشكلة: الخادم لا يستجيب
```bash
# تحقق من حالة Docker
docker-compose -f docker-compose.production.yml ps

# عرض السجلات
docker-compose -f docker-compose.production.yml logs -f backend

# إعادة تشغيل
docker-compose -f docker-compose.production.yml restart
```

### المشكلة: قاعدة البيانات لا تتصل
```bash
# تحقق من DATABASE_URL
echo $DATABASE_URL

# اختبر الاتصال
mysql -u username -p -h hostname -e "SELECT 1"
```

### المشكلة: البريد الإلكتروني لا يُرسل
```bash
# تحقق من بيانات SendGrid
echo $SMTP_USER
echo $SMTP_PASSWORD

# اختبر الاتصال
telnet smtp.sendgrid.net 587
```

---

## ✅ قائمة التحقق النهائية

- [ ] تم نشر قاعدة البيانات على السحابة
- [ ] تم نشر الخادم على DigitalOcean/AWS
- [ ] تم نشر الواجهة الأمامية على Vercel
- [ ] تم ربط النطاق الأساسي
- [ ] تم تفعيل SSL Certificate
- [ ] تم إعداد SendGrid
- [ ] تم إعداد Twilio
- [ ] تم إعداد Stripe
- [ ] تم إعداد AWS S3
- [ ] تم اختبار جميع الميزات
- [ ] تم تفعيل المراقبة والتنبيهات
- [ ] تم إعداد النسخ الاحتياطية

---

**تاريخ آخر تحديث:** مارس 2026
**الإصدار:** v5.0
**الحالة:** جاهز للنشر

