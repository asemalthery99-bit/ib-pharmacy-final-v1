import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Spinner } from "@/components/ui/spinner";
import { AlertCircle, CheckCircle, Truck, CreditCard } from "lucide-react";
import { toast } from "sonner";

export default function Checkout() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [promoCode, setPromoCode] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<any>(null);
  const [notes, setNotes] = useState("");

  // Fetch cart
  const { data: cart, isLoading: cartLoading } = trpc.cart.getCart.useQuery();

  // Validate promo code
  const validatePromoQuery = trpc.promoCodes.validate.useQuery(
    { code: promoCode },
    { enabled: false }
  );

  const handleValidatePromo = async () => {
    if (!promoCode.trim()) {
      toast.error("يرجى إدخال كود الخصم");
      return;
    }
    try {
      const result = await validatePromoQuery.refetch();
      if (result.data) {
        setAppliedPromo(result.data);
        toast.success("تم تطبيق كود الخصم بنجاح");
        setPromoCode("");
      }
    } catch (error: any) {
      toast.error(error?.message || "كود الخصم غير صحيح");
    }
  };

  // Create order
  const { mutate: createOrder, isPending: orderPending } = trpc.orders.create.useMutation({
    onSuccess: (data: any) => {
      toast.success("تم إنشاء الطلب بنجاح");
      navigate(`/orders/${data.orderId}`);
    },
    onError: (error: any) => {
      toast.error(error?.message || "حدث خطأ في إنشاء الطلب");
    },
  });

  // Clear cart after successful order
  const { mutate: clearCart } = trpc.cart.clearCart.useMutation();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <p className="text-lg font-semibold mb-4">يرجى تسجيل الدخول</p>
          <Button onClick={() => navigate("/")} className="w-full">
            العودة للرئيسية
          </Button>
        </Card>
      </div>
    );
  }

  if (cartLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  const cartItems = (cart?.items as any[]) || [];

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-yellow-500" />
          <p className="text-lg font-semibold mb-4">السلة فارغة</p>
          <Button onClick={() => navigate("/catalog")} className="w-full">
            تصفح الأدوية
          </Button>
        </Card>
      </div>
    );
  }

  // Fetch medicines to get prices
  const { data: medicines = [] } = trpc.medicines.list.useQuery();

  // Calculate totals
  const subtotal = cartItems.reduce((sum: number, item: any) => {
    const medicine = medicines.find((m: any) => m.id === item.medicineId);
    return sum + (medicine ? Number(medicine.price) * item.quantity : 0);
  }, 0);

  let discount = 0;
  if (appliedPromo) {
    if (appliedPromo.discountType === "percentage") {
      discount = (subtotal * Number(appliedPromo.discountValue)) / 100;
      if (appliedPromo.maxDiscount) {
        discount = Math.min(discount, Number(appliedPromo.maxDiscount));
      }
    } else {
      discount = Number(appliedPromo.discountValue);
    }
  }

  const total = Math.max(0, subtotal - discount);



  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast.error("السلة فارغة");
      return;
    }

    const items = cartItems.map((item: any) => {
      const medicine = medicines.find((m: any) => m.id === item.medicineId);
      return {
        medicineId: item.medicineId,
        quantity: item.quantity,
        priceAtTime: medicine?.price.toString() || "0",
      };
    });

    createOrder({
      items,
      totalPrice: total.toFixed(2),
      discountAmount: discount.toFixed(2),
      promoCodeId: appliedPromo?.id,
      notes,
    });

    if (!orderPending) {
      clearCart();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">إتمام الطلب</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Items */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">عناصر الطلب</h2>
              <div className="space-y-4">
                {cartItems.map((item: any) => {
                  const medicine = medicines.find((m: any) => m.id === item.medicineId);
                  return (
                    <div key={item.medicineId} className="flex items-center justify-between border-b pb-4 last:border-b-0">
                      <div className="flex-1">
                        <p className="font-semibold">{medicine?.name}</p>
                        <p className="text-sm text-gray-600">الكمية: {item.quantity}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{(Number(medicine?.price || 0) * item.quantity).toFixed(2)} ريال</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Promo Code */}
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">كود الخصم</h2>
              {appliedPromo ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-semibold text-emerald-900">{appliedPromo.code}</p>
                    <p className="text-sm text-emerald-700">
                      {appliedPromo.discountType === "percentage"
                        ? `خصم ${appliedPromo.discountValue}%`
                        : `خصم ${appliedPromo.discountValue} ريال`}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setAppliedPromo(null)}
                  >
                    إزالة
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input
                    placeholder="أدخل كود الخصم"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    disabled={validatePromoQuery.isFetching}
                  />
                  <Button
                    onClick={handleValidatePromo}
                    disabled={validatePromoQuery.isFetching}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    {validatePromoQuery.isFetching ? <Spinner /> : "تطبيق"}
                  </Button>
                </div>
              )}
            </Card>

            {/* Delivery Notes */}
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">ملاحظات التوصيل</h2>
              <textarea
                placeholder="أضف ملاحظات إضافية للطلب (اختياري)"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                rows={4}
              />
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-20 space-y-4">
              <h2 className="text-xl font-bold">ملخص الطلب</h2>

              <div className="space-y-2 border-b pb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">المجموع الفرعي</span>
                  <span className="font-semibold">{subtotal.toFixed(2)} ريال</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>الخصم</span>
                    <span>-{discount.toFixed(2)} ريال</span>
                  </div>
                )}
              </div>

              <div className="flex justify-between text-lg font-bold">
                <span>الإجمالي</span>
                <span className="text-emerald-600">{total.toFixed(2)} ريال</span>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
                <CreditCard className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-blue-900">
                  سيتم معالجة الدفع بعد تأكيد الطلب
                </p>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 flex items-start gap-3">
                <Truck className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-emerald-900">
                  التوصيل المجاني للطلبات فوق 50 ريال
                </p>
              </div>

              <Button
                onClick={handleCheckout}
                disabled={orderPending || cartItems.length === 0}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-6 text-lg"
              >
                {orderPending ? (
                  "جاري المعالجة..."
                ) : (
                  "إتمام الطلب"
                )}
              </Button>

              <Button
                variant="outline"
                onClick={() => navigate("/catalog")}
                className="w-full"
              >
                متابعة التسوق
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
