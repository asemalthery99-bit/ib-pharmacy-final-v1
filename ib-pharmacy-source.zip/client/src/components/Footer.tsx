import { Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-foreground text-primary-foreground mt-20">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* About */}
          <div>
            <h3 className="font-bold text-lg mb-4">صيدلية إب</h3>
            <p className="text-sm opacity-90">
              صيدليتك الموثوقة أونلاين. نقدم أدوية أصلية مع توصيل آمن واستشارات صيدلانية مجانية.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">الروابط السريعة</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:opacity-80 transition">الكتالوج</a></li>
              <li><a href="#" className="hover:opacity-80 transition">طلباتي</a></li>
              <li><a href="#" className="hover:opacity-80 transition">الاستشارات</a></li>
              <li><a href="#" className="hover:opacity-80 transition">الأسئلة الشائعة</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-bold mb-4">الدعم</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:opacity-80 transition">الدعم</a></li>
              <li><a href="#" className="hover:opacity-80 transition">سياسة الخصوصية</a></li>
              <li><a href="#" className="hover:opacity-80 transition">الشروط والأحكام</a></li>
              <li><a href="#" className="hover:opacity-80 transition">اتصل بنا</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold mb-4">تواصل معنا</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <a href="mailto:info@ibpharmacy.com" className="hover:opacity-80 transition">
                  info@ibpharmacy.com
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <a href="tel:+967123456789" className="hover:opacity-80 transition">
                  +967 1 234 5678
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>إب، اليمن</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-primary-foreground/20 pt-8"></div>

        {/* Copyright & Ownership */}
        <div className="flex flex-col md:flex-row justify-between items-center text-sm opacity-80 gap-4">
          <p>جميع الحقوق محفوظة © 2026 صيدلية إب الرقمية</p>
          <p className="text-center md:text-right">
            تم تطوير هذا الموقع بواسطة <span className="font-semibold">المستخدم</span> بالتعاون مع <span className="font-semibold">Manus AI</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
