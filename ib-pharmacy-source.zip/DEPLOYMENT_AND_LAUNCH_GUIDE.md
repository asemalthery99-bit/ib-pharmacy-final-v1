# دليل النشر والإطلاق النهائي - الإصدار 3.8
## صيدلية إب الرقمية - من التطوير إلى الإطلاق التجاري الفعلي

---

## المحتويات
1. [شراء اسم النطاق](#شراء-اسم-النطاق)
2. [النشر على Vercel](#النشر-على-vercel)
3. [النشر على AWS](#النشر-على-aws)
4. [إعدادات الأمان والشهادات](#إعدادات-الأمان-والشهادات)
5. [نظام الدعم الفني](#نظام-الدعم-الفني)
6. [اختبار المستخدم (Beta Testing)](#اختبار-المستخدم-beta-testing)
7. [قائمة التحقق النهائية](#قائمة-التحقق-النهائية)

---

## شراء اسم النطاق

### الخطوة 1: اختيار منصة تسجيل النطاق

اختر من المنصات الموثوقة:
- **Namecheap** (https://www.namecheap.com) - اقتصادي وموثوق
- **GoDaddy** (https://www.godaddy.com) - الأكثر شهرة
- **Domain.com** (https://www.domain.com) - خيارات متعددة
- **Google Domains** (https://domains.google) - سهل الاستخدام

### الخطوة 2: البحث عن النطاق

```bash
# ابحث عن:
ibpharmacy.com
ibpharmacy.ye (للعراق)
ibpharmacy.net
ibpharmacy.online
```

### الخطوة 3: شراء وتجديد

- **السعر:** عادة 10-15 دولار سنوياً
- **المدة:** اشترِ لمدة 3 سنوات على الأقل
- **الخصوصية:** فعّل حماية الخصوصية (WHOIS Privacy)

### الخطوة 4: إعدادات DNS

بعد الشراء، ستحتاج لربط النطاق بخادمك:

#### للنشر على Vercel:
```
اذهب إلى إعدادات النطاق
أضف DNS Records التالية:

Type: CNAME
Name: www
Value: cname.vercel-dns.com

Type: A
Name: @
Value: 76.76.19.165
```

#### للنشر على AWS:
```
استخدم Route 53 في AWS
أضف A Record يشير إلى CloudFront Distribution
```

---

## النشر على Vercel

### الخطوة 1: إنشاء حساب Vercel

1. اذهب إلى https://vercel.com
2. سجل دخول باستخدام GitHub
3. أنشئ فريق جديد (Team)

### الخطوة 2: ربط المستودع

```bash
# في GitHub:
# 1. ادفع الكود إلى GitHub
git push origin main

# 2. في Vercel، اختر "New Project"
# 3. اختر مستودع GitHub
# 4. اختر الفرع (main)
```

### الخطوة 3: إضافة متغيرات البيئة

```bash
# في لوحة تحكم Vercel:
# Settings > Environment Variables

أضف جميع المتغيرات من .env.production:
- DATABASE_URL
- PAYPAL_CLIENT_ID
- PAYPAL_CLIENT_SECRET
- GOOGLE_MAPS_API_KEY
- OPENAI_API_KEY
- FIREBASE_API_KEY
- AWS_ACCESS_KEY_ID
- AWS_SECRET_ACCESS_KEY
- JWT_SECRET
```

### الخطوة 4: ربط النطاق

```bash
# في Vercel:
# Settings > Domains
# أضف النطاق الخاص بك (ibpharmacy.com)

# اتبع التعليمات لإضافة DNS Records
```

### الخطوة 5: النشر

```bash
# Vercel سينشر تلقائياً عند كل push إلى main
# يمكنك مراقبة التقدم في لوحة التحكم
```

---

## النشر على AWS

### الخطوة 1: إنشاء حساب AWS

1. اذهب إلى https://aws.amazon.com
2. أنشئ حساب جديد
3. تحقق من الهوية

### الخطوة 2: إعداد EC2 Instance

```bash
# 1. اذهب إلى EC2 Dashboard
# 2. اختر "Launch Instance"
# 3. اختر "Ubuntu 22.04 LTS"
# 4. اختر t3.medium (أو أكبر)
# 5. أنشئ Security Group مع:
#    - Port 80 (HTTP)
#    - Port 443 (HTTPS)
#    - Port 3000 (Application)
```

### الخطوة 3: الاتصال بـ Instance

```bash
# تحميل المفتاح الخاص
chmod 400 your-key.pem

# الاتصال بالخادم
ssh -i your-key.pem ubuntu@your-instance-ip
```

### الخطوة 4: تثبيت البيئة

```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# تثبيت Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# تثبيت Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### الخطوة 5: نشر التطبيق

```bash
# استنسخ المستودع
git clone https://github.com/your-repo/ibpharmacy.git
cd ibpharmacy

# أنشئ ملف .env.production
cp .env.example .env.production
# عدّل القيم

# شغّل Docker Compose
sudo docker-compose up -d

# تحقق من الحالة
sudo docker-compose ps
```

### الخطوة 6: إعداد Nginx كـ Reverse Proxy

```bash
# تثبيت Nginx
sudo apt install -y nginx

# إنشاء ملف إعدادات
sudo nano /etc/nginx/sites-available/ibpharmacy
```

```nginx
server {
    listen 80;
    server_name ibpharmacy.com www.ibpharmacy.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# تفعيل الموقع
sudo ln -s /etc/nginx/sites-available/ibpharmacy /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### الخطوة 7: تفعيل HTTPS

```bash
# تثبيت Certbot
sudo apt install -y certbot python3-certbot-nginx

# الحصول على شهادة SSL
sudo certbot --nginx -d ibpharmacy.com -d www.ibpharmacy.com

# التجديد التلقائي
sudo systemctl enable certbot.timer
```

---

## إعدادات الأمان والشهادات

### 1. شهادات SSL/TLS

```bash
# تحقق من شهادتك
sudo certbot certificates

# تجديد يدوي
sudo certbot renew --dry-run
```

### 2. جدار الحماية (Firewall)

```bash
# تفعيل UFW
sudo ufw enable

# السماح بالمنافذ المطلوبة
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

### 3. نسخ احتياطية

```bash
# نسخة احتياطية يومية من قاعدة البيانات
0 2 * * * /home/ubuntu/backup-db.sh
```

---

## نظام الدعم الفني

### 1. تفعيل WhatsApp

```bash
# في .env
WHATSAPP_NUMBER="+967XXXXXXXXX"
WHATSAPP_BUSINESS_ACCOUNT_ID="your_account_id"
WHATSAPP_API_KEY="your_api_key"
```

### 2. نظام التذاكر

```bash
# سيتم تخزين التذاكر في قاعدة البيانات
# يمكن الوصول إليها من لوحة التحكم
```

### 3. البريد الإلكتروني

```bash
# في .env
SMTP_HOST="smtp.gmail.com"
SMTP_USER="your-email@gmail.com"
SMTP_PASSWORD="your-app-password"
```

---

## اختبار المستخدم (Beta Testing)

### الخطوة 1: اختيار المختبرين

- اختر 5-10 أشخاص من مختلف الفئات
- يفضل أن يكونوا من العملاء المحتملين
- تأكد من تنوع الأعمار والخلفيات التقنية

### الخطوة 2: إعداد البيئة التجريبية

```bash
# أنشئ رابط اختبار خاص
https://beta.ibpharmacy.com

# أضف علامة "Beta" في الواجهة
```

### الخطوة 3: توزيع الرابط

```
أرسل لهم:
- رابط الموقع
- قائمة بالميزات المطلوب اختبارها
- نموذج ملاحظات
- رقم WhatsApp للدعم
```

### الخطوة 4: جمع الملاحظات

```bash
# استخدم BetaFeedbackWidget المدمج
# أو نموذج Google Forms
# أو استطلاع مباشر عبر WhatsApp
```

### الخطوة 5: التحسينات

```bash
# حلل الملاحظات
# صنفها حسب الأولوية
# طبق التحسينات
# أعد الاختبار
```

---

## قائمة التحقق النهائية

### قبل الإطلاق (2 أسبوع)
- [ ] تم شراء اسم النطاق
- [ ] تم إعداد DNS Records
- [ ] تم اختبار جميع الخدمات الخارجية
- [ ] تم ملء جميع مفاتيح API
- [ ] تم استيراد قائمة الأدوية
- [ ] تم اختبار عملية الدفع
- [ ] تم اختبار الإشعارات
- [ ] تم اختبار الخرائط

### أثناء الاختبار التجريبي (1 أسبوع)
- [ ] تم اختيار المختبرين
- [ ] تم توزيع رابط الاختبار
- [ ] تم جمع الملاحظات
- [ ] تم تصحيح الأخطاء الحرجة
- [ ] تم تحسين الأداء

### قبل الإطلاق النهائي (يوم واحد)
- [ ] تم تفعيل HTTPS
- [ ] تم اختبار الموقع على جميع المتصفحات
- [ ] تم اختبار الموقع على الهاتف
- [ ] تم إعداد نظام المراقبة
- [ ] تم إعداد نظام النسخ الاحتياطية
- [ ] تم إعداد فريق الدعم الفني
- [ ] تم إعداد خطة الطوارئ

### بعد الإطلاق (يومياً)
- [ ] مراقبة الأداء
- [ ] الرد على استفسارات العملاء
- [ ] تتبع الأخطاء والمشاكل
- [ ] تحديث السجلات

---

## الدعم والمساعدة

### في حالة المشاكل:

1. **تحقق من السجلات:** `docker-compose logs -f`
2. **تحقق من الحالة:** `docker-compose ps`
3. **أعد تشغيل الخدمة:** `docker-compose restart`
4. **تواصل مع الدعم الفني**

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.8
**الحالة:** ✅ جاهز للإطلاق التجاري الفعلي الفوري

