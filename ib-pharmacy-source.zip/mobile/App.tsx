import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import { I18nManager } from 'react-native';

// Set RTL for Arabic
I18nManager.forceRTL(true);

// Screens
import HomeScreen from './screens/HomeScreen';
import CatalogScreen from './screens/CatalogScreen';
import MedicineDetailScreen from './screens/MedicineDetailScreen';
import CartScreen from './screens/CartScreen';
import OrdersScreen from './screens/OrdersScreen';
import DeliveryTrackingScreen from './screens/DeliveryTrackingScreen';
import LoyaltyScreen from './screens/LoyaltyScreen';
import ProfileScreen from './screens/ProfileScreen';
import PrescriptionScanScreen from './screens/PrescriptionScanScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

function HomeStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: true,
        headerTitleAlign: 'center',
        headerStyle: {
          backgroundColor: '#2563eb',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      }}
    >
      <Stack.Screen
        name="HomeMain"
        component={HomeScreen}
        options={{ title: 'صيدلية إب الرقمية' }}
      />
      <Stack.Screen
        name="MedicineDetail"
        component={MedicineDetailScreen}
        options={{ title: 'تفاصيل الدواء' }}
      />
      <Stack.Screen
        name="PrescriptionScan"
        component={PrescriptionScanScreen}
        options={{ title: 'مسح الروشتة' }}
      />
    </Stack.Navigator>
  );
}

function CatalogStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: true,
        headerTitleAlign: 'center',
        headerStyle: {
          backgroundColor: '#2563eb',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      }}
    >
      <Stack.Screen
        name="CatalogMain"
        component={CatalogScreen}
        options={{ title: 'كتالوج الأدوية' }}
      />
      <Stack.Screen
        name="MedicineDetail"
        component={MedicineDetailScreen}
        options={{ title: 'تفاصيل الدواء' }}
      />
    </Stack.Navigator>
  );
}

function OrdersStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: true,
        headerTitleAlign: 'center',
        headerStyle: {
          backgroundColor: '#2563eb',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      }}
    >
      <Stack.Screen
        name="OrdersMain"
        component={OrdersScreen}
        options={{ title: 'طلباتي' }}
      />
      <Stack.Screen
        name="DeliveryTracking"
        component={DeliveryTrackingScreen}
        options={{ title: 'تتبع الطلب' }}
      />
    </Stack.Navigator>
  );
}

function ProfileStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: true,
        headerTitleAlign: 'center',
        headerStyle: {
          backgroundColor: '#2563eb',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      }}
    >
      <Stack.Screen
        name="ProfileMain"
        component={ProfileScreen}
        options={{ title: 'حسابي' }}
      />
      <Stack.Screen
        name="Loyalty"
        component={LoyaltyScreen}
        options={{ title: 'برنامج الولاء' }}
      />
    </Stack.Navigator>
  );
}

export default function App() {
  const [locationPermission, setLocationPermission] = useState<boolean>(false);
  const [notificationPermission, setNotificationPermission] = useState<boolean>(false);

  useEffect(() => {
    // Request location permission
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      setLocationPermission(status === 'granted');
    })();

    // Request notification permission
    (async () => {
      const { status } = await Notifications.requestPermissionsAsync();
      setNotificationPermission(status === 'granted');
    })();

    // Listen for notifications
    const subscription = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        console.log('Notification tapped:', response.notification);
      }
    );

    return () => subscription.remove();
  }, []);

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#2563eb',
          tabBarInactiveTintColor: '#9ca3af',
          tabBarStyle: {
            backgroundColor: '#ffffff',
            borderTopColor: '#e5e7eb',
            borderTopWidth: 1,
          },
        }}
      >
        <Tab.Screen
          name="Home"
          component={HomeStack}
          options={{
            title: 'الرئيسية',
            tabBarLabel: 'الرئيسية',
            tabBarIcon: ({ color }) => (
              <Text style={{ fontSize: 20 }}>🏠</Text>
            ),
          }}
        />
        <Tab.Screen
          name="Catalog"
          component={CatalogStack}
          options={{
            title: 'الكتالوج',
            tabBarLabel: 'الأدوية',
            tabBarIcon: ({ color }) => (
              <Text style={{ fontSize: 20 }}>💊</Text>
            ),
          }}
        />
        <Tab.Screen
          name="Cart"
          component={CartScreen}
          options={{
            title: 'السلة',
            tabBarLabel: 'السلة',
            tabBarIcon: ({ color }) => (
              <Text style={{ fontSize: 20 }}>🛒</Text>
            ),
          }}
        />
        <Tab.Screen
          name="Orders"
          component={OrdersStack}
          options={{
            title: 'الطلبات',
            tabBarLabel: 'طلباتي',
            tabBarIcon: ({ color }) => (
              <Text style={{ fontSize: 20 }}>📦</Text>
            ),
          }}
        />
        <Tab.Screen
          name="Profile"
          component={ProfileStack}
          options={{
            title: 'الملف الشخصي',
            tabBarLabel: 'حسابي',
            tabBarIcon: ({ color }) => (
              <Text style={{ fontSize: 20 }}>👤</Text>
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

import { Text } from 'react-native';
