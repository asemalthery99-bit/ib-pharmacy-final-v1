import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export interface CartItem {
  medicineId: number;
  quantity: number;
  medicineName?: string;
  medicinePrice?: string;
}

interface CartContextType {
  items: CartItem[];
  isLoading: boolean;
  addToCart: (medicineId: number, quantity?: number) => Promise<void>;
  removeFromCart: (medicineId: number) => Promise<void>;
  updateQuantity: (medicineId: number, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  getTotalPrice: () => number;
  getTotalItems: () => number;
  getCartItem: (medicineId: number) => CartItem | undefined;
  refetch: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch cart from API
  const { data: cartData, refetch: refetchCart } = trpc.cart.getCart.useQuery(
    undefined,
    {
      enabled: !!user,
      staleTime: 1000 * 60 * 5, // 5 minutes
    }
  );

  // Update local items when cart data changes
  useEffect(() => {
    if (cartData) {
      setItems(cartData);
    }
  }, [cartData]);

  // Mutations
  const addItemMutation = trpc.cart.addItem.useMutation();
  const updateItemMutation = trpc.cart.updateItem.useMutation();
  const removeItemMutation = trpc.cart.removeItem.useMutation();
  const clearCartMutation = trpc.cart.clear.useMutation();

  const addToCart = useCallback(
    async (medicineId: number, quantity: number = 1) => {
      if (!user) {
        throw new Error("User must be logged in to add items to cart");
      }

      setIsLoading(true);
      try {
        await addItemMutation.mutateAsync({
          medicineId,
          quantity,
        });
        await refetchCart();
      } catch (error) {
        console.error("Failed to add item to cart:", error);
        throw error;
      } finally {
        setIsLoading(false);
      }
    },
    [user, addItemMutation, refetchCart]
  );

  const removeFromCart = useCallback(
    async (medicineId: number) => {
      if (!user) {
        throw new Error("User must be logged in to remove items from cart");
      }

      setIsLoading(true);
      try {
        await removeItemMutation.mutateAsync({ medicineId });
        await refetchCart();
      } catch (error) {
        console.error("Failed to remove item from cart:", error);
        throw error;
      } finally {
        setIsLoading(false);
      }
    },
    [user, removeItemMutation, refetchCart]
  );

  const updateQuantity = useCallback(
    async (medicineId: number, quantity: number) => {
      if (!user) {
        throw new Error("User must be logged in to update cart");
      }

      if (quantity <= 0) {
        await removeFromCart(medicineId);
        return;
      }

      setIsLoading(true);
      try {
        await updateItemMutation.mutateAsync({
          medicineId,
          quantity,
        });
        await refetchCart();
      } catch (error) {
        console.error("Failed to update item quantity:", error);
        throw error;
      } finally {
        setIsLoading(false);
      }
    },
    [user, updateItemMutation, removeFromCart, refetchCart]
  );

  const clearCart = useCallback(async () => {
    if (!user) {
      throw new Error("User must be logged in to clear cart");
    }

    setIsLoading(true);
    try {
      await clearCartMutation.mutateAsync();
      await refetchCart();
    } catch (error) {
      console.error("Failed to clear cart:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [user, clearCartMutation, refetchCart]);

  const getTotalPrice = useCallback(() => {
    return items.reduce((total, item) => {
      const price = parseFloat(item.medicinePrice || "0");
      return total + price * item.quantity;
    }, 0);
  }, [items]);

  const getTotalItems = useCallback(() => {
    return items.reduce((total, item) => total + item.quantity, 0);
  }, [items]);

  const getCartItem = useCallback(
    (medicineId: number) => {
      return items.find((item) => item.medicineId === medicineId);
    },
    [items]
  );

  const value: CartContextType = {
    items,
    isLoading,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getTotalPrice,
    getTotalItems,
    getCartItem,
    refetch: refetchCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
