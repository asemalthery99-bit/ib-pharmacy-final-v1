import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

/**
 * Loyalty Program Router
 * Provides endpoints for managing customer loyalty points and rewards
 */
export const loyaltyRouter = router({
  // ============ GET USER LOYALTY STATS ============
  getUserLoyaltyStats: protectedProcedure.query(async ({ ctx }) => {
    try {
      // In a real implementation, you would fetch from loyalty table
      // For now, returning mock data
      const loyaltyPoints = Math.floor(Math.random() * 5000);
      const tier = loyaltyPoints >= 1000 ? "platinum" : loyaltyPoints >= 500 ? "gold" : loyaltyPoints >= 100 ? "silver" : "bronze";

      return {
        userId: ctx.user.id,
        totalPoints: loyaltyPoints,
        availablePoints: loyaltyPoints,
        tier,
        tierName: {
          bronze: "برونزي",
          silver: "فضي",
          gold: "ذهبي",
          platinum: "بلاتيني",
        }[tier],
        nextTierPoints: tier === "platinum" ? 0 : { bronze: 100, silver: 500, gold: 1000 }[tier],
        pointsToNextTier: tier === "platinum" ? 0 : ({ bronze: 100, silver: 500, gold: 1000 }[tier] || 0) - loyaltyPoints,
        rewardsRedeemed: Math.floor(Math.random() * 10),
        memberSince: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000), // 1 year ago
      };
    } catch (error) {
      console.error("[Loyalty] Error fetching loyalty stats:", error);
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch loyalty stats" });
    }
  }),

  // ============ GET AVAILABLE REWARDS ============
  getAvailableRewards: protectedProcedure.query(async () => {
    try {
      return [
        {
          id: 1,
          name: "خصم 10% على الطلب التالي",
          arabicName: "خصم 10% على الطلب التالي",
          pointsRequired: 100,
          description: "احصل على خصم 10% على أي طلب",
          icon: "gift",
          category: "discount",
        },
        {
          id: 2,
          name: "توصيل مجاني",
          arabicName: "توصيل مجاني",
          pointsRequired: 250,
          description: "توصيل مجاني لأي طلب",
          icon: "truck",
          category: "delivery",
        },
        {
          id: 3,
          name: "خصم 20% على الطلب التالي",
          arabicName: "خصم 20% على الطلب التالي",
          pointsRequired: 500,
          description: "احصل على خصم 20% على أي طلب",
          icon: "gift",
          category: "discount",
        },
        {
          id: 4,
          name: "هدية خاصة",
          arabicName: "هدية خاصة",
          pointsRequired: 1000,
          description: "احصل على هدية خاصة من الصيدلية",
          icon: "star",
          category: "special",
        },
      ];
    } catch (error) {
      console.error("[Loyalty] Error fetching rewards:", error);
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch rewards" });
    }
  }),

  // ============ REDEEM REWARD ============
  redeemReward: protectedProcedure
    .input(z.object({
      rewardId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // In a real implementation, you would:
        // 1. Check if user has enough points
        // 2. Deduct points from user account
        // 3. Create a reward redemption record
        // 4. Send notification to user

        return {
          success: true,
          message: "Reward redeemed successfully",
          redemption: {
            rewardId: input.rewardId,
            userId: ctx.user.id,
            redeemedAt: new Date(),
            code: `REWARD-${Date.now()}`,
            expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
          },
        };
      } catch (error) {
        console.error("[Loyalty] Error redeeming reward:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to redeem reward" });
      }
    }),

  // ============ GET LOYALTY HISTORY ============
  getLoyaltyHistory: protectedProcedure
    .input(z.object({
      limit: z.number().default(20),
      offset: z.number().default(0),
    }))
    .query(async ({ ctx, input }) => {
      try {
        // In a real implementation, you would fetch from loyalty history table
        return {
          history: [
            {
              id: 1,
              type: "purchase",
              description: "شراء أدوية",
              points: 50,
              date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
            },
            {
              id: 2,
              type: "reward_redeemed",
              description: "استرجاع مكافأة - خصم 10%",
              points: -100,
              date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
            },
            {
              id: 3,
              type: "bonus",
              description: "مكافأة عيد ميلاد",
              points: 25,
              date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
            },
          ],
          total: 3,
          limit: input.limit,
          offset: input.offset,
        };
      } catch (error) {
        console.error("[Loyalty] Error fetching history:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch history" });
      }
    }),

  // ============ GET TIER BENEFITS ============
  getTierBenefits: protectedProcedure.query(async () => {
    try {
      return {
        tiers: [
          {
            tier: "bronze",
            name: "برونزي",
            pointsRequired: 0,
            benefits: [
              "1 نقطة لكل دولار",
              "الوصول إلى المكافآت الأساسية",
            ],
          },
          {
            tier: "silver",
            name: "فضي",
            pointsRequired: 100,
            benefits: [
              "1.25 نقطة لكل دولار",
              "خصم 5% على جميع الطلبات",
              "توصيل مجاني على الطلبات فوق 50 دولار",
              "أولوية في خدمة العملاء",
            ],
          },
          {
            tier: "gold",
            name: "ذهبي",
            pointsRequired: 500,
            benefits: [
              "1.5 نقطة لكل دولار",
              "خصم 10% على جميع الطلبات",
              "توصيل مجاني على جميع الطلبات",
              "أولوية عالية في خدمة العملاء",
              "عروض خاصة حصرية",
            ],
          },
          {
            tier: "platinum",
            name: "بلاتيني",
            pointsRequired: 1000,
            benefits: [
              "2 نقطة لكل دولار",
              "خصم 15% على جميع الطلبات",
              "توصيل مجاني على جميع الطلبات",
              "أولوية قصوى في خدمة العملاء",
              "عروض خاصة حصرية",
              "هدايا شهرية",
              "استشارة صيدلانية مجانية",
            ],
          },
        ],
      };
    } catch (error) {
      console.error("[Loyalty] Error fetching tier benefits:", error);
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch tier benefits" });
    }
  }),
});
