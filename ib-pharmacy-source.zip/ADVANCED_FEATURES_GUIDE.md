# دليل الميزات المتقدمة - الإصدار 3.5
## صيدلية إب الرقمية - منصة ذكية ولوجستية متكاملة

---

## نظرة عامة

تم إضافة طبقة جديدة من الذكاء الاصطناعي والعمليات اللوجستية المتقدمة التي تحول الصيدلية إلى منصة ذكية قادرة على التنبؤ والتوصية والتوسع عالمياً.

---

## 1. الذكاء الاصطناعي المتقدم (Advanced AI)

### 1.1 نظام التنبؤ بالمخزون (Inventory Prediction)

**الملف:** `server/services/advancedAI.ts`

#### الميزات الرئيسية

```typescript
// التنبؤ بمستويات المخزون
const predictions = await predictInventoryLevels(
  medicines,
  salesHistory,
  30 // أيام المتنبأ بها
);
```

**النتائج:**
- 📊 **التنبؤ الدقيق:** حساب عدد الأيام المتبقية قبل نفاد المخزون
- 🎯 **مستويات المخاطر:** تصنيف (منخفض، متوسط، مرتفع، حرج)
- 📈 **الموسمية:** تطبيق عوامل الموسمية (مثل أدوية الحساسية في الربيع)
- 🔄 **الاقتراحات التلقائية:** توصيات بكميات إعادة الطلب

#### مثال عملي

```typescript
const medicines = [
  {
    id: 'MED-001',
    name: 'بنادول',
    currentStock: 100,
    monthlyConsumption: 50,
    seasonalDemand: {
      1: 1.2, // يناير: طلب أعلى 20%
      2: 1.1,
      3: 1.3, // مارس: موسم الإنفلونزا
      // ...
    },
  },
];

const predictions = await predictInventoryLevels(medicines, salesHistory);

// النتيجة:
// {
//   medicineId: 'MED-001',
//   medicineName: 'بنادول',
//   currentStock: 100,
//   predictedConsumption: 60,
//   daysUntilStockout: 50,
//   riskLevel: 'low',
//   recommendation: '✅ آمن: بنادول متوفر بكميات كافية',
//   reorderQuantity: 100,
//   reorderDate: Date(في 7 أيام),
//   confidence: 0.92
// }
```

#### الخوارزميات المستخدمة

1. **المتوسط المتحرك (Moving Average):**
   ```
   الاستهلاك المتوقع = متوسط الـ 30 يوم الأخيرة × عامل الموسمية
   ```

2. **تعديل الموسمية:**
   ```
   الاستهلاك المعدل = الاستهلاك الأساسي × معامل الموسم
   ```

3. **حساب يوم النفاد:**
   ```
   أيام_النفاد = المخزون_الحالي ÷ الاستهلاك_اليومي_المتوقع
   ```

### 1.2 نظام التوصية الذكي (Recommendation Engine)

**الميزات:**
- 🎁 **التوصيات المكملة:** اقتراح منتجات تكمل الشراء الحالي
- 📊 **زيادة قيمة الطلب:** توقع زيادة 15-35% في متوسط قيمة الطلب
- 🧠 **التعلم الذكي:** تحسين التوصيات بناءً على سلوك العميل

#### أمثلة التوصيات

```typescript
// عند شراء خافض الحرارة، يُنصح بـ:
const recommendations = [
  {
    name: 'فيتامين C',
    reason: 'يُنصح به عادة مع خافض الحرارة',
    expectedIncrease: 22, // 22% زيادة في قيمة الطلب
  },
  {
    name: 'شراب السعال',
    reason: 'يُنصح به عادة مع خافض الحرارة',
    expectedIncrease: 18,
  },
  {
    name: 'مسكن الألم',
    reason: 'يُنصح به عادة مع خافض الحرارة',
    expectedIncrease: 20,
  },
];
```

#### خريطة المنتجات المكملة

| المنتج الأساسي | المنتجات الموصى بها | نسبة الزيادة |
|---|---|---|
| خافض الحرارة | فيتامين C، شراب السعال | 15-35% |
| مسكن الألم | فيتامين C، كريم مسكن | 18-28% |
| أنسولين | شرائط قياس، إبر حقن | 20-40% |
| أدوية الضغط | جهاز قياس، فيتامينات | 15-25% |

### 1.3 تحليل الاتجاهات الموسمية

```typescript
const trends = await analyzeSeasonalTrends(salesHistory, medicineId);

// النتيجة:
// {
//   trend: 'increasing', // أم 'decreasing' أم 'stable'
//   seasonalPattern: {
//     'يناير': 1.2,
//     'فبراير': 1.1,
//     'مارس': 1.3,
//     // ...
//   },
//   predictedDemandNextMonth: 75,
//   confidence: 0.88
// }
```

---

## 2. نظام الاشتراكات (Subscription System)

### 2.1 الاشتراكات للأمراض المزمنة

**الملف:** `server/services/subscriptionService.ts`

#### الميزات الرئيسية

- 💊 **طلبات متكررة تلقائية:** للسكري، الضغط، وأمراض مزمنة أخرى
- 📅 **جدولة ذكية:** توصيل في نفس التاريخ كل شهر
- 🔔 **تذكيرات ذكية:** قبل انتهاء المخزون بأسبوع
- ⏸️ **إيقاف مؤقت:** إمكانية إيقاف الاشتراك مؤقتاً دون إلغاء

#### إنشاء اشتراك

```typescript
const subscription = await createSubscription(
  userId: 'USER-001',
  medicineId: 'MED-001',
  medicineName: 'أنسولين',
  quantity: 1,
  frequency: 'weekly' // أو 'biweekly', 'monthly', 'quarterly');

// النتيجة:
// {
//   id: 'SUB-001',
//   userId: 'USER-001',
//   medicineId: 'MED-001',
//   medicineName: 'أنسولين',
//   quantity: 1,
//   frequency: 'weekly',
//   startDate: Date.now(),
//   nextDeliveryDate: Date(بعد 7 أيام),
//   status: 'active',
//   autoRenew: true,
//   createdAt: Date.now()
// }
```

#### ملف المريض المزمن

```typescript
const profile = await createChronicDiseaseProfile(
  userId: 'USER-001',
  diseases: [
    {
      name: 'السكري من النوع الثاني',
      diagnosisDate: new Date('2020-01-15'),
      medications: ['أنسولين', 'ميتفورمين'],
    },
    {
      name: 'ارتفاع ضغط الدم',
      diagnosisDate: new Date('2018-06-20'),
      medications: ['ليسينوبريل', 'أملوديبين'],
    },
  ],
  allergies: ['البنسلين', 'الأسبرين']
);
```

#### التوصيات التلقائية

```typescript
const recommendations = await getRecommendedSubscriptions(userId);

// النتيجة:
// [
//   {
//     id: 'SUB-REC-001',
//     medicineName: 'أنسولين',
//     frequency: 'monthly',
//     notes: 'موصى به لـ السكري من النوع الثاني'
//   },
//   {
//     id: 'SUB-REC-002',
//     medicineName: 'ليسينوبريل',
//     frequency: 'monthly',
//     notes: 'موصى به لـ ارتفاع ضغط الدم'
//   }
// ]
```

### 2.2 معالجة الاشتراكات التلقائية

```typescript
// يتم تشغيل هذا يومياً (cron job)
const result = await processAutomaticSubscriptionOrders();

// النتيجة:
// {
//   processed: 45,
//   failed: 2,
//   errors: ['Failed to process subscription SUB-123']
// }
```

### 2.3 إحصائيات الاشتراك

```typescript
const stats = await getSubscriptionStats(userId);

// النتيجة:
// {
//   totalSubscriptions: 3,
//   activeSubscriptions: 2,
//   pausedSubscriptions: 1,
//   totalMonthlySpend: 250, // USD
//   nextDeliveryDate: Date(غداً)
// }
```

---

## 3. الشحن الدولي (International Shipping)

### 3.1 الربط مع شركات الشحن

**الملف:** `server/services/internationalShipping.ts`

#### الشركات المدعومة

| الشركة | الدول المدعومة | السرعة | التكلفة |
|---|---|---|---|
| **Aramex** | 150+ دولة | 5-7 أيام | متوسطة |
| **DHL** | 220+ دولة | 2-4 أيام | عالية |
| **FedEx** | 220+ دولة | 1-3 أيام | عالية جداً |
| **UPS** | 220+ دولة | 2-5 أيام | عالية |

#### الحصول على عروض الأسعار

```typescript
const quotes = await getShippingQuotes(
  destination: {
    country: 'Saudi Arabia',
    city: 'Riyadh',
    postalCode: '12345'
  },
  weight: 2, // kg
  dimensions: {
    length: 30,
    width: 20,
    height: 10 // cm
  },
  serviceType: 'express');

// النتيجة:
// [
//   {
//     providerName: 'DHL',
//     estimatedDays: 2,
//     cost: 125,
//     currency: 'USD',
//     serviceType: 'express'
//   },
//   {
//     providerName: 'Aramex',
//     estimatedDays: 5,
//     cost: 95,
//     currency: 'USD',
//     serviceType: 'express'
//   },
//   // ...
// ]
```

#### إنشاء شحنة دولية

```typescript
const shipment = await createInternationalShipment(
  orderId: 'ORD-001',
  provider: 'dhl',
  destination: {
    country: 'Saudi Arabia',
    city: 'Riyadh',
    address: 'King Fahd Road, Building 123',
    postalCode: '12345',
    recipientName: 'محمد علي',
    recipientPhone: '+966501234567'
  },
  items: [
    {
      description: 'أنسولين 100 وحدة',
      quantity: 2,
      value: 50
    }
  ],
  weight: 2,
  dimensions: { length: 30, width: 20, height: 10 },
  cost: 125
);

// النتيجة:
// {
//   id: 'SHIP-001',
//   orderId: 'ORD-001',
//   provider: 'dhl',
//   trackingNumber: 'DHL1234567890ABC',
//   status: 'pending',
//   estimatedDeliveryDate: Date(بعد يومين),
//   cost: 125,
//   currency: 'USD'
// }
```

#### تتبع الشحنة

```typescript
const tracking = await trackInternationalShipment(
  'DHL1234567890ABC',
  'dhl');

// النتيجة:
// {
//   status: 'in_transit',
//   lastUpdate: Date.now(),
//   location: 'Cairo, Egypt',
//   estimatedDelivery: Date(غداً),
//   events: [
//     {
//       date: Date(أمس),
//       status: 'picked_up',
//       location: 'Ibb, Yemen',
//       description: 'تم استلام الطرد من المرسل'
//     },
//     {
//       date: Date(اليوم),
//       status: 'in_transit',
//       location: 'Cairo, Egypt',
//       description: 'وصل الطرد إلى مركز الفرز'
//     }
//   ]
// }
```

### 3.2 حساب تكاليف الشحن

```typescript
const cost = calculateShippingCost(
  destination: 'Saudi Arabia',
  weight: 2,
  serviceType: 'express');
// النتيجة: 95 USD
```

### 3.3 التحقق من صحة العنوان

```typescript
const validation = validateShippingAddress(
  address: 'King Fahd Road, Building 123',
  city: 'Riyadh',
  country: 'Saudi Arabia',
  postalCode: '12345');

// النتيجة:
// {
//   valid: true,
//   errors: []
// }
```

---

## 4. سيناريوهات الاستخدام المتكاملة

### سيناريو 1: مريض السكري المزمن

1. **الإعداد الأولي:**
   - ينشئ المريض ملف صحي يحتوي على تشخيصه
   - يختار الأدوية الموصى بها (أنسولين، ميتفورمين)

2. **الاشتراك التلقائي:**
   - ينشئ اشتراك شهري للأنسولين
   - يتلقى تذكيرات قبل انتهاء المخزون بأسبوع

3. **التنبؤ الذكي:**
   - النظام يتنبأ بزيادة الطلب في فصل الشتاء
   - يُنصح بزيادة كمية الطلب قبل الموسم

4. **التوصيات:**
   - عند شراء أنسولين، يُنصح بـ شرائط قياس السكر
   - زيادة متوسط قيمة الطلب بـ 25%

### سيناريو 2: عميل دولي

1. **البحث عن الأسعار:**
   - يختار عميل سعودي شراء أدوية من الصيدلية
   - يطلب عروض أسعار من 4 شركات شحن

2. **اختيار الشحن:**
   - يختار DHL (أسرع خيار)
   - يتلقى رقم تتبع فوري

3. **التتبع الحي:**
   - يتابع الشحنة من اليمن إلى السعودية
   - يتلقى إشعارات عند كل مرحلة

---

## 5. الدوال الأساسية

### خدمة الذكاء الاصطناعي المتقدم

```typescript
// التنبؤ
predictInventoryLevels(medicines, salesHistory, days)
analyzeSeasonalTrends(salesHistory, medicineId)
getSmartRecommendations(purchasedMedicines, allMedicines)
getAIInsights(predictions, recommendations)
predictMedicineDemand(historicalData, medicineId, days)
getBulkOrderRecommendations(predictions, budget)
```

### خدمة الاشتراكات

```typescript
// الاشتراكات
createSubscription(userId, medicineId, quantity, frequency)
getUserSubscriptions(userId)
updateSubscription(subscriptionId, updates)
cancelSubscription(subscriptionId, reason)
pauseSubscription(subscriptionId, pauseUntil)
resumeSubscription(subscriptionId)

// ملفات المرضى
createChronicDiseaseProfile(userId, diseases, allergies)
getChronicDiseaseProfile(userId)
getRecommendedSubscriptions(userId)

// المعالجة
processAutomaticSubscriptionOrders()
getSubscriptionStats(userId)
```

### خدمة الشحن الدولي

```typescript
// العروض والشحن
getShippingQuotes(destination, weight, dimensions, serviceType)
createInternationalShipment(orderId, provider, destination, items, weight, dimensions, cost)
trackInternationalShipment(trackingNumber, provider)
updateShipmentStatus(shipmentId, status, location)

// الحسابات والتحقق
calculateShippingCost(destination, weight, serviceType)
validateShippingAddress(address, city, country, postalCode)
getSupportedCountries()
```

---

## 6. أفضل الممارسات

### للمديرين
1. **مراقبة المخزون:** تفعيل التنبيهات للعناصر الحرجة
2. **تحليل الموسمية:** استعد للطلب الموسمي مسبقاً
3. **تحسين الأرباح:** استخدم التوصيات لزيادة قيمة الطلب

### للصيادلة
1. **الاشتراكات:** شجع المرضى المزمنين على الاشتراك
2. **التذكيرات:** استخدم التذكيرات الذكية لتحسين الالتزام
3. **الأمان:** تحقق من التعارضات الدوائية دائماً

### للعملاء
1. **الاشتراك:** وفر الوقت والمال بالاشتراك
2. **التوصيات:** استفد من المنتجات المكملة
3. **الشحن الدولي:** اختر أفضل خيار شحن لاحتياجاتك

---

## 7. الملفات المضافة

| الملف | الوصف |
|------|-------|
| `server/services/advancedAI.ts` | خدمة الذكاء الاصطناعي المتقدمة |
| `server/services/subscriptionService.ts` | خدمة الاشتراكات والأمراض المزمنة |
| `server/services/internationalShipping.ts` | خدمة الشحن الدولي |
| `ADVANCED_FEATURES_GUIDE.md` | هذا الدليل |

---

## 8. الخطوات التالية

### قصير الأجل
1. ✅ تطبيق معالجة الاشتراكات التلقائية (Cron Job)
2. ✅ ربط APIs الشحن الفعلية (Aramex, DHL)
3. ✅ اختبار نظام التنبؤ على بيانات حقيقية

### متوسط الأجل
1. تحسين نموذج التنبؤ باستخدام ML متقدم
2. إضافة نظام تقييمات ومراجعات محققة
3. تطوير لوحة تقارير ذكية للمديرين

### طويل الأجل
1. توسع إلى دول أخرى
2. إضافة ميزات AR للمنتجات
3. تطبيق نظام الدفع بالتقسيط

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.5
**الحالة:** ✅ مكتمل وجاهز للإطلاق
