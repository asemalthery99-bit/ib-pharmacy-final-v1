import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

/**
 * Ratings and Reviews Router
 * Provides endpoints for customers to rate medicines and services
 */
export const ratingsRouter = router({
  // ============ MEDICINE RATINGS ============
  rateMedicine: protectedProcedure
    .input(z.object({
      medicineId: z.number(),
      rating: z.number().min(1).max(5),
      review: z.string().max(500).optional(),
      title: z.string().max(100).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // In a real implementation, you would save this to a ratings table
        // For now, we'll return a success response
        return {
          success: true,
          message: "Rating submitted successfully",
          rating: {
            medicineId: input.medicineId,
            rating: input.rating,
            review: input.review,
            title: input.title,
            userId: ctx.user.id,
            createdAt: new Date(),
          },
        };
      } catch (error) {
        console.error("[Ratings] Error submitting rating:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to submit rating" });
      }
    }),

  // ============ GET MEDICINE RATINGS ============
  getMedicineRatings: protectedProcedure
    .input(z.object({
      medicineId: z.number(),
    }))
    .query(async ({ input }) => {
      try {
        // In a real implementation, you would fetch from ratings table
        return {
          medicineId: input.medicineId,
          averageRating: 4.5,
          totalRatings: 12,
          ratings: [
            {
              id: 1,
              userId: 1,
              userName: "أحمد محمد",
              rating: 5,
              title: "منتج ممتاز",
              review: "المنتج جيد جداً والخدمة سريعة",
              createdAt: new Date(),
            },
          ],
        };
      } catch (error) {
        console.error("[Ratings] Error fetching ratings:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch ratings" });
      }
    }),

  // ============ SERVICE RATING ============
  rateService: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      rating: z.number().min(1).max(5),
      review: z.string().max(500).optional(),
      deliveryRating: z.number().min(1).max(5).optional(),
      pharmacistRating: z.number().min(1).max(5).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        return {
          success: true,
          message: "Service rating submitted successfully",
          rating: {
            orderId: input.orderId,
            overallRating: input.rating,
            deliveryRating: input.deliveryRating,
            pharmacistRating: input.pharmacistRating,
            review: input.review,
            userId: ctx.user.id,
            createdAt: new Date(),
          },
        };
      } catch (error) {
        console.error("[Ratings] Error submitting service rating:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to submit rating" });
      }
    }),
});
