/**
 * Loyalty Program Service
 * Manages customer loyalty points, rewards, and redemption
 */

export interface LoyaltyAccount {
  userId: string;
  totalPoints: number;
  tier: "bronze" | "silver" | "gold" | "platinum";
  totalSpent: number;
  joinDate: Date;
  lastActivityDate: Date;
}

export interface PointsTransaction {
  id: string;
  userId: string;
  points: number;
  type: "earn" | "redeem" | "bonus" | "adjustment";
  description: string;
  orderId?: string;
  createdAt: Date;
}

export interface Reward {
  id: string;
  name: string;
  description: string;
  pointsCost: number;
  discount: number; // percentage
  expiryDays: number;
  category: "discount" | "free_item" | "shipping" | "special";
  isActive: boolean;
}

/**
 * Loyalty Program Configuration
 */
const LOYALTY_CONFIG = {
  pointsPerRiyal: 1, // 1 point per 1 riyal spent
  tierThresholds: {
    bronze: 0,
    silver: 500,
    gold: 1500,
    platinum: 3000,
  },
  tierBenefits: {
    bronze: {
      pointsMultiplier: 1.0,
      birthdayBonus: 50,
      referralBonus: 100,
    },
    silver: {
      pointsMultiplier: 1.1,
      birthdayBonus: 100,
      referralBonus: 150,
    },
    gold: {
      pointsMultiplier: 1.25,
      birthdayBonus: 200,
      referralBonus: 250,
    },
    platinum: {
      pointsMultiplier: 1.5,
      birthdayBonus: 500,
      referralBonus: 500,
    },
  },
};

/**
 * Available rewards catalog
 */
const REWARDS_CATALOG: Reward[] = [
  {
    id: "RWD-001",
    name: "خصم 10% على الشراء التالي",
    description: "احصل على خصم 10% على أي شراء",
    pointsCost: 100,
    discount: 10,
    expiryDays: 30,
    category: "discount",
    isActive: true,
  },
  {
    id: "RWD-002",
    name: "خصم 20% على الشراء التالي",
    description: "احصل على خصم 20% على أي شراء",
    pointsCost: 250,
    discount: 20,
    expiryDays: 30,
    category: "discount",
    isActive: true,
  },
  {
    id: "RWD-003",
    name: "توصيل مجاني",
    description: "احصل على توصيل مجاني لطلبك القادم",
    pointsCost: 150,
    discount: 0,
    expiryDays: 14,
    category: "shipping",
    isActive: true,
  },
  {
    id: "RWD-004",
    name: "منتج مجاني (بنادول 500 ملغ)",
    description: "احصل على عبوة بنادول 500 ملغ مجاناً",
    pointsCost: 200,
    discount: 0,
    expiryDays: 30,
    category: "free_item",
    isActive: true,
  },
  {
    id: "RWD-005",
    name: "خصم 30% على الشراء التالي",
    description: "احصل على خصم 30% على أي شراء",
    pointsCost: 500,
    discount: 30,
    expiryDays: 30,
    category: "discount",
    isActive: true,
  },
  {
    id: "RWD-006",
    name: "مكافأة خاصة - 500 نقطة إضافية",
    description: "احصل على 500 نقطة إضافية مجاناً",
    pointsCost: 300,
    discount: 0,
    expiryDays: 0,
    category: "special",
    isActive: true,
  },
];

/**
 * Calculate loyalty tier based on total spent
 */
export function calculateTier(totalSpent: number): LoyaltyAccount["tier"] {
  if (totalSpent >= LOYALTY_CONFIG.tierThresholds.platinum) return "platinum";
  if (totalSpent >= LOYALTY_CONFIG.tierThresholds.gold) return "gold";
  if (totalSpent >= LOYALTY_CONFIG.tierThresholds.silver) return "silver";
  return "bronze";
}

/**
 * Calculate points earned from purchase
 */
export function calculatePointsEarned(
  purchaseAmount: number,
  tier: LoyaltyAccount["tier"]
): number {
  const basePoints = Math.floor(purchaseAmount * LOYALTY_CONFIG.pointsPerRiyal);
  const multiplier = LOYALTY_CONFIG.tierBenefits[tier].pointsMultiplier;
  return Math.floor(basePoints * multiplier);
}

/**
 * Create loyalty account for new user
 */
export async function createLoyaltyAccount(userId: string): Promise<LoyaltyAccount> {
  const account: LoyaltyAccount = {
    userId,
    totalPoints: 0,
    tier: "bronze",
    totalSpent: 0,
    joinDate: new Date(),
    lastActivityDate: new Date(),
  };

  console.log("Loyalty account created:", account);
  return account;
}

/**
 * Add points to user account
 */
export async function addPoints(
  userId: string,
  points: number,
  type: PointsTransaction["type"],
  description: string,
  orderId?: string
): Promise<PointsTransaction> {
  const transaction: PointsTransaction = {
    id: `TXN-${Date.now()}`,
    userId,
    points,
    type,
    description,
    orderId,
    createdAt: new Date(),
  };

  console.log("Points added:", transaction);
  return transaction;
}

/**
 * Redeem reward
 */
export async function redeemReward(
  userId: string,
  rewardId: string
): Promise<{
  success: boolean;
  reward: Reward | null;
  remainingPoints: number;
  message: string;
}> {
  const reward = REWARDS_CATALOG.find((r) => r.id === rewardId);

  if (!reward) {
    return {
      success: false,
      reward: null,
      remainingPoints: 0,
      message: "المكافأة غير موجودة",
    };
  }

  // In production, check user's points balance
  const userPoints = 500; // Mock value

  if (userPoints < reward.pointsCost) {
    return {
      success: false,
      reward: null,
      remainingPoints: userPoints,
      message: `لا توجد نقاط كافية. تحتاج إلى ${reward.pointsCost} نقطة`,
    };
  }

  // Deduct points and create transaction
  const transaction: PointsTransaction = {
    id: `TXN-${Date.now()}`,
    userId,
    points: -reward.pointsCost,
    type: "redeem",
    description: `تم استبدال المكافأة: ${reward.name}`,
    createdAt: new Date(),
  };

  console.log("Reward redeemed:", transaction);

  return {
    success: true,
    reward,
    remainingPoints: userPoints - reward.pointsCost,
    message: `تم استبدال المكافأة بنجاح: ${reward.name}`,
  };
}

/**
 * Get user loyalty account
 */
export async function getLoyaltyAccount(userId: string): Promise<LoyaltyAccount> {
  // In production, fetch from database
  return {
    userId,
    totalPoints: 450,
    tier: "silver",
    totalSpent: 750,
    joinDate: new Date("2025-01-15"),
    lastActivityDate: new Date(),
  };
}

/**
 * Get points history
 */
export async function getPointsHistory(userId: string): Promise<PointsTransaction[]> {
  // In production, fetch from database
  const mockHistory: PointsTransaction[] = [
    {
      id: "TXN-001",
      userId,
      points: 150,
      type: "earn",
      description: "شراء أدوية بقيمة 150 ريال",
      orderId: "ORD-001",
      createdAt: new Date("2026-03-15"),
    },
    {
      id: "TXN-002",
      userId,
      points: -100,
      type: "redeem",
      description: "استبدال خصم 10%",
      createdAt: new Date("2026-03-10"),
    },
    {
      id: "TXN-003",
      userId,
      points: 200,
      type: "earn",
      description: "شراء أدوية بقيمة 200 ريال",
      orderId: "ORD-002",
      createdAt: new Date("2026-03-05"),
    },
    {
      id: "TXN-004",
      userId,
      points: 100,
      type: "bonus",
      description: "مكافأة الإحالة - صديق جديد",
      createdAt: new Date("2026-02-28"),
    },
  ];

  return mockHistory;
}

/**
 * Get available rewards for user
 */
export async function getAvailableRewards(userId: string): Promise<Reward[]> {
  // In production, filter based on user's points and tier
  return REWARDS_CATALOG.filter((r) => r.isActive);
}

/**
 * Apply referral bonus
 */
export async function applyReferralBonus(
  referrerId: string,
  newUserId: string
): Promise<PointsTransaction> {
  // Get referrer's tier for bonus amount
  const referrerAccount = await getLoyaltyAccount(referrerId);
  const bonusPoints =
    LOYALTY_CONFIG.tierBenefits[referrerAccount.tier].referralBonus;

  const transaction: PointsTransaction = {
    id: `TXN-${Date.now()}`,
    userId: referrerId,
    points: bonusPoints,
    type: "bonus",
    description: `مكافأة الإحالة - مستخدم جديد (${newUserId})`,
    createdAt: new Date(),
  };

  console.log("Referral bonus applied:", transaction);
  return transaction;
}

/**
 * Apply birthday bonus
 */
export async function applyBirthdayBonus(userId: string): Promise<PointsTransaction> {
  const account = await getLoyaltyAccount(userId);
  const bonusPoints = LOYALTY_CONFIG.tierBenefits[account.tier].birthdayBonus;

  const transaction: PointsTransaction = {
    id: `TXN-${Date.now()}`,
    userId,
    points: bonusPoints,
    type: "bonus",
    description: "مكافأة عيد الميلاد",
    createdAt: new Date(),
  };

  console.log("Birthday bonus applied:", transaction);
  return transaction;
}

/**
 * Get loyalty tier benefits
 */
export function getTierBenefits(tier: LoyaltyAccount["tier"]) {
  return LOYALTY_CONFIG.tierBenefits[tier];
}

/**
 * Get next tier requirements
 */
export function getNextTierRequirements(currentTier: LoyaltyAccount["tier"]): {
  nextTier: LoyaltyAccount["tier"] | null;
  requiredSpent: number;
  currentSpent: number;
  remainingSpent: number;
} {
  const tiers: LoyaltyAccount["tier"][] = ["bronze", "silver", "gold", "platinum"];
  const currentIndex = tiers.indexOf(currentTier);

  if (currentIndex === tiers.length - 1) {
    return {
      nextTier: null,
      requiredSpent: LOYALTY_CONFIG.tierThresholds.platinum,
      currentSpent: 0,
      remainingSpent: 0,
    };
  }

  const nextTier = tiers[currentIndex + 1];
  const requiredSpent = LOYALTY_CONFIG.tierThresholds[nextTier];

  return {
    nextTier,
    requiredSpent,
    currentSpent: 0, // In production, fetch from database
    remainingSpent: requiredSpent,
  };
}
