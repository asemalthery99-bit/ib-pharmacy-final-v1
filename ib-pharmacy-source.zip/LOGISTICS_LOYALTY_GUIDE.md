# دليل الجانب العملي واللوجستي والولاء
## صيدلية إب الرقمية - الإصدار 3.3

---

## نظرة عامة

تم إضافة نظامين متقدمين لتعزيز العمليات اللوجستية وزيادة ولاء العملاء:

1. **نظام إدارة التوصيل:** لتتبع الطلبات والسائقين في الوقت الفعلي
2. **برنامج الولاء:** لمكافأة العملاء المخلصين بنقاط وخصومات

---

## 1. نظام إدارة التوصيل (Delivery Management System)

### الملف: `server/services/deliveryManagement.ts`

### الميزات الرئيسية

#### 1.1 إدارة السائقين

**تسجيل سائق جديد:**
```typescript
const driver = await registerDriver({
  name: "محمد علي",
  phone: "967123456789",
  email: "driver@ibpharmacy.com",
  vehicle: "Toyota Corolla",
  licensePlate: "YM-1234",
  status: "active",
  latitude: 15.3694,
  longitude: 44.2039,
});
```

**معلومات السائق:**
- الاسم والبيانات الشخصية
- معلومات المركبة ولوحة الترخيص
- الموقع الحالي (GPS)
- التقييم والإحصائيات

#### 1.2 تتبع الطلبات

**حالات التوصيل:**
- `pending` - في انتظار السائق
- `assigned` - تم تعيين السائق
- `in_transit` - في الطريق
- `delivered` - تم التسليم
- `failed` - فشل التسليم

**تتبع فوري:**
```typescript
const tracking = await trackDelivery("DLV-001");
// {
//   status: "in_transit",
//   driverName: "محمد علي",
//   currentLocation: { lat: 15.3720, lng: 44.2070 },
//   estimatedArrival: Date,
//   distance: 2.5 // km
// }
```

#### 1.3 تعيين الطلبات للسائقين

**التعيين الذكي:**
```typescript
const assignment = await assignDeliveryToNearestDriver(
  "ORD-001",
  { lat: 15.3750, lng: 44.2100 }, // موقع العميل
  { lat: 15.3694, lng: 44.2039 }   // موقع الصيدلية
);
```

**الخوارزمية:**
- حساب المسافة بين الصيدلية والعميل
- اختيار أقرب سائق متاح
- تقدير وقت التوصيل

#### 1.4 حساب المسافة والوقت

**دالة Haversine:**
```typescript
const distance = calculateDistance(
  15.3694, 44.2039, // موقع البداية
  15.3750, 44.2100  // موقع النهاية
);
// النتيجة: المسافة بالكيلومترات
```

**تقدير الوقت:**
```typescript
const timeMinutes = estimateDeliveryTime(distance);
// بناءً على متوسط سرعة 30 كم/ساعة
```

### المكون: `DeliveryTracker`

**الملف:** `client/src/components/DeliveryTracker.tsx`

#### الميزات:
- عرض حالة التوصيل الحالية
- معلومات السائق (الاسم، التقييم، المركبة)
- الموقع على الخريطة
- الوقت المتبقي (عداد حي)
- خيارات الاتصال بالسائق
- تتبع خطوات التوصيل

#### الاستخدام:
```jsx
import DeliveryTracker from "@/components/DeliveryTracker";

<DeliveryTracker 
  deliveryInfo={{
    status: "in_transit",
    driverName: "محمد علي",
    driverPhone: "967123456789",
    driverRating: 4.9,
    vehicleInfo: "Toyota Corolla",
    licensePlate: "YM-1234",
    currentLocation: { lat: 15.3720, lng: 44.2070 },
    deliveryLocation: { lat: 15.3750, lng: 44.2100 },
    estimatedArrival: new Date(Date.now() + 20 * 60000),
    distance: 2.5,
    estimatedTime: 20,
  }}
/>
```

---

## 2. برنامج الولاء (Loyalty Program)

### الملف: `server/services/loyaltyProgram.ts`

### الميزات الرئيسية

#### 2.1 نظام المستويات

**المستويات الأربعة:**

| المستوى | الحد الأدنى للإنفاق | مضاعف النقاط | مكافأة عيد الميلاد | مكافأة الإحالة |
|--------|------------------|------------|-----------------|--------------|
| **برونزي** | 0 ريال | 1.0x | 50 نقطة | 100 نقطة |
| **فضي** | 500 ريال | 1.1x | 100 نقطة | 150 نقطة |
| **ذهبي** | 1500 ريال | 1.25x | 200 نقطة | 250 نقطة |
| **بلاتيني** | 3000 ريال | 1.5x | 500 نقطة | 500 نقطة |

#### 2.2 نظام النقاط

**كسب النقاط:**
```typescript
// 1 نقطة لكل ريال (مع مضاعف حسب المستوى)
const points = calculatePointsEarned(150, "silver");
// النتيجة: 165 نقطة (150 × 1.1)
```

**أنواع المعاملات:**
- `earn` - كسب نقاط من الشراء
- `redeem` - استبدال النقاط بمكافآت
- `bonus` - مكافآت خاصة (عيد ميلاد، إحالة)
- `adjustment` - تعديلات إدارية

#### 2.3 المكافآت المتاحة

**كتالوج المكافآت:**

| المكافأة | النقاط المطلوبة | الفائدة | الصلاحية |
|--------|-----------------|--------|---------|
| خصم 10% | 100 | 10% على الشراء | 30 يوم |
| خصم 20% | 250 | 20% على الشراء | 30 يوم |
| توصيل مجاني | 150 | توصيل مجاني | 14 يوم |
| منتج مجاني | 200 | بنادول 500 ملغ | 30 يوم |
| خصم 30% | 500 | 30% على الشراء | 30 يوم |
| 500 نقطة إضافية | 300 | 500 نقطة | فوري |

#### 2.4 استبدال المكافآت

```typescript
const result = await redeemReward("USER-001", "RWD-001");
// {
//   success: true,
//   reward: { ... },
//   remainingPoints: 350,
//   message: "تم استبدال المكافأة بنجاح"
// }
```

#### 2.5 برنامج الإحالة

**كيف يعمل:**
1. العميل يحصل على كود إحالة فريد
2. يشارك الكود مع أصدقائه
3. عند الشراء الأول للصديق، يحصل على مكافأة
4. المكافأة تختلف حسب مستوى العميل

```typescript
const bonus = await applyReferralBonus("USER-001", "USER-002");
// مكافأة تلقائية بناءً على مستوى المُحيل
```

### المكون: `LoyaltyDashboard`

**الملف:** `client/src/components/LoyaltyDashboard.tsx`

#### الميزات:
- عرض المستوى الحالي والمزايا
- عداد النقاط الحالية
- شريط التقدم نحو المستوى التالي
- كتالوج المكافآت
- معلومات المزايا حسب المستوى
- برنامج الإحالة مع كود فريد
- إحصائيات الإحالة

#### الاستخدام:
```jsx
import LoyaltyDashboard from "@/components/LoyaltyDashboard";

<LoyaltyDashboard 
  userId="USER-001"
  totalPoints={450}
  tier="silver"
  totalSpent={750}
/>
```

---

## 3. التكامل مع النظام الكامل

### في صفحة الطلبات:

```jsx
import DeliveryTracker from "@/components/DeliveryTracker";

// عرض تتبع التوصيل للطلب الحالي
<DeliveryTracker deliveryInfo={deliveryInfo} />
```

### في حساب المستخدم:

```jsx
import LoyaltyDashboard from "@/components/LoyaltyDashboard";

// عرض لوحة الولاء
<LoyaltyDashboard 
  userId={user.id}
  totalPoints={user.loyaltyPoints}
  tier={user.loyaltyTier}
  totalSpent={user.totalSpent}
/>
```

### في السلة:

```jsx
// عرض النقاط المكتسبة من هذا الشراء
const pointsEarned = calculatePointsEarned(cartTotal, userTier);
<p>ستحصل على {pointsEarned} نقطة من هذا الشراء</p>
```

---

## 4. الدوال الأساسية

### خدمة التوصيل

```typescript
// تسجيل سائق
registerDriver(driverData)

// تحديث موقع السائق
updateDriverLocation(driverId, latitude, longitude)

// تحديث حالة السائق
updateDriverStatus(driverId, status)

// تعيين طلب للسائق الأقرب
assignDeliveryToNearestDriver(orderId, customerLocation, pharmacyLocation)

// تحديث حالة التوصيل
updateDeliveryStatus(deliveryId, status)

// حساب المسافة
calculateDistance(lat1, lng1, lat2, lng2)

// تقدير وقت التوصيل
estimateDeliveryTime(distanceKm)

// تتبع التوصيل
trackDelivery(deliveryId)

// إحصائيات السائق
getDriverStats(driverId)

// الحصول على السائقين النشطين
getActiveDrivers()
```

### خدمة الولاء

```typescript
// حساب المستوى
calculateTier(totalSpent)

// حساب النقاط المكتسبة
calculatePointsEarned(purchaseAmount, tier)

// إنشاء حساب ولاء
createLoyaltyAccount(userId)

// إضافة نقاط
addPoints(userId, points, type, description, orderId)

// استبدال مكافأة
redeemReward(userId, rewardId)

// الحصول على حساب الولاء
getLoyaltyAccount(userId)

// سجل النقاط
getPointsHistory(userId)

// المكافآت المتاحة
getAvailableRewards(userId)

// مكافأة الإحالة
applyReferralBonus(referrerId, newUserId)

// مكافأة عيد الميلاد
applyBirthdayBonus(userId)

// مزايا المستوى
getTierBenefits(tier)

// متطلبات المستوى التالي
getNextTierRequirements(currentTier)
```

---

## 5. سيناريوهات الاستخدام

### سيناريو 1: عملية شراء كاملة

1. العميل يضع طلب بقيمة 150 ريال
2. يحصل على 165 نقطة (150 × 1.1 لأنه في مستوى فضي)
3. يتم تعيين السائق الأقرب
4. يمكن للعميل تتبع الطلب في الوقت الفعلي
5. عند التسليم، يتم تأكيد النقاط

### سيناريو 2: استبدال مكافأة

1. العميل لديه 450 نقطة
2. يختار خصم 20% (250 نقطة)
3. يتم خصم النقاط من حسابه
4. يحصل على كود الخصم
5. يستخدم الكود في الشراء التالي

### سيناريو 3: برنامج الإحالة

1. العميل يشارك كوده مع صديق
2. الصديق يشتري باستخدام الكود
3. العميل يحصل على 150 نقطة (حسب مستواه الفضي)
4. الصديق يحصل على مكافأة ترحيب (50 نقطة)

---

## 6. أفضل الممارسات

### للمتاجر
1. **تحديث معلومات السائقين:** تأكد من تحديث مواقع السائقين باستمرار
2. **مراقبة الأداء:** تابع إحصائيات السائقين والتقييمات
3. **تشجيع الولاء:** أرسل عروض خاصة للعملاء في مستويات أعلى

### للعملاء
1. **استخدام البرنامج:** اجمع النقاط من كل شراء
2. **الإحالة:** شارك الكود واحصل على مكافآت إضافية
3. **الترقية:** اسعَ للوصول إلى مستويات أعلى للحصول على مزايا أفضل

### للمطورين
1. **التكامل مع Google Maps:** أضف خريطة حقيقية لتتبع الموقع
2. **الإشعارات الفورية:** أرسل تنبيهات عند تحديث حالة التوصيل
3. **التقارير:** أنشئ تقارير مفصلة عن الأداء والولاء

---

## 7. الملفات المضافة والمعدلة

| الملف | النوع | الوصف |
|------|-------|-------|
| `server/services/deliveryManagement.ts` | جديد | خدمة إدارة التوصيل |
| `server/services/loyaltyProgram.ts` | جديد | خدمة برنامج الولاء |
| `client/src/components/DeliveryTracker.tsx` | جديد | مكون تتبع التوصيل |
| `client/src/components/LoyaltyDashboard.tsx` | جديد | لوحة الولاء |

---

## 8. الخطوات التالية

### قصير الأجل
1. ✅ ربط النظام بـ Google Maps API
2. ✅ إضافة إشعارات فورية (SMS, Push)
3. ✅ تطبيق نظام التقييمات للسائقين

### متوسط الأجل
1. تطبيق الهاتف المحمول مع GPS
2. نظام إدارة متقدم للسائقين
3. تقارير تفصيلية للمديرين

### طويل الأجل
1. تكامل مع خدمات الدفع المتقدمة
2. نظام الذكاء الاصطناعي لتحسين التوصيل
3. توسع إلى مدن أخرى

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.3
**الحالة:** ✅ مكتمل وجاهز للاستخدام
