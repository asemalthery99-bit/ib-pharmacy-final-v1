import { drizzle } from "drizzle-orm/mysql2";
import { medicines, inventory } from "../drizzle/schema.js";

const db = drizzle(process.env.DATABASE_URL);

const medicinesData = [
  {
    name: "Panadol Advance",
    arabicName: "بنادول أدفانس",
    category: "pain-relief",
    price: "1500",
    description: "Effective pain relief for headaches, toothaches, and fever.",
    arabicDescription: "مسكن فعال للآلام للصداع وآلام الأسنان والحمى.",
    dosage: "500mg - 1000mg every 4-6 hours",
    sideEffects: "Rare: Nausea, allergic reactions.",
    arabicSideEffects: "نادر: غثيان، ردود فعل تحسسية.",
    usage: "Swallow with water. Do not exceed 8 tablets in 24 hours.",
    arabicUsage: "يبلع مع الماء. لا تتجاوز 8 أقراص في 24 ساعة.",
    imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?q=80&w=800&auto=format&fit=crop",
  },
  {
    name: "Amoxicillin",
    arabicName: "أموكسيسيلين",
    category: "antibiotics",
    price: "3500",
    description: "Broad-spectrum antibiotic used to treat bacterial infections.",
    arabicDescription: "مضاد حيوي واسع الطيف يستخدم لعلاج العدوى البكتيرية.",
    dosage: "500mg three times daily",
    sideEffects: "Diarrhea, nausea, skin rash.",
    arabicSideEffects: "إسهال، غثيان، طفح جلدي.",
    usage: "Finish the entire course as prescribed by your doctor.",
    arabicUsage: "أكمل الجرعة كاملة كما وصفها الطبيب.",
    imageUrl: "https://images.unsplash.com/photo-1471864190281-ad5f9f33d70e?q=80&w=800&auto=format&fit=crop",
  },
  {
    name: "Vitamin C 1000mg",
    arabicName: "فيتامين سي 1000 ملجم",
    category: "vitamins",
    price: "2000",
    description: "Supports immune system health and provides antioxidant protection.",
    arabicDescription: "يدعم صحة جهاز المناعة ويوفر حماية مضادة للأكسدة.",
    dosage: "One tablet daily",
    sideEffects: "Stomach upset if taken in large doses.",
    arabicSideEffects: "اضطراب المعدة إذا تم تناوله بجرعات كبيرة.",
    usage: "Dissolve in a glass of water and drink.",
    arabicUsage: "يذاب في كوب من الماء ويشرب.",
    imageUrl: "https://images.unsplash.com/photo-1616671285410-0950be03714c?q=80&w=800&auto=format&fit=crop",
  },
  {
    name: "Metformin 500mg",
    arabicName: "ميتفورمين 500 ملجم",
    category: "chronic-diseases",
    price: "1200",
    description: "Used to control high blood sugar in people with type 2 diabetes.",
    arabicDescription: "يستخدم للسيطرة على ارتفاع نسبة السكر في الدم لدى مرضى السكري من النوع الثاني.",
    dosage: "500mg twice daily with meals",
    sideEffects: "Digestive issues, metallic taste in mouth.",
    arabicSideEffects: "مشاكل هضمية، طعم معدني في الفم.",
    usage: "Take with food to reduce stomach side effects.",
    arabicUsage: "يؤخذ مع الطعام لتقليل الآثار الجانبية للمعدة.",
    imageUrl: "https://images.unsplash.com/photo-1550572017-edd951b55104?q=80&w=800&auto=format&fit=crop",
  },
  {
    name: "La Roche-Posay Effaclar",
    arabicName: "لاروش بوزيه إيفاكلار",
    category: "skincare",
    price: "8500",
    description: "Gel cleanser for oily, acne-prone skin.",
    arabicDescription: "جل منظف للبشرة الدهنية والمعرضة لحب الشباب.",
    dosage: "Use twice daily",
    sideEffects: "Dryness if overused.",
    arabicSideEffects: "جفاف في حال الاستخدام المفرط.",
    usage: "Apply to wet face, massage gently, then rinse.",
    arabicUsage: "ضع على الوجه الرطب، دلك برفق، ثم اشطف.",
    imageUrl: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=800&auto=format&fit=crop",
  },
];

async function seed() {
  try {
    console.log("🌱 Starting database seed...");
    
    // Insert medicines
    for (const medicine of medicinesData) {
      const result = await db.insert(medicines).values(medicine);
      const medicineId = result[0].insertId;
      
      // Create inventory for each medicine
      await db.insert(inventory).values({
        medicineId,
        quantity: Math.floor(Math.random() * 100) + 20,
        minThreshold: 10,
        maxThreshold: 1000,
      });
      
      console.log(`✅ Added medicine: ${medicine.arabicName}`);
    }
    
    console.log("✅ Database seed completed successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Seed error:", error);
    process.exit(1);
  }
}

seed();
