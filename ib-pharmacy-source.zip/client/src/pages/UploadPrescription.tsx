import { useState, useRef } from "react";
import { Link } from "wouter";
import { Upload, FileImage, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { usePrescription } from "@/contexts/PrescriptionContext";
import { toast } from "sonner";

export default function UploadPrescription() {
  const { uploadPrescription } = usePrescription();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // التحقق من نوع الملف
    if (!file.type.startsWith("image/")) {
      toast.error("يرجى اختيار صورة فقط");
      return;
    }

    // التحقق من حجم الملف (5MB كحد أقصى)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("حجم الصورة يجب أن يكون أقل من 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!selectedImage) {
      toast.error("يرجى اختيار صورة الروشتة");
      return;
    }

    setIsUploading(true);
    
    // محاكاة تأخير الرفع
    setTimeout(() => {
      uploadPrescription(selectedImage, notes);
      setIsUploading(false);
      setUploadSuccess(true);
      setSelectedImage(null);
      setNotes("");
      toast.success("تم رفع الروشتة بنجاح! سيتم مراجعتها من قبل الصيدلي");
      
      // إعادة تعيين بعد 3 ثوانٍ
      setTimeout(() => {
        setUploadSuccess(false);
      }, 3000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-foreground mb-2">رفع الروشتة الطبية</h1>
          <p className="text-muted-foreground">
            قم برفع صورة روشتتك الطبية وسيقوم الصيدلي بمراجعتها وإرسال عرض سعر لك
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upload Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Upload Card */}
            <Card className="border-2 border-dashed border-primary/30 hover:border-primary transition">
              <CardContent className="p-8">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="cursor-pointer"
                >
                  {selectedImage ? (
                    <div className="space-y-4">
                      <div className="relative rounded-lg overflow-hidden bg-muted">
                        <img
                          src={selectedImage}
                          alt="الروشتة المختارة"
                          className="w-full h-96 object-cover"
                        />
                      </div>
                      <Button
                        variant="outline"
                        className="w-full border-primary text-primary hover:bg-primary/10"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        تغيير الصورة
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="flex justify-center mb-4">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                          <FileImage className="w-8 h-8 text-primary" />
                        </div>
                      </div>
                      <h3 className="text-lg font-bold text-foreground mb-2">
                        اختر صورة الروشتة
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        اضغط هنا أو اسحب الصورة لرفعها
                      </p>
                      <p className="text-xs text-muted-foreground">
                        الصيغ المدعومة: JPG, PNG, WebP (أقصى حجم: 5MB)
                      </p>
                    </div>
                  )}
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageSelect}
                  className="hidden"
                />
              </CardContent>
            </Card>

            {/* Notes Section */}
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-right">ملاحظات إضافية (اختياري)</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="أضف أي ملاحظات مهمة للصيدلي مثل الحساسيات أو الأدوية التي تتناولها حالياً..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="min-h-32 text-right"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  هذه الملاحظات ستساعد الصيدلي على تقديم أفضل خدمة لك
                </p>
              </CardContent>
            </Card>

            {/* Upload Button */}
            {!uploadSuccess && (
              <Button
                onClick={handleUpload}
                disabled={!selectedImage || isUploading}
                className="w-full h-12 bg-primary hover:bg-primary/90 text-white text-base font-bold gap-2"
              >
                <Upload className="w-5 h-5" />
                {isUploading ? "جاري الرفع..." : "رفع الروشتة"}
              </Button>
            )}

            {/* Success Message */}
            {uploadSuccess && (
              <div className="bg-accent/10 border border-accent p-4 rounded-lg flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div className="text-right">
                  <p className="font-bold text-accent mb-1">تم الرفع بنجاح!</p>
                  <p className="text-sm text-muted-foreground">
                    سيتم مراجعة روشتتك من قبل الصيدلي خلال 24 ساعة وسيتم إرسال عرض السعر إليك
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Info Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* How It Works */}
            <Card className="border-border bg-primary/5">
              <CardHeader>
                <CardTitle className="text-right text-lg">كيف يعمل؟</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-right">
                <div className="flex gap-3 items-start">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 font-bold text-sm">
                    1
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">رفع الروشتة</p>
                    <p className="text-sm text-muted-foreground">قم برفع صورة واضحة للروشتة</p>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 font-bold text-sm">
                    2
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">مراجعة الصيدلي</p>
                    <p className="text-sm text-muted-foreground">سيقوم الصيدلي بمراجعة الروشتة</p>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 font-bold text-sm">
                    3
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">عرض السعر</p>
                    <p className="text-sm text-muted-foreground">تلقي عرض سعر مفصل للأدوية</p>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0 font-bold text-sm">
                    4
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">الشراء والتوصيل</p>
                    <p className="text-sm text-muted-foreground">أتمم الشراء واستقبل الأدوية</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips Card */}
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-right text-lg flex items-center justify-end gap-2">
                  <AlertCircle className="w-5 h-5" />
                  نصائح مهمة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-right text-sm">
                <p>✓ تأكد من وضوح الروشتة</p>
                <p>✓ اختر صورة بإضاءة جيدة</p>
                <p>✓ تجنب الظلال والانعكاسات</p>
                <p>✓ أضف ملاحظات عن الحساسيات</p>
              </CardContent>
            </Card>

            {/* Browse Catalog Link */}
            <Link href="/catalog">
              <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/10 gap-2">
                <ArrowRight className="w-5 h-5" />
                تصفح الكتالوج
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
