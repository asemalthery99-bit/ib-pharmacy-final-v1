# دليل التطوير الشامل
## صيدلية إب الرقمية - النسخة الاحترافية

---

## 📋 جدول المحتويات

1. [البدء السريع](#البدء-السريع)
2. [هيكل المشروع](#هيكل-المشروع)
3. [قاعدة البيانات](#قاعدة-البيانات)
4. [الـ API](#الـ-api)
5. [الواجهة الأمامية](#الواجهة-الأمامية)
6. [نظام الإشعارات](#نظام-الإشعارات)
7. [نظام الدفع](#نظام-الدفع)
8. [الاختبارات](#الاختبارات)
9. [النشر والإطلاق](#النشر-والإطلاق)

---

## البدء السريع

### المتطلبات
- Node.js 22+
- MySQL 8+
- pnpm 10+

### التثبيت والتشغيل

```bash
# تثبيت المتطلبات
pnpm install

# تشغيل خادم التطوير
pnpm dev

# تشغيل الاختبارات
pnpm test

# فحص TypeScript
pnpm check
```

---

## هيكل المشروع

```
ibpharmacy_pro/
├── server/                    # Backend
│   ├── routers.ts            # جميع API routers
│   ├── db.ts                 # database queries
│   ├── services/             # business logic
│   │   ├── notifications.ts  # نظام الإشعارات
│   │   └── paypal.ts         # نظام الدفع
│   ├── routers/              # tRPC routers
│   │   ├── notifications.ts
│   │   └── payments.ts
│   └── _core/                # framework core
├── client/                    # Frontend
│   ├── src/
│   │   ├── pages/            # صفحات التطبيق
│   │   ├── components/       # مكونات React
│   │   ├── contexts/         # React contexts
│   │   ├── lib/              # utility functions
│   │   └── App.tsx           # main app
│   └── public/               # static files
├── drizzle/                   # Database
│   ├── schema.ts             # جداول البيانات
│   └── migrations/           # database migrations
├── shared/                    # shared code
└── storage/                   # S3 helpers
```

---

## قاعدة البيانات

### الجداول الرئيسية

#### 1. Users (المستخدمين)
```sql
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  openId VARCHAR(64) UNIQUE NOT NULL,
  name TEXT,
  email VARCHAR(320),
  role ENUM('user', 'admin', 'pharmacist') DEFAULT 'user',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### 2. Medicines (الأدوية)
```sql
CREATE TABLE medicines (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  price DECIMAL(10, 2),
  imageUrl TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3. Inventory (المخزون)
```sql
CREATE TABLE inventory (
  id INT PRIMARY KEY AUTO_INCREMENT,
  medicineId INT NOT NULL,
  quantity INT DEFAULT 0,
  minThreshold INT DEFAULT 50,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (medicineId) REFERENCES medicines(id)
);
```

#### 4. Orders (الطلبات)
```sql
CREATE TABLE orders (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  status ENUM('pending', 'preparing', 'ready', 'completed') DEFAULT 'pending',
  paymentStatus ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
  totalPrice DECIMAL(10, 2),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);
```

#### 5. Prescriptions (الروشتات)
```sql
CREATE TABLE prescriptions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  extractedMedicines JSON,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);
```

---

## الـ API

### Routers الرئيسية

#### 1. Medicines Router
```typescript
// البحث والفلترة
medicines.search.query({ query, category, minPrice, maxPrice })

// الحصول على الأدوية
medicines.list.query()
medicines.getById.query({ id })
medicines.getByIds.query({ ids })

// إدارة الأدوية (Admin)
medicines.create.mutation({ name, category, price, ... })
medicines.update.mutation({ id, ... })
medicines.delete.mutation({ id })
```

#### 2. Inventory Router
```typescript
// الحصول على معلومات المخزون
inventory.getByMedicineId.query({ medicineId })
inventory.getLowStock.query()

// تحديث المخزون
inventory.updateQuantity.mutation({ medicineId, quantity })
```

#### 3. Cart Router
```typescript
// إدارة السلة
cart.addItem.mutation({ medicineId, quantity })
cart.removeItem.mutation({ medicineId })
cart.updateQuantity.mutation({ medicineId, quantity })
cart.getCart.query()
cart.clearCart.mutation()
```

#### 4. Orders Router
```typescript
// إدارة الطلبات
orders.create.mutation({ items })
orders.getById.query({ id })
orders.getUserOrders.query()
orders.updateStatus.mutation({ id, status })
```

#### 5. Payments Router
```typescript
// نظام الدفع
payments.createPayPalOrder.mutation({ orderId, amount })
payments.capturePayPalPayment.mutation({ orderId, paypalOrderId })
payments.getOrderPaymentStatus.query({ orderId })
payments.listUserPayments.query()
```

#### 6. Notifications Router
```typescript
// الإشعارات
notifications.list.query()
notifications.mark.mutation({ id })
notifications.delete.mutation({ id })
notifications.deleteAll.mutation()
```

---

## الواجهة الأمامية

### الصفحات الرئيسية

| الصفحة | المسار | الوصف |
|--------|--------|-------|
| Home | / | الصفحة الرئيسية |
| Catalog | /medicines | كتالوج الأدوية |
| Detail | /medicines/:id | تفاصيل الدواء |
| Cart | /cart | سلة التسوق |
| Checkout | /checkout/:orderId | صفحة الدفع |
| Orders | /orders | الطلبات |
| Prescriptions | /prescriptions | الروشتات |
| Dashboard | /dashboard | لوحة الصيدلي |
| Admin | /admin | لوحة الإدارة |

### المكونات الرئيسية

```typescript
// Cart Context
const { cart, addItem, removeItem, updateQuantity, clearCart } = useCartContext();

// Notifications
const { notifications } = useNotifications();

// Auth
const { user, logout } = useAuth();

// tRPC
const { data, isLoading } = trpc.medicines.list.useQuery();
const mutation = trpc.orders.create.useMutation();
```

---

## نظام الإشعارات

### Triggers المتاحة

```typescript
// عند إنشاء طلب جديد
notifyNewOrder(orderId, userId, totalPrice)

// عند رفع روشتة جديدة
notifyNewPrescription(prescriptionId, userId)

// عند انخفاض المخزون
notifyLowInventory(medicineId, currentQuantity, threshold)

// عند نجاح الدفع
notifyPaymentSuccess(orderId, amount, method)

// عند فشل الدفع
notifyPaymentFailure(orderId, reason)
```

### الاستخدام

```typescript
import { notifyNewOrder } from "./services/notifications";

// إرسال إشعار
await notifyNewOrder(orderId, userId, totalPrice);
```

---

## نظام الدفع

### PayPal Integration

```typescript
import { createPayPalOrder, capturePayPalPayment } from "./services/paypal";

// إنشاء طلب PayPal
const paypalOrderId = await createPayPalOrder(
  orderId,
  amount,
  "USD",
  customerEmail,
  customerName
);

// معالجة الدفع
const result = await capturePayPalPayment(paypalOrderId);
```

### Checkout Flow

```
1. العميل يضيف أدوية إلى السلة
2. يذهب إلى صفحة Checkout
3. ينقر على "الدفع عبر PayPal"
4. يتم تحويله إلى PayPal
5. بعد الدفع الناجح، يعود إلى التطبيق
6. يتم تحديث حالة الطلب إلى "paid"
7. يتم إرسال إشعار للصيدلي
```

---

## الاختبارات

### تشغيل الاختبارات

```bash
# تشغيل جميع الاختبارات
pnpm test

# تشغيل اختبار محدد
pnpm test -- auth.logout.test.ts

# مراقبة الاختبارات
pnpm test -- --watch
```

### أنواع الاختبارات

| النوع | الملف | العدد |
|------|-------|-------|
| Auth Tests | auth.logout.test.ts | 1 |
| Pharmacy API | routers.test.ts | 6 |
| API Binding | integration.test.ts | 8 |
| Notifications | notifications.test.ts | 13 |
| **المجموع** | | **28** |

---

## النشر والإطلاق

### قبل الإطلاق

- [ ] جميع الاختبارات تعمل بنجاح
- [ ] لا توجد أخطاء TypeScript
- [ ] تم فحص الأمان
- [ ] تم اختبار الأداء
- [ ] تم توثيق جميع الـ APIs
- [ ] تم إعداد متغيرات البيئة

### متغيرات البيئة المطلوبة

```env
# Database
DATABASE_URL=mysql://user:password@localhost/ibpharmacy

# OAuth
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# PayPal
PAYPAL_CLIENT_ID=your_client_id
PAYPAL_CLIENT_SECRET=your_client_secret

# S3
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-east-1

# LLM
BUILT_IN_FORGE_API_KEY=your_api_key
BUILT_IN_FORGE_API_URL=https://api.manus.im
```

### خطوات الإطلاق

1. تحضير قاعدة البيانات
2. تعيين متغيرات البيئة
3. تشغيل الاختبارات
4. بناء التطبيق
5. نشر على الخادم
6. اختبار في الإنتاج

---

## الدعم والمساعدة

### الموارد المتاحة

- 📖 [دليل tRPC](https://trpc.io)
- 📖 [دليل React](https://react.dev)
- 📖 [دليل Drizzle ORM](https://orm.drizzle.team)
- 📖 [دليل PayPal](https://developer.paypal.com)

### الأخطاء الشائعة

| الخطأ | الحل |
|------|-----|
| Database connection failed | تحقق من DATABASE_URL |
| PayPal API error | تحقق من PAYPAL_CLIENT_ID و PAYPAL_CLIENT_SECRET |
| S3 upload failed | تحقق من AWS credentials |
| LLM extraction failed | تحقق من BUILT_IN_FORGE_API_KEY |

---

**آخر تحديث:** 18 مارس 2026
