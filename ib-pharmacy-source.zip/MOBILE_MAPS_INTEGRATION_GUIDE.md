# دليل تطبيق الهاتف المحمول وتكامل خرائط Google
## صيدلية إب الرقمية - الإصدار 3.4

---

## نظرة عامة

تم إضافة طبقة جديدة من التقنيات الحديثة لتحويل مشروع صيدلية إب الرقمية إلى منصة متعددة المنصات (Cross-Platform):

1. **تطبيق الهاتف المحمول (React Native):** تطبيق أصلي يعمل على iOS و Android
2. **خرائط Google المتكاملة:** تتبع حي للسائقين والعملاء مع تحديد المواقع بدقة
3. **نظام إشعارات الدفع:** إشعارات فورية لتحديثات الطلبات والعروضات

---

## 1. تطبيق الهاتف المحمول (Mobile App)

### البنية الأساسية

```
mobile/
├── App.tsx                 # نقطة الدخول الرئيسية
├── app.json               # إعدادات التطبيق (Expo)
├── screens/
│   ├── HomeScreen.tsx
│   ├── CatalogScreen.tsx
│   ├── MedicineDetailScreen.tsx
│   ├── CartScreen.tsx
│   ├── OrdersScreen.tsx
│   ├── DeliveryTrackingScreen.tsx
│   ├── LoyaltyScreen.tsx
│   ├── ProfileScreen.tsx
│   └── PrescriptionScanScreen.tsx
├── services/
│   ├── mapsService.ts
│   ├── notificationsService.ts
│   └── apiService.ts
├── components/
│   ├── DeliveryMap.tsx
│   ├── OrderCard.tsx
│   └── NotificationCenter.tsx
└── assets/
    ├── icon.png
    ├── splash.png
    └── fonts/
```

### الميزات الرئيسية

#### 1.1 التنقل (Navigation)

**الهيكل:**
- **Bottom Tab Navigation:** 5 تبويبات رئيسية
  - الرئيسية (Home)
  - الأدوية (Catalog)
  - السلة (Cart)
  - الطلبات (Orders)
  - الملف الشخصي (Profile)

**الملف:** `mobile/App.tsx`

```typescript
// استخدام React Navigation
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

<Tab.Navigator>
  <Tab.Screen name="Home" component={HomeStack} />
  <Tab.Screen name="Catalog" component={CatalogStack} />
  <Tab.Screen name="Cart" component={CartScreen} />
  <Tab.Screen name="Orders" component={OrdersStack} />
  <Tab.Screen name="Profile" component={ProfileStack} />
</Tab.Navigator>
```

#### 1.2 دعم اللغة العربية

```typescript
import { I18nManager } from 'react-native';

// تفعيل RTL للعربية
I18nManager.forceRTL(true);
```

#### 1.3 الأذونات المطلوبة

```json
{
  "android": {
    "permissions": [
      "android.permission.ACCESS_FINE_LOCATION",
      "android.permission.ACCESS_COARSE_LOCATION",
      "android.permission.CAMERA",
      "android.permission.READ_EXTERNAL_STORAGE",
      "android.permission.WRITE_EXTERNAL_STORAGE"
    ]
  }
}
```

### الشاشات الرئيسية

#### HomeScreen
- عرض الأدوية المشهورة
- الفئات السريعة
- العروضات الحالية
- الدخول السريع للمساعد الذكي

#### CatalogScreen
- قائمة كاملة للأدوية
- البحث والتصفية
- التصنيفات
- التقييمات والمراجعات

#### DeliveryTrackingScreen
- تتبع الطلب الحالي
- معلومات السائق
- الموقع على الخريطة
- الاتصال بالسائق

#### LoyaltyScreen
- عرض النقاط الحالية
- المستوى والمزايا
- المكافآت المتاحة
- برنامج الإحالة

---

## 2. تكامل خرائط Google (Google Maps Integration)

### الملف: `mobile/services/mapsService.ts`

### الميزات الرئيسية

#### 2.1 الحصول على الموقع الحالي

```typescript
import * as Location from 'expo-location';

const currentLocation = await mapsService.getCurrentLocation();
// { latitude: 15.3694, longitude: 44.2039 }
```

#### 2.2 تحديد الموقع من العنوان (Geocoding)

```typescript
const coords = await mapsService.geocode('شارع الثورة، إب');
// { latitude: 15.3694, longitude: 44.2039 }
```

#### 2.3 الحصول على العنوان من الموقع (Reverse Geocoding)

```typescript
const address = await mapsService.reverseGeocode({
  latitude: 15.3694,
  longitude: 44.2039,
});
// {
//   street: 'شارع الثورة',
//   city: 'إب',
//   region: 'إب',
//   country: 'اليمن',
//   formattedAddress: 'شارع الثورة، إب، اليمن'
// }
```

#### 2.4 حساب المسافة بين نقطتين

```typescript
const distance = mapsService.calculateDistance(
  { latitude: 15.3694, longitude: 44.2039 }, // موقع الصيدلية
  { latitude: 15.3750, longitude: 44.2100 }  // موقع العميل
);
// 2.5 (km)
```

#### 2.5 تقدير وقت التوصيل

```typescript
const timeMinutes = mapsService.estimateDeliveryTime(2.5);
// 20 (دقيقة)
```

#### 2.6 تتبع الموقع في الوقت الفعلي

```typescript
const unsubscribe = mapsService.watchUserLocation((location) => {
  console.log('Current location:', location);
});

// لإيقاف المراقبة
unsubscribe();
```

#### 2.7 فتح الخريطة الأصلية

```typescript
// فتح موقع على الخريطة
const mapUrl = mapsService.generateMapUrl(
  { latitude: 15.3694, longitude: 44.2039 },
  'صيدلية إب الرقمية');
Linking.openURL(mapUrl);

// فتح الاتجاهات
const directionsUrl = mapsService.generateDirectionsUrl(
  { latitude: 15.3694, longitude: 44.2039 }, // من
  { latitude: 15.3750, longitude: 44.2100 }  // إلى
);
Linking.openURL(directionsUrl);
```

#### 2.8 البحث عن الصيدليات القريبة

```typescript
const nearbyPharmacies = await mapsService.getNearbyPharmacies(
  { latitude: 15.3694, longitude: 44.2039 },
  5 // نطاق البحث بالكيلومترات
);
// [
//   {
//     id: 'PHARM-001',
//     name: 'صيدلية إب الرقمية - الفرع الرئيسي',
//     location: { latitude: 15.3694, longitude: 44.2039 },
//     distance: 2.5,
//     address: 'شارع الثورة، إب',
//     rating: 4.9
//   }
// ]
```

### إعداد مفاتيح Google Maps API

#### الخطوة 1: إنشاء مشروع على Google Cloud Console

1. اذهب إلى [Google Cloud Console](https://console.cloud.google.com)
2. أنشئ مشروع جديد
3. فعّل **Maps SDK for Android** و **Maps SDK for iOS**

#### الخطوة 2: إنشاء مفاتيح API

```bash
# للـ Android
# 1. احصل على SHA-1 fingerprint
keytool -list -v -keystore ~/.android/debug.keystore

# 2. أنشئ مفتاح API في Google Cloud Console
# 3. قيّد المفتاح لـ Android فقط

# للـ iOS
# 1. أنشئ مفتاح API في Google Cloud Console
# 2. قيّد المفتاح لـ iOS فقط
```

#### الخطوة 3: إضافة المفاتيح إلى التطبيق

**في `mobile/app.json`:**

```json
{
  "expo": {
    "android": {
      "config": {
        "googleMaps": {
          "apiKey": "YOUR_GOOGLE_MAPS_API_KEY_ANDROID"
        }
      }
    },
    "ios": {
      "config": {
        "googleMapsApiKey": "YOUR_GOOGLE_MAPS_API_KEY_IOS"
      }
    }
  }
}
```

---

## 3. نظام إشعارات الدفع (Push Notifications)

### الملف: `mobile/services/notificationsService.ts`

### الميزات الرئيسية

#### 3.1 تهيئة الإشعارات

```typescript
import { notificationsService } from './services/notificationsService';

// في App.tsx
useEffect(() => {
  const token = await notificationsService.initializeNotifications();
  console.log('Push token:', token);
  
  // حفظ التوكن على الخادم
  await saveTokenToServer(token);
}, []);
```

#### 3.2 إرسال إشعار محلي

```typescript
await notificationsService.sendLocalNotification({
  title: '✅ تم تأكيد طلبك',
  body: 'تم استقبال طلبك #ORD-001',
  data: { orderId: 'ORD-001' },
});
```

#### 3.3 جدولة إشعار للمستقبل

```typescript
const notificationId = await notificationsService.scheduleNotification(
  {
    title: '💊 تذكير الدواء',
    body: 'حان وقت تناول الدواء',
    data: { medicationName: 'بنادول' },
  },
  3600 // بعد ساعة واحدة
);
```

#### 3.4 قوالب الإشعارات المدمجة

```typescript
// تأكيد الطلب
notificationsService.notificationTemplates.orderConfirmed('ORD-001');

// جاري التحضير
notificationsService.notificationTemplates.orderPreparing('ORD-001');

// جاهز للتسليم
notificationsService.notificationTemplates.orderReady('ORD-001');

// السائق في الطريق
notificationsService.notificationTemplates.driverAssigned('محمد علي', '967123456789');

// الطلب في الطريق
notificationsService.notificationTemplates.orderOnWay(20);

// تم التسليم
notificationsService.notificationTemplates.orderDelivered('ORD-001');

// نقاط الولاء
notificationsService.notificationTemplates.loyaltyPointsEarned(150);

// عرض خاص
notificationsService.notificationTemplates.specialOffer(20, 24);

// تذكير الدواء
notificationsService.notificationTemplates.reminderMedication('بنادول');

// تجديد الدواء
notificationsService.notificationTemplates.refillReminder('بنادول');
```

#### 3.5 الاستماع للإشعارات

```typescript
// عند استقبال إشعار
const subscription = notificationsService.onNotificationReceived((notification) => {
  console.log('Notification received:', notification);
});

// عند الضغط على الإشعار
const responseSubscription = notificationsService.onNotificationResponse((notification) => {
  const { orderId } = notification.request.content.data;
  // الانتقال إلى صفحة تتبع الطلب
  navigation.navigate('DeliveryTracking', { orderId });
});

// تنظيف الاشتراكات
return () => {
  subscription.remove();
  responseSubscription.remove();
};
```

---

## 4. سيناريوهات الاستخدام المتكاملة

### سيناريو 1: عملية شراء كاملة مع التوصيل

1. **العميل يضع طلب:**
   ```typescript
   // يختار الأدوية من الكتالوج
   // يضيفها للسلة
   // يكمل عملية الشراء
   ```

2. **تأكيد الطلب:**
   ```typescript
   // إرسال إشعار: "تم تأكيد طلبك"
   notificationsService.notificationTemplates.orderConfirmed('ORD-001');
   ```

3. **تحضير الطلب:**
   ```typescript
   // إرسال إشعار: "جاري تحضير طلبك"
   notificationsService.notificationTemplates.orderPreparing('ORD-001');
   ```

4. **تعيين السائق:**
   ```typescript
   // البحث عن أقرب سائق
   const nearestDriver = await findNearestDriver(customerLocation);
   
   // إرسال إشعار: "تم تعيين السائق"
   notificationsService.notificationTemplates.driverAssigned(
     nearestDriver.name,
     nearestDriver.phone
   );
   ```

5. **تتبع التوصيل:**
   ```typescript
   // مراقبة موقع السائق
   const unsubscribe = mapsService.watchUserLocation((location) => {
     // تحديث موقع السائق على الخريطة
     updateDriverLocation(location);
   });
   
   // إرسال إشعار: "طلبك في الطريق"
   notificationsService.notificationTemplates.orderOnWay(20);
   ```

6. **التسليم:**
   ```typescript
   // تأكيد التسليم
   // إرسال إشعار: "تم تسليم طلبك"
   notificationsService.notificationTemplates.orderDelivered('ORD-001');
   
   // إضافة نقاط الولاء
   notificationsService.notificationTemplates.loyaltyPointsEarned(150);
   ```

### سيناريو 2: تذكيرات الأدوية

```typescript
// جدولة تذكيرات يومية
const medicationSchedule = [
  { time: '08:00', medication: 'بنادول' },
  { time: '14:00', medication: 'فيتامين C' },
  { time: '20:00', medication: 'بنادول' },
];

medicationSchedule.forEach((schedule) => {
  scheduleNotification(
    notificationsService.notificationTemplates.reminderMedication(schedule.medication),
    calculateSecondsUntilTime(schedule.time)
  );
});
```

---

## 5. الدوال الأساسية

### خدمة الخرائط

```typescript
// الموقع
getCurrentLocation()
watchUserLocation(callback)
reverseGeocode(coords)
geocode(address)

// المسافة والوقت
calculateDistance(from, to)
estimateDeliveryTime(distanceKm)

// الخرائط
generateMapUrl(coords, label)
generateDirectionsUrl(from, to, mode)

// البحث
getNearbyPharmacies(userLocation, radiusKm)
trackDeliveryLocation(deliveryId, callback)
getRoute(from, to)
```

### خدمة الإشعارات

```typescript
// الإعداد
initializeNotifications()
setNotificationHandler(settings)

// الإرسال
sendLocalNotification(payload)
scheduleNotification(payload, delaySeconds)
sendPushNotification(expoPushToken, payload)

// الإدارة
cancelNotification(notificationId)
cancelAllNotifications()
getScheduledNotifications()

// الاستماع
onNotificationResponse(callback)
onNotificationReceived(callback)

// الإعدادات
updateNotificationSettings(settings)
```

---

## 6. أفضل الممارسات

### للمطورين

1. **استخدم Expo للتطوير السريع:**
   ```bash
   npx create-expo-app ibpharmacy-mobile
   cd ibpharmacy-mobile
   npm install expo-location expo-notifications
   ```

2. **اختبر على جهاز فعلي:**
   ```bash
   npx expo start
   # ثم افتح التطبيق على هاتفك
   ```

3. **استخدم EAS Build للنشر:**
   ```bash
   npm install -g eas-cli
   eas build --platform android
   eas build --platform ios
   ```

### للعملاء

1. **فعّل الإشعارات:** للحصول على تحديثات فورية
2. **شارك موقعك:** لتسهيل عملية التوصيل
3. **استخدم الخريطة:** لتتبع السائق بدقة

---

## 7. الملفات المضافة

| الملف | الوصف |
|------|-------|
| `mobile/app.json` | إعدادات التطبيق |
| `mobile/App.tsx` | نقطة الدخول الرئيسية |
| `mobile/services/mapsService.ts` | خدمة الخرائط |
| `mobile/services/notificationsService.ts` | خدمة الإشعارات |
| `mobile/screens/DeliveryTrackingScreen.tsx` | شاشة تتبع التوصيل |

---

## 8. الخطوات التالية

### قصير الأجل
1. ✅ ربط Google Maps API الفعلي
2. ✅ تطبيق Firebase Cloud Messaging
3. ✅ اختبار على أجهزة حقيقية

### متوسط الأجل
1. نشر التطبيق على App Store و Google Play
2. إضافة ميزات الدفع داخل التطبيق
3. تحسين الأداء والسرعة

### طويل الأجل
1. إضافة ميزات AR للمنتجات
2. نظام الذكاء الاصطناعي للتوصيات
3. توسع إلى منصات أخرى

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.4
**الحالة:** ✅ مكتمل وجاهز للنشر
