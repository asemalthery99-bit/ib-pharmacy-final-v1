import { useState } from "react";
import { AlertTriangle, CheckCircle2, AlertCircle, Upload, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { toast } from "sonner";

interface ExtractedMedicine {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
}

interface DrugInteraction {
  drug1: string;
  drug2: string;
  severity: "عالية" | "متوسطة" | "منخفضة";
  description: string;
}

interface AnalysisResult {
  medicines: ExtractedMedicine[];
  interactions: DrugInteraction[];
  warnings: string[];
  recommendations: string[];
  isValid: boolean;
}

export default function UploadPrescriptionEnhanced() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(
    null
  );
  const [patientHistory, setPatientHistory] = useState({
    age: "",
    allergies: "",
    conditions: "",
    currentMedicines: "",
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setAnalysisResult(null);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedFile) {
      toast.error("يرجى اختيار صورة الروشتة");
      return;
    }

    setIsAnalyzing(true);

    try {
      // Simulate API call for prescription analysis
      // In production, this would call the backend API with the image
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Mock analysis result
      const mockResult: AnalysisResult = {
        medicines: [
          {
            name: "أسبرين",
            dosage: "500 ملغ",
            frequency: "مرتين يومياً",
            duration: "7 أيام",
          },
          {
            name: "أموكسيسيلين",
            dosage: "500 ملغ",
            frequency: "ثلاث مرات يومياً",
            duration: "10 أيام",
          },
        ],
        interactions: [
          {
            drug1: "أسبرين",
            drug2: "وارفارين",
            severity: "عالية",
            description: "قد يزيد خطر النزيف",
          },
        ],
        warnings: [
          "⚠️ تحذير: المريض لديه حساسية من البنسلين",
          "⚠️ قد يوجد تعارض مع الأدوية الحالية",
        ],
        recommendations: [
          "✓ تناول الأدوية مع الطعام لتجنب اضطراب المعدة",
          "✓ تجنب الكحول أثناء العلاج",
          "✓ استشر الصيدلي قبل تناول أي أدوية إضافية",
        ],
        isValid: false,
      };

      setAnalysisResult(mockResult);

      if (!mockResult.isValid) {
        toast.error("تم اكتشاف مشاكل في الروشتة - يرجى مراجعة التفاصيل");
      } else {
        toast.success("تم تحليل الروشتة بنجاح");
      }
    } catch (error) {
      toast.error("فشل في تحليل الروشتة");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arabic-bold mb-2">
            تحليل الروشتات الطبية الذكي
          </h1>
          <p className="text-gray-600">
            استخدم الذكاء الاصطناعي لتحليل روشتتك والكشف عن التعارضات الدوائية
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Upload Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* File Upload Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-arabic-bold">
                  رفع صورة الروشتة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className="border-2 border-dashed border-primary rounded-lg p-8 text-center cursor-pointer hover:bg-primary/5 transition"
                  onClick={() =>
                    document.getElementById("file-input")?.click()
                  }
                >
                  <Upload className="w-12 h-12 mx-auto mb-4 text-primary" />
                  <p className="text-lg font-semibold text-arabic-bold mb-2">
                    اسحب الصورة هنا أو انقر للاختيار
                  </p>
                  <p className="text-sm text-gray-600">
                    صيغ مدعومة: JPG, PNG, PDF (حد أقصى 10 ميجابايت)
                  </p>
                  <input
                    id="file-input"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>

                {selectedFile && (
                  <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-sm text-green-700 font-semibold">
                      ✓ تم اختيار الملف: {selectedFile.name}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Patient History Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-arabic-bold">
                  السجل الطبي للمريض (اختياري)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-arabic-bold mb-2">
                    العمر
                  </label>
                  <input
                    type="number"
                    placeholder="أدخل العمر"
                    value={patientHistory.age}
                    onChange={(e) =>
                      setPatientHistory({
                        ...patientHistory,
                        age: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-arabic-bold mb-2">
                    الحساسيات المعروفة
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: بنسلين، أسبرين"
                    value={patientHistory.allergies}
                    onChange={(e) =>
                      setPatientHistory({
                        ...patientHistory,
                        allergies: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-arabic-bold mb-2">
                    الحالات الطبية
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: ارتفاع ضغط الدم، السكري"
                    value={patientHistory.conditions}
                    onChange={(e) =>
                      setPatientHistory({
                        ...patientHistory,
                        conditions: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-arabic-bold mb-2">
                    الأدوية الحالية
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: وارفارين، ميتفورمين"
                    value={patientHistory.currentMedicines}
                    onChange={(e) =>
                      setPatientHistory({
                        ...patientHistory,
                        currentMedicines: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Analyze Button */}
            <Button
              onClick={handleAnalyze}
              disabled={!selectedFile || isAnalyzing}
              className="w-full bg-primary hover:bg-primary/90 text-white py-6 text-lg font-bold text-arabic-bold"
            >
              {isAnalyzing ? (
                <>
                  <Loader className="w-5 h-5 ml-2 animate-spin" />
                  جاري التحليل...
                </>
              ) : (
                "تحليل الروشتة"
              )}
            </Button>
          </div>

          {/* Info Sidebar */}
          <div className="space-y-4">
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-sm text-arabic-bold text-blue-900">
                  ℹ️ معلومات مهمة
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-blue-800 space-y-2">
                <p>
                  • يتم تحليل الروشتة باستخدام الذكاء الاصطناعي المتقدم
                </p>
                <p>• سيتم فحص التعارضات الدوائية تلقائياً</p>
                <p>• سيتم التحقق من الجرعات الموصى بها</p>
                <p>• سيتم تقديم توصيات شاملة</p>
              </CardContent>
            </Card>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <CardTitle className="text-sm text-arabic-bold text-yellow-900">
                  ⚠️ تحذير طبي
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-yellow-800">
                هذا التحليل لأغراض تعليمية فقط وليس بديلاً عن استشارة الطبيب أو
                الصيدلي المختص.
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Analysis Results */}
        {analysisResult && (
          <div className="mt-8 space-y-6">
            <h2 className="text-2xl font-bold text-arabic-bold">
              نتائج التحليل
            </h2>

            <Tabs defaultValue="medicines" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="medicines">الأدوية</TabsTrigger>
                <TabsTrigger value="interactions">التعارضات</TabsTrigger>
                <TabsTrigger value="warnings">التحذيرات</TabsTrigger>
                <TabsTrigger value="recommendations">التوصيات</TabsTrigger>
              </TabsList>

              {/* Medicines Tab */}
              <TabsContent value="medicines">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      {analysisResult.medicines.map((medicine, index) => (
                        <div
                          key={index}
                          className="p-4 border border-gray-200 rounded-lg"
                        >
                          <h4 className="font-bold text-arabic-bold mb-2">
                            {medicine.name}
                          </h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <p>
                              <span className="font-semibold">الجرعة:</span>{" "}
                              {medicine.dosage}
                            </p>
                            <p>
                              <span className="font-semibold">التكرار:</span>{" "}
                              {medicine.frequency}
                            </p>
                            <p>
                              <span className="font-semibold">المدة:</span>{" "}
                              {medicine.duration}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Interactions Tab */}
              <TabsContent value="interactions">
                <Card>
                  <CardContent className="pt-6">
                    {analysisResult.interactions.length > 0 ? (
                      <div className="space-y-4">
                        {analysisResult.interactions.map((interaction, index) => (
                          <div
                            key={index}
                            className="p-4 border-l-4 border-red-500 bg-red-50 rounded"
                          >
                            <div className="flex items-start gap-3">
                              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                              <div>
                                <h4 className="font-bold text-red-900 text-arabic-bold">
                                  {interaction.drug1} + {interaction.drug2}
                                </h4>
                                <p className="text-sm text-red-800 mt-1">
                                  {interaction.description}
                                </p>
                                <span className="inline-block mt-2 px-2 py-1 bg-red-200 text-red-900 text-xs rounded font-semibold">
                                  خطورة: {interaction.severity}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 bg-green-50 rounded-lg border border-green-200 flex items-center gap-3">
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                        <p className="text-green-800 font-semibold text-arabic">
                          لا توجد تعارضات دوائية معروفة
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Warnings Tab */}
              <TabsContent value="warnings">
                <Card>
                  <CardContent className="pt-6">
                    {analysisResult.warnings.length > 0 ? (
                      <div className="space-y-3">
                        {analysisResult.warnings.map((warning, index) => (
                          <div
                            key={index}
                            className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start gap-3"
                          >
                            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                            <p className="text-sm text-yellow-800 text-arabic">
                              {warning}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-600 text-center py-4">
                        لا توجد تحذيرات
                      </p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Recommendations Tab */}
              <TabsContent value="recommendations">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      {analysisResult.recommendations.map((rec, index) => (
                        <div
                          key={index}
                          className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3"
                        >
                          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                          <p className="text-sm text-green-800 text-arabic">
                            {rec}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button className="flex-1 bg-primary hover:bg-primary/90 text-white text-arabic-bold">
                إضافة إلى السلة
              </Button>
              <Button
                variant="outline"
                className="flex-1 text-arabic-bold"
                onClick={() => {
                  setAnalysisResult(null);
                  setSelectedFile(null);
                }}
              >
                تحليل روشتة أخرى
              </Button>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
