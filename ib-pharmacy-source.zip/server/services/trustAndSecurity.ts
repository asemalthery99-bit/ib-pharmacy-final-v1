/**
 * Trust & Security Service
 * Handles verified reviews and pharmacist digital signatures
 */

export interface VerifiedReview {
  id: string;
  medicineId: string;
  medicineName: string;
  userId: string;
  userName: string;
  orderId: string;
  rating: number; // 1-5
  title: string;
  content: string;
  verified: boolean; // Only true if user actually purchased
  purchaseDate: Date;
  reviewDate: Date;
  helpful: number; // Number of people who found it helpful
  unhelpful: number;
  images?: string[];
  pharmacistResponse?: {
    pharmacistId: string;
    pharmacistName: string;
    response: string;
    responseDate: Date;
  };
  status: 'pending' | 'approved' | 'rejected';
  moderationNotes?: string;
}

export interface PharmacistSignature {
  id: string;
  prescriptionId: string;
  pharmacistId: string;
  pharmacistName: string;
  pharmacistLicense: string;
  signatureData: string; // Digital signature hash
  signatureTimestamp: Date;
  verified: boolean;
  verificationMethod: 'digital_signature' | 'otp' | 'biometric';
  medicines: Array<{
    medicineId: string;
    medicineName: string;
    dosage: string;
    quantity: number;
    instructions: string;
  }>;
  patientName: string;
  patientAge: number;
  patientConditions?: string[];
  notes?: string;
  status: 'signed' | 'verified' | 'dispensed';
}

export interface ReviewStatistics {
  medicineId: string;
  medicineName: string;
  averageRating: number;
  totalReviews: number;
  verifiedReviews: number;
  ratingDistribution: {
    5: number;
    4: number;
    3: number;
    2: number;
    1: number;
  };
  trustScore: number; // 0-100
}

/**
 * Create a verified review (only for verified purchases)
 */
export async function createVerifiedReview(
  medicineId: string,
  medicineName: string,
  userId: string,
  userName: string,
  orderId: string,
  purchaseDate: Date,
  rating: number,
  title: string,
  content: string,
  images?: string[]
): Promise<VerifiedReview | null> {
  // Verify that user actually purchased this medicine
  const isPurchased = await verifyPurchase(userId, medicineId, orderId);

  if (!isPurchased) {
    console.error('User did not purchase this medicine');
    return null;
  }

  // Validate rating
  if (rating < 1 || rating > 5) {
    console.error('Invalid rating');
    return null;
  }

  const review: VerifiedReview = {
    id: `REV-${Date.now()}`,
    medicineId,
    medicineName,
    userId,
    userName,
    orderId,
    rating,
    title,
    content,
    verified: true,
    purchaseDate,
    reviewDate: new Date(),
    helpful: 0,
    unhelpful: 0,
    images,
    status: 'pending', // Needs moderation
  };

  console.log('Verified review created:', review);
  return review;
}

/**
 * Verify that user purchased the medicine
 */
async function verifyPurchase(
  userId: string,
  medicineId: string,
  orderId: string
): Promise<boolean> {
  // In production, check database for order
  // Mock verification
  return true;
}

/**
 * Get reviews for a medicine
 */
export async function getMedicineReviews(
  medicineId: string,
  onlyVerified: boolean = true,
  sortBy: 'helpful' | 'recent' | 'rating' = 'helpful'): Promise<VerifiedReview[]> {
  // Mock reviews
  const mockReviews: VerifiedReview[] = [
    {
      id: 'REV-001',
      medicineId,
      medicineName: 'بنادول',
      userId: 'USER-001',
      userName: 'محمد علي',
      orderId: 'ORD-001',
      rating: 5,
      title: 'دواء فعال جداً',
      content: 'استخدمت هذا الدواء وكان فعالاً جداً في خفض الحرارة. التوصيل سريع والجودة ممتازة.',
      verified: true,
      purchaseDate: new Date('2025-03-01'),
      reviewDate: new Date('2025-03-05'),
      helpful: 45,
      unhelpful: 2,
      status: 'approved',
      pharmacistResponse: {
        pharmacistId: 'PHARM-001',
        pharmacistName: 'فاطمة محمد',
        response: 'شكراً على تقييمك الإيجابي. نتمنى لك الشفاء العاجل.',
        responseDate: new Date('2025-03-06'),
      },
    },
    {
      id: 'REV-002',
      medicineId,
      medicineName: 'بنادول',
      userId: 'USER-002',
      userName: 'سارة أحمد',
      orderId: 'ORD-002',
      rating: 4,
      title: 'جيد لكن غالي الثمن قليلاً',
      content: 'الدواء فعال لكن السعر أعلى من الصيدليات الأخرى. الخدمة ممتازة والتوصيل سريع.',
      verified: true,
      purchaseDate: new Date('2025-02-15'),
      reviewDate: new Date('2025-02-20'),
      helpful: 28,
      unhelpful: 5,
      status: 'approved',
    },
  ];

  let filtered = onlyVerified
    ? mockReviews.filter((r) => r.verified && r.status === 'approved')
    : mockReviews.filter((r) => r.status === 'approved');

  // Sort
  if (sortBy === 'helpful') {
    filtered.sort((a, b) => b.helpful - a.helpful);
  } else if (sortBy === 'recent') {
    filtered.sort((a, b) => b.reviewDate.getTime() - a.reviewDate.getTime());
  } else if (sortBy === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  }

  return filtered;
}

/**
 * Get review statistics for a medicine
 */
export async function getReviewStatistics(
  medicineId: string
): Promise<ReviewStatistics> {
  const reviews = await getMedicineReviews(medicineId, true);

  const ratingDistribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  let totalRating = 0;

  for (const review of reviews) {
    ratingDistribution[review.rating as keyof typeof ratingDistribution]++;
    totalRating += review.rating;
  }

  const averageRating = reviews.length > 0 ? totalRating / reviews.length : 0;

  // Calculate trust score (0-100)
  const verifiedCount = reviews.filter((r) => r.verified).length;
  const trustScore = Math.round(
    (averageRating / 5) * 80 + (verifiedCount / Math.max(reviews.length, 1)) * 20
  );

  return {
    medicineId,
    medicineName: 'بنادول', // Mock
    averageRating: Math.round(averageRating * 10) / 10,
    totalReviews: reviews.length,
    verifiedReviews: verifiedCount,
    ratingDistribution,
    trustScore,
  };
}

/**
 * Create pharmacist digital signature
 */
export async function createPharmacistSignature(
  prescriptionId: string,
  pharmacistId: string,
  pharmacistName: string,
  pharmacistLicense: string,
  medicines: Array<{
    medicineId: string;
    medicineName: string;
    dosage: string;
    quantity: number;
    instructions: string;
  }>,
  patientName: string,
  patientAge: number,
  patientConditions?: string[],
  notes?: string
): Promise<PharmacistSignature> {
  // Generate digital signature
  const signatureData = generateDigitalSignature(
    prescriptionId,
    pharmacistId,
    medicines
  );

  const signature: PharmacistSignature = {
    id: `SIG-${Date.now()}`,
    prescriptionId,
    pharmacistId,
    pharmacistName,
    pharmacistLicense,
    signatureData,
    signatureTimestamp: new Date(),
    verified: true,
    verificationMethod: 'digital_signature',
    medicines,
    patientName,
    patientAge,
    patientConditions,
    notes,
    status: 'signed',
  };

  console.log('Pharmacist signature created:', signature);
  return signature;
}

/**
 * Generate digital signature hash
 */
function generateDigitalSignature(
  prescriptionId: string,
  pharmacistId: string,
  medicines: any[]
): string {
  // In production, use cryptographic signing
  const data = `${prescriptionId}|${pharmacistId}|${medicines.map((m) => m.medicineId).join(',')}`;
  const hash = Buffer.from(data).toString('base64');
  return `SIG-${hash}`;
}

/**
 * Verify pharmacist signature
 */
export async function verifyPharmacistSignature(
  signature: PharmacistSignature
): Promise<boolean> {
  // In production, verify cryptographic signature
  if (!signature.signatureData || !signature.pharmacistLicense) {
    return false;
  }

  // Check if pharmacist is licensed
  const isLicensed = await verifyPharmacistLicense(
    signature.pharmacistId,
    signature.pharmacistLicense
  );

  return isLicensed && signature.verified;
}

/**
 * Verify pharmacist license
 */
async function verifyPharmacistLicense(
  pharmacistId: string,
  license: string
): Promise<boolean> {
  // In production, check with pharmacy board
  // Mock verification
  return true;
}

/**
 * Get pharmacist's signature history
 */
export async function getPharmacistSignatureHistory(
  pharmacistId: string,
  limit: number = 50
): Promise<PharmacistSignature[]> {
  // Mock data
  const mockSignatures: PharmacistSignature[] = [
    {
      id: 'SIG-001',
      prescriptionId: 'PRESC-001',
      pharmacistId,
      pharmacistName: 'فاطمة محمد',
      pharmacistLicense: 'PHARM-2024-001',
      signatureData: 'SIG-PRESC-001|PHARM-001|MED-001,MED-002',
      signatureTimestamp: new Date(),
      verified: true,
      verificationMethod: 'digital_signature',
      medicines: [
        {
          medicineId: 'MED-001',
          medicineName: 'أنسولين',
          dosage: '100 وحدة',
          quantity: 1,
          instructions: 'حقن تحت الجلد مرة يومياً',
        },
      ],
      patientName: 'محمد علي',
      patientAge: 45,
      patientConditions: ['السكري'],
      status: 'dispensed',
    },
  ];

  return mockSignatures.slice(0, limit);
}

/**
 * Mark review as helpful
 */
export async function markReviewHelpful(
  reviewId: string,
  helpful: boolean
): Promise<boolean> {
  console.log(`Review ${reviewId} marked as ${helpful ? 'helpful' : 'unhelpful'}`);
  return true;
}

/**
 * Moderate review (approve/reject)
 */
export async function moderateReview(
  reviewId: string,
  approved: boolean,
  notes?: string
): Promise<boolean> {
  console.log(
    `Review ${reviewId} ${approved ? 'approved' : 'rejected'}. Notes: ${notes || 'None'}`
  );
  return true;
}

/**
 * Add pharmacist response to review
 */
export async function addPharmacistResponseToReview(
  reviewId: string,
  pharmacistId: string,
  pharmacistName: string,
  response: string
): Promise<boolean> {
  console.log(
    `Pharmacist response added to review ${reviewId} by ${pharmacistName}`
  );
  return true;
}

/**
 * Get trust score for medicine
 */
export async function getMedicineTrustScore(
  medicineId: string
): Promise<number> {
  const stats = await getReviewStatistics(medicineId);
  return stats.trustScore;
}

/**
 * Get medicines by trust score
 */
export async function getMedicinesByTrustScore(
  minScore: number = 70
): Promise<Array<{ medicineId: string; trustScore: number }>> {
  // Mock data
  return [
    { medicineId: 'MED-001', trustScore: 95 },
    { medicineId: 'MED-002', trustScore: 88 },
    { medicineId: 'MED-003', trustScore: 82 },
  ].filter((m) => m.trustScore >= minScore);
}

