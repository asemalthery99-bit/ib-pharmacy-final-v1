/**
 * Admin Analytics Service
 * Provides comprehensive analytics and insights for pharmacy management
 */

export interface DashboardMetrics {
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  activeSubscriptions: number;
  averageOrderValue: number;
  conversionRate: number;
  customerRetentionRate: number;
  inventoryTurnover: number;
}

export interface SalesAnalytics {
  date: Date;
  orders: number;
  revenue: number;
  averageOrderValue: number;
  topProducts: Array<{
    productId: string;
    productName: string;
    quantity: number;
    revenue: number;
  }>;
}

export interface HourlyAnalytics {
  hour: number; // 0-23
  orders: number;
  revenue: number;
  peakTime: boolean;
}

export interface GeographicAnalytics {
  region: string;
  city: string;
  orders: number;
  revenue: number;
  customers: number;
  averageOrderValue: number;
}

export interface CustomerAnalytics {
  totalCustomers: number;
  newCustomers: number;
  returningCustomers: number;
  churnRate: number;
  lifetimeValue: number;
  segmentation: {
    highValue: number;
    regular: number;
    atRisk: number;
    inactive: number;
  };
}

export interface LoyaltyAnalytics {
  totalMembers: number;
  activeMembers: number;
  totalPointsIssued: number;
  totalPointsRedeemed: number;
  averagePointsPerCustomer: number;
  tierDistribution: {
    bronze: number;
    silver: number;
    gold: number;
    platinum: number;
  };
  roiOnLoyaltyProgram: number; // percentage
}

export interface InventoryAnalytics {
  totalItems: number;
  lowStockItems: number;
  outOfStockItems: number;
  fastMovingItems: number;
  slowMovingItems: number;
  averageTurnoverRate: number;
  stockValue: number;
  stockWastePercentage: number;
}

/**
 * Get dashboard metrics overview
 */
export async function getDashboardMetrics(): Promise<DashboardMetrics> {
  // Mock data - in production, calculate from database
  return {
    totalOrders: 1250,
    totalRevenue: 45320.5,
    totalCustomers: 890,
    activeSubscriptions: 234,
    averageOrderValue: 36.26,
    conversionRate: 3.2,
    customerRetentionRate: 68.5,
    inventoryTurnover: 4.2,
  };
}

/**
 * Get sales analytics for date range
 */
export async function getSalesAnalytics(
  startDate: Date,
  endDate: Date
): Promise<SalesAnalytics[]> {
  // Mock data
  const analytics: SalesAnalytics[] = [];
  const currentDate = new Date(startDate);

  while (currentDate <= endDate) {
    const dayOfWeek = currentDate.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const baseOrders = isWeekend ? 45 : 35;
    const variance = Math.random() * 20 - 10;

    analytics.push({
      date: new Date(currentDate),
      orders: Math.round(baseOrders + variance),
      revenue: Math.round((baseOrders + variance) * 36.26),
      averageOrderValue: 36.26,
      topProducts: [
        {
          productId: 'MED-001',
          productName: 'بنادول',
          quantity: Math.round(Math.random() * 50 + 20),
          revenue: Math.round(Math.random() * 500 + 300),
        },
        {
          productId: 'MED-002',
          productName: 'فيتامين C',
          quantity: Math.round(Math.random() * 40 + 15),
          revenue: Math.round(Math.random() * 400 + 200),
        },
      ],
    });

    currentDate.setDate(currentDate.getDate() + 1);
  }

  return analytics;
}

/**
 * Get hourly analytics (peak hours)
 */
export async function getHourlyAnalytics(): Promise<HourlyAnalytics[]> {
  // Mock data showing peak hours
  const peakHours = [8, 9, 12, 13, 18, 19, 20]; // Morning, lunch, evening

  const analytics: HourlyAnalytics[] = [];

  for (let hour = 0; hour < 24; hour++) {
    const isPeak = peakHours.includes(hour);
    const baseOrders = isPeak ? 15 : 5;
    const variance = Math.random() * 5;

    analytics.push({
      hour,
      orders: Math.round(baseOrders + variance),
      revenue: Math.round((baseOrders + variance) * 36.26),
      peakTime: isPeak,
    });
  }

  return analytics;
}

/**
 * Get geographic analytics
 */
export async function getGeographicAnalytics(): Promise<GeographicAnalytics[]> {
  // Mock data
  return [
    {
      region: 'إب',
      city: 'إب',
      orders: 450,
      revenue: 16317,
      customers: 320,
      averageOrderValue: 36.26,
    },
    {
      region: 'صنعاء',
      city: 'صنعاء',
      orders: 280,
      revenue: 10153,
      customers: 210,
      averageOrderValue: 36.26,
    },
    {
      region: 'عدن',
      city: 'عدن',
      orders: 320,
      revenue: 11603,
      customers: 240,
      averageOrderValue: 36.26,
    },
    {
      region: 'الحديدة',
      city: 'الحديدة',
      orders: 200,
      revenue: 7252,
      customers: 120,
      averageOrderValue: 36.26,
    },
  ];
}

/**
 * Get customer analytics
 */
export async function getCustomerAnalytics(): Promise<CustomerAnalytics> {
  // Mock data
  return {
    totalCustomers: 890,
    newCustomers: 145,
    returningCustomers: 745,
    churnRate: 8.2,
    lifetimeValue: 450.5,
    segmentation: {
      highValue: 120,
      regular: 450,
      atRisk: 180,
      inactive: 140,
    },
  };
}

/**
 * Get loyalty program analytics
 */
export async function getLoyaltyAnalytics(): Promise<LoyaltyAnalytics> {
  // Mock data
  return {
    totalMembers: 650,
    activeMembers: 520,
    totalPointsIssued: 125000,
    totalPointsRedeemed: 45000,
    averagePointsPerCustomer: 192.3,
    tierDistribution: {
      bronze: 280,
      silver: 180,
      gold: 120,
      platinum: 70,
    },
    roiOnLoyaltyProgram: 28.5, // 28.5% ROI
  };
}

/**
 * Get inventory analytics
 */
export async function getInventoryAnalytics(): Promise<InventoryAnalytics> {
  // Mock data
  return {
    totalItems: 450,
    lowStockItems: 45,
    outOfStockItems: 8,
    fastMovingItems: 120,
    slowMovingItems: 85,
    averageTurnoverRate: 4.2,
    stockValue: 125000,
    stockWastePercentage: 2.3,
  };
}

/**
 * Get top products by revenue
 */
export async function getTopProductsByRevenue(
  limit: number = 10
): Promise<
  Array<{
    productId: string;
    productName: string;
    quantity: number;
    revenue: number;
    margin: number;
  }>
> {
  // Mock data
  return [
    {
      productId: 'MED-001',
      productName: 'بنادول',
      quantity: 450,
      revenue: 16335,
      margin: 35,
    },
    {
      productId: 'MED-002',
      productName: 'فيتامين C',
      quantity: 380,
      revenue: 13788,
      margin: 40,
    },
    {
      productId: 'MED-003',
      productName: 'شراب السعال',
      quantity: 290,
      revenue: 10524,
      margin: 38,
    },
    {
      productId: 'MED-004',
      productName: 'أنسولين',
      quantity: 120,
      revenue: 9120,
      margin: 25,
    },
    {
      productId: 'MED-005',
      productName: 'أدوية الضغط',
      quantity: 210,
      revenue: 7623,
      margin: 32,
    },
  ].slice(0, limit);
}

/**
 * Get revenue forecast
 */
export async function getRevenueForecast(
  daysAhead: number = 30
): Promise<Array<{ date: Date; predictedRevenue: number; confidence: number }>> {
  // Mock forecast
  const forecast = [];
  const baseRevenue = 1510.68; // Daily average

  for (let i = 0; i < daysAhead; i++) {
    const date = new Date();
    date.setDate(date.getDate() + i);

    const variance = Math.random() * 200 - 100;
    const confidence = 0.95 - i * 0.01; // Decreases over time

    forecast.push({
      date,
      predictedRevenue: Math.round(baseRevenue + variance),
      confidence: Math.max(0.5, confidence),
    });
  }

  return forecast;
}

/**
 * Get customer acquisition cost (CAC)
 */
export async function getCustomerAcquisitionCost(): Promise<{
  totalMarketingSpend: number;
  newCustomers: number;
  cac: number;
  paybackPeriod: number; // months
}> {
  // Mock data
  return {
    totalMarketingSpend: 5000,
    newCustomers: 145,
    cac: 34.48,
    paybackPeriod: 2.5,
  };
}

/**
 * Get customer lifetime value (CLV)
 */
export async function getCustomerLifetimeValue(): Promise<{
  averageClv: number;
  highValueClv: number;
  regularClv: number;
  atRiskClv: number;
}> {
  // Mock data
  return {
    averageClv: 450.5,
    highValueClv: 1200.75,
    regularClv: 380.25,
    atRiskClv: 150.5,
  };
}

/**
 * Get payment method analytics
 */
export async function getPaymentMethodAnalytics(): Promise<
  Array<{
    method: string;
    transactions: number;
    revenue: number;
    percentage: number;
  }>
> {
  // Mock data
  return [
    { method: 'Credit Card', transactions: 450, revenue: 16335, percentage: 36 },
    { method: 'E-Wallet', transactions: 380, revenue: 13788, percentage: 30.4 },
    { method: 'PayPal', transactions: 250, revenue: 9065, percentage: 20 },
    { method: 'Bank Transfer', transactions: 170, revenue: 6162, percentage: 13.6 },
  ];
}

/**
 * Get subscription analytics
 */
export async function getSubscriptionAnalytics(): Promise<{
  totalSubscriptions: number;
  activeSubscriptions: number;
  pausedSubscriptions: number;
  cancelledSubscriptions: number;
  monthlyRecurringRevenue: number;
  churnRate: number;
  growthRate: number;
}> {
  // Mock data
  return {
    totalSubscriptions: 450,
    activeSubscriptions: 234,
    pausedSubscriptions: 89,
    cancelledSubscriptions: 127,
    monthlyRecurringRevenue: 8500,
    churnRate: 12.5,
    growthRate: 8.3,
  };
}

/**
 * Get comprehensive report
 */
export async function getComprehensiveReport(): Promise<{
  metrics: DashboardMetrics;
  sales: SalesAnalytics[];
  hourly: HourlyAnalytics[];
  geographic: GeographicAnalytics[];
  customers: CustomerAnalytics;
  loyalty: LoyaltyAnalytics;
  inventory: InventoryAnalytics;
  topProducts: any[];
  forecast: any[];
}> {
  return {
    metrics: await getDashboardMetrics(),
    sales: await getSalesAnalytics(
      new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      new Date()
    ),
    hourly: await getHourlyAnalytics(),
    geographic: await getGeographicAnalytics(),
    customers: await getCustomerAnalytics(),
    loyalty: await getLoyaltyAnalytics(),
    inventory: await getInventoryAnalytics(),
    topProducts: await getTopProductsByRevenue(),
    forecast: await getRevenueForecast(),
  };
}
