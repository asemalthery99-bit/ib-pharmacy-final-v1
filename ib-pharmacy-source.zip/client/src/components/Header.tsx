import { Link, useLocation } from "wouter";
import { ShoppingCart, Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();
  const { getTotalItems } = useCart();
  const totalItems = getTotalItems();

  const isActive = (path: string) => location === path;

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center text-white font-bold text-lg">
            ب
          </div>
          <span className="font-bold text-xl text-foreground hidden sm:inline text-arabic-bold">صيدلية إب</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/" className={`${isActive("/") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
            الرئيسية
          </Link>
          <Link href="/catalog" className={`${isActive("/catalog") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
            الكتالوج
          </Link>
          <Link href="/orders" className={`${isActive("/orders") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
            طلباتي
          </Link>
          <Link href="/upload-prescription" className={`${isActive("/upload-prescription") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
            رفع روشتة
          </Link>
          <Link href="/pharmacist-dashboard" className={`${isActive("/pharmacist-dashboard") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
            لوحة الصيدلي
          </Link>
          <Link href="#" className="text-foreground hover:text-primary transition font-medium text-arabic">
            اتصل بنا
          </Link>
        </nav>

        {/* Right Side Actions */}
        <div className="flex items-center gap-4">
          <Link href="/cart" className="relative p-2 hover:bg-muted rounded-lg transition">
            <ShoppingCart className="w-5 h-5 text-foreground" />
            {totalItems > 0 && (
              <span className="absolute top-1 left-1 bg-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {totalItems}
              </span>
            )}
          </Link>
          <Link href="/cart" className="md:hidden relative p-2 hover:bg-muted rounded-lg transition">
            <ShoppingCart className="w-5 h-5 text-foreground" />
            {totalItems > 0 && (
              <span className="absolute top-1 left-1 bg-accent text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                {totalItems}
              </span>
            )}
          </Link>
          <Button className="hidden sm:inline-flex bg-primary hover:bg-primary/90 text-primary-foreground text-arabic">
            تسجيل الدخول
          </Button>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 hover:bg-muted rounded-lg transition"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <nav className="md:hidden border-t border-border bg-white">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <Link href="/" className={`${isActive("/") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
              الرئيسية
            </Link>
            <Link href="/catalog" className={`${isActive("/catalog") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
              الكتالوج
            </Link>
            <Link href="/orders" className={`${isActive("/orders") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
              طلباتي
            </Link>
            <Link href="/upload-prescription" className={`${isActive("/upload-prescription") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
              رفع روشتة
            </Link>
            <Link href="/pharmacist-dashboard" className={`${isActive("/pharmacist-dashboard") ? "text-primary font-bold" : "text-foreground"} hover:text-primary transition font-medium text-arabic`}>
              لوحة الصيدلي
            </Link>
            <Link href="#" className="text-foreground hover:text-primary transition font-medium text-arabic">
              اتصل بنا
            </Link>
            <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-arabic">
              تسجيل الدخول
            </Button>
          </div>
        </nav>
      )}
    </header>
  );
}
