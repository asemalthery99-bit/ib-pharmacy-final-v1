import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);

try {
  console.log("🌱 بدء ملء قاعدة البيانات...");

  // Clear existing data
  await connection.query("DELETE FROM ratings");
  await connection.query("DELETE FROM driverRatings");
  await connection.query("DELETE FROM orderItems");
  await connection.query("DELETE FROM orders");
  await connection.query("DELETE FROM inventory");
  await connection.query("DELETE FROM medicines");
  await connection.query("DELETE FROM promoCodes");
  await connection.query("DELETE FROM categories");
  await connection.query("DELETE FROM deliveryStages");
  await connection.query("DELETE FROM deliveryTracking");

  // Insert categories
  const categories = [
    { name: "أدوية الألم", description: "أدوية لتسكين الألم والحمى" },
    { name: "أدوية الجهاز التنفسي", description: "أدوية لنزلات البرد والإنفلونزا" },
    { name: "أدوية الجهاز الهضمي", description: "أدوية لمشاكل المعدة والهضم" },
    { name: "أدوية الحساسية", description: "أدوية لعلاج الحساسية والحكة" },
    { name: "الفيتامينات والمكملات", description: "فيتامينات ومكملات غذائية" },
    { name: "أدوية الجلد", description: "أدوية لعلاج مشاكل الجلد" },
  ];

  for (const cat of categories) {
    await connection.query("INSERT INTO categories (name, description) VALUES (?, ?)", [
      cat.name,
      cat.description,
    ]);
  }

  console.log("✅ تم إدراج الفئات");

  // Insert medicines
  const medicines = [
    {
      name: "باراسيتامول 500 ملغ",
      description: "دواء لتسكين الألم والحمى",
      categoryId: 1,
      price: "15.00",
      activeIngredient: "Paracetamol",
      manufacturer: "شركة الدواء العربية",
      requiresPrescription: false,
    },
    {
      name: "إيبوبروفين 400 ملغ",
      description: "مسكن ألم وخافض حرارة قوي",
      categoryId: 1,
      price: "20.00",
      activeIngredient: "Ibuprofen",
      manufacturer: "شركة الدواء الدولية",
      requiresPrescription: false,
    },
    {
      name: "شراب السعال",
      description: "دواء فعال لعلاج السعال والبرد",
      categoryId: 2,
      price: "25.00",
      activeIngredient: "Dextromethorphan",
      manufacturer: "شركة الأدوية المتقدمة",
      requiresPrescription: false,
    },
    {
      name: "أقراص الحموضة",
      description: "تخفيف سريع من حموضة المعدة",
      categoryId: 3,
      price: "18.00",
      activeIngredient: "Omeprazole",
      manufacturer: "شركة الدواء الوطنية",
      requiresPrescription: true,
    },
    {
      name: "مضاد الحساسية",
      description: "دواء فعال لعلاج الحساسية",
      categoryId: 4,
      price: "22.00",
      activeIngredient: "Cetirizine",
      manufacturer: "شركة الصحة الأولى",
      requiresPrescription: false,
    },
    {
      name: "فيتامين C 1000 ملغ",
      description: "مكمل غذائي لتقوية المناعة",
      categoryId: 5,
      price: "30.00",
      activeIngredient: "Vitamin C",
      manufacturer: "شركة الفيتامينات",
      requiresPrescription: false,
    },
    {
      name: "كريم الجلد",
      description: "كريم طبي لعلاج الالتهابات الجلدية",
      categoryId: 6,
      price: "35.00",
      activeIngredient: "Hydrocortisone",
      manufacturer: "شركة العناية بالجلد",
      requiresPrescription: true,
    },
    {
      name: "أقراص الزنك",
      description: "مكمل غذائي لتقوية المناعة",
      categoryId: 5,
      price: "28.00",
      activeIngredient: "Zinc",
      manufacturer: "شركة الفيتامينات",
      requiresPrescription: false,
    },
  ];

  for (const med of medicines) {
    const result = await connection.query(
      "INSERT INTO medicines (name, description, categoryId, price, activeIngredient, manufacturer, requiresPrescription) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [
        med.name,
        med.description,
        med.categoryId,
        med.price,
        med.activeIngredient,
        med.manufacturer,
        med.requiresPrescription ? 1 : 0,
      ]
    );

    // Create inventory for each medicine
    const medicineId = result[0].insertId;
    await connection.query(
      "INSERT INTO inventory (medicineId, quantity, minThreshold, maxThreshold) VALUES (?, ?, ?, ?)",
      [medicineId, 100, 50, 500]
    );
  }

  console.log("✅ تم إدراج الأدوية والمخزون");

  // Insert promo codes
  const promoCodes = [
    {
      code: "WELCOME20",
      discountType: "percentage",
      discountValue: "20.00",
      minOrderAmount: "50.00",
      usageLimit: 100,
      validFrom: new Date(),
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    },
    {
      code: "SUMMER15",
      discountType: "percentage",
      discountValue: "15.00",
      minOrderAmount: "100.00",
      usageLimit: 50,
      validFrom: new Date(),
      validUntil: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
    },
    {
      code: "SAVE50",
      discountType: "fixed",
      discountValue: "50.00",
      minOrderAmount: "200.00",
      usageLimit: 20,
      validFrom: new Date(),
      validUntil: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
    },
  ];

  for (const promo of promoCodes) {
    await connection.query(
      "INSERT INTO promoCodes (code, discountType, discountValue, minOrderAmount, usageLimit, validFrom, validUntil, isActive) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [
        promo.code,
        promo.discountType,
        promo.discountValue,
        promo.minOrderAmount,
        promo.usageLimit,
        promo.validFrom,
        promo.validUntil,
        1,
      ]
    );
  }

  console.log("✅ تم إدراج أكواد الخصم");

  console.log("🎉 تم ملء قاعدة البيانات بنجاح!");
} catch (error) {
  console.error("❌ خطأ:", error);
} finally {
  await connection.end();
}
