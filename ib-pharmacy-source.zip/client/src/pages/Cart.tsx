import { useCart } from "@/contexts/CartContext";
import { Link } from "wouter";
import { Trash2, Plus, Minus, ShoppingCart, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function Cart() {
  const { items, removeFromCart, updateQuantity, getTotalPrice, getTotalItems, clearCart, isLoading } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);

  // Fetch medicine details for all items in cart
  const medicineIds = items.map(item => item.medicineId);
  const { data: medicines = [] } = trpc.medicines.getByIds.useQuery(
    { ids: medicineIds },
    { enabled: medicineIds.length > 0 }
  );

  const totalPrice = getTotalPrice();
  const totalItems = getTotalItems();
  const shippingCost = 500;
  const finalTotal = totalPrice + (items.length > 0 ? shippingCost : 0);

  const handleUpdateQuantity = async (medicineId: number, newQuantity: number) => {
    try {
      setIsProcessing(true);
      await updateQuantity(medicineId, newQuantity);
      toast.success("تم تحديث الكمية");
    } catch (error) {
      toast.error("فشل تحديث الكمية");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRemoveFromCart = async (medicineId: number) => {
    try {
      setIsProcessing(true);
      await removeFromCart(medicineId);
      toast.success("تم حذف المنتج من السلة");
    } catch (error) {
      toast.error("فشل حذف المنتج");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearCart = async () => {
    try {
      setIsProcessing(true);
      await clearCart();
      toast.success("تم تفريغ السلة");
    } catch (error) {
      toast.error("فشل تفريغ السلة");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-foreground mb-2">سلة التسوق</h1>
          <p className="text-muted-foreground">
            {totalItems > 0 
              ? `لديك ${totalItems} منتج${totalItems > 1 ? 'ات' : ''} في السلة`
              : "سلتك فارغة"}
          </p>
        </div>

        {items.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => {
                const medicine = medicines.find(m => m.id === item.medicineId);
                if (!medicine) return null;

                return (
                  <Card key={item.medicineId} className="overflow-hidden border-border hover:shadow-md transition">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        {/* Product Image */}
                        <div className="w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
                          <img
                            src={medicine.imageUrl || ""}
                            alt={medicine.arabicName}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Product Details */}
                        <div className="flex-1 text-right">
                          <Link href={`/medicine/${item.medicineId}`}>
                            <h3 className="text-lg font-bold text-foreground hover:text-primary transition cursor-pointer">
                              {medicine.arabicName}
                            </h3>
                          </Link>
                          <p className="text-sm text-muted-foreground mb-2">{medicine.name}</p>
                          <p className="text-lg font-bold text-primary mb-3">
                            {(parseFloat(medicine.price) * item.quantity).toLocaleString()} ريال
                          </p>

                          {/* Quantity Controls */}
                          <div className="flex items-center gap-2 justify-end">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleUpdateQuantity(item.medicineId, item.quantity + 1)}
                              disabled={isProcessing || isLoading}
                              className="w-8 h-8 p-0"
                            >
                              <Plus className="w-4 h-4" />
                            </Button>
                            <Input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => {
                                const value = parseInt(e.target.value);
                                if (value > 0) {
                                  handleUpdateQuantity(item.medicineId, value);
                                }
                              }}
                              disabled={isProcessing || isLoading}
                              className="w-16 h-8 text-center"
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleUpdateQuantity(item.medicineId, item.quantity - 1)}
                              disabled={isProcessing || isLoading}
                              className="w-8 h-8 p-0"
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleRemoveFromCart(item.medicineId)}
                              disabled={isProcessing || isLoading}
                              className="text-destructive hover:bg-destructive/10 mr-2"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="border-border sticky top-4">
                <CardHeader>
                  <CardTitle className="text-right">ملخص الطلب</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Subtotal */}
                  <div className="flex justify-between items-center text-right">
                    <span className="text-muted-foreground">المجموع الفرعي:</span>
                    <span className="font-semibold">{totalPrice.toLocaleString()} ريال</span>
                  </div>

                  {/* Shipping */}
                  <div className="flex justify-between items-center text-right border-t border-border pt-4">
                    <span className="text-muted-foreground">تكلفة التوصيل:</span>
                    <span className="font-semibold">{shippingCost.toLocaleString()} ريال</span>
                  </div>

                  {/* Total */}
                  <div className="flex justify-between items-center text-right border-t border-border pt-4 pb-4">
                    <span className="font-bold text-lg">الإجمالي:</span>
                    <span className="font-bold text-lg text-primary">{finalTotal.toLocaleString()} ريال</span>
                  </div>

                  {/* Checkout Button */}
                  <Link href="/checkout">
                    <Button 
                      disabled={isProcessing || isLoading}
                      className="w-full bg-primary hover:bg-primary/90 text-white h-12 text-base gap-2"
                    >
                      <ShoppingCart className="w-5 h-5" />
                      متابعة الدفع
                    </Button>
                  </Link>

                  {/* Continue Shopping */}
                  <Link href="/catalog">
                    <Button variant="outline" className="w-full h-12 border-primary text-primary hover:bg-primary/10 gap-2">
                      <ArrowRight className="w-5 h-5" />
                      متابعة التسوق
                    </Button>
                  </Link>

                  {/* Clear Cart */}
                  <Button
                    variant="ghost"
                    onClick={handleClearCart}
                    disabled={isProcessing || isLoading}
                    className="w-full text-destructive hover:bg-destructive/10"
                  >
                    تفريغ السلة
                  </Button>
                </CardContent>
              </Card>

              {/* Shipping Info */}
              <Card className="mt-4 border-border bg-primary/5">
                <CardContent className="p-4 text-right">
                  <p className="text-sm font-semibold text-primary mb-2">معلومات التوصيل</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>✓ توصيل مجاني للطلبات فوق 50,000 ريال</li>
                    <li>✓ توصيل سريع خلال 24 ساعة</li>
                    <li>✓ ضمان سلامة المنتجات</li>
                    <li>✓ إمكانية الاسترجاع خلال 7 أيام</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          // Empty Cart
          <div className="text-center py-20">
            <div className="flex justify-center mb-6">
              <ShoppingCart className="w-24 h-24 text-muted-foreground opacity-20" />
            </div>
            <h2 className="text-2xl font-bold mb-2">سلتك فارغة</h2>
            <p className="text-muted-foreground mb-8">ابدأ التسوق الآن واختر الأدوية التي تحتاجها</p>
            <Link href="/catalog">
              <Button className="bg-primary hover:bg-primary/90 text-white gap-2">
                <ArrowRight className="w-5 h-5" />
                تصفح الكتالوج
              </Button>
            </Link>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
