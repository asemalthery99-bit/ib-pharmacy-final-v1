import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';

/**
 * Push Notifications Service
 * Handles push notification setup, sending, and management
 */

export interface NotificationPayload {
  title: string;
  body: string;
  data?: Record<string, any>;
  sound?: string;
  badge?: number;
}

export interface NotificationSettings {
  alert: boolean;
  sound: boolean;
  badge: boolean;
}

/**
 * Initialize notifications
 */
export async function initializeNotifications(): Promise<string | null> {
  try {
    // Check if device is physical
    if (!Device.isDevice) {
      console.warn('Notifications only work on physical devices');
      return null;
    }

    // Get existing permissions
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    // Request permissions if not already granted
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.warn('Failed to get push notification permissions');
      return null;
    }

    // Get push token
    const projectId = Constants.expoConfig?.extra?.eas?.projectId;
    const token = (
      await Notifications.getExpoPushTokenAsync({
        projectId,
      })
    ).data;

    console.log('Push token:', token);
    return token;
  } catch (error) {
    console.error('Error initializing notifications:', error);
    return null;
  }
}

/**
 * Send local notification
 */
export async function sendLocalNotification(
  payload: NotificationPayload
): Promise<void> {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: payload.title,
        body: payload.body,
        data: payload.data || {},
        sound: payload.sound || 'default',
        badge: payload.badge || 1,
      },
      trigger: {
        seconds: 1,
      },
    });
  } catch (error) {
    console.error('Error sending local notification:', error);
  }
}

/**
 * Schedule notification for later
 */
export async function scheduleNotification(
  payload: NotificationPayload,
  delaySeconds: number
): Promise<string | null> {
  try {
    const notificationId = await Notifications.scheduleNotificationAsync({
      content: {
        title: payload.title,
        body: payload.body,
        data: payload.data || {},
        sound: payload.sound || 'default',
        badge: payload.badge || 1,
      },
      trigger: {
        seconds: delaySeconds,
      },
    });

    return notificationId;
  } catch (error) {
    console.error('Error scheduling notification:', error);
    return null;
  }
}

/**
 * Cancel scheduled notification
 */
export async function cancelNotification(notificationId: string): Promise<void> {
  try {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  } catch (error) {
    console.error('Error canceling notification:', error);
  }
}

/**
 * Cancel all notifications
 */
export async function cancelAllNotifications(): Promise<void> {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
  } catch (error) {
    console.error('Error canceling all notifications:', error);
  }
}

/**
 * Listen for notification responses
 */
export function onNotificationResponse(
  callback: (notification: Notifications.Notification) => void
): Notifications.Subscription {
  return Notifications.addNotificationResponseReceivedListener((response) => {
    callback(response.notification);
  });
}

/**
 * Listen for incoming notifications
 */
export function onNotificationReceived(
  callback: (notification: Notifications.Notification) => void
): Notifications.Subscription {
  return Notifications.addNotificationReceivedListener((notification) => {
    callback(notification);
  });
}

/**
 * Set notification handler
 */
export function setNotificationHandler(
  settings: NotificationSettings
): void {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: settings.alert,
      shouldPlaySound: settings.sound,
      shouldSetBadge: settings.badge,
    }),
  });
}

/**
 * Notification templates for common scenarios
 */
export const notificationTemplates = {
  orderConfirmed: (orderId: string): NotificationPayload => ({
    title: '✅ تم تأكيد طلبك',
    body: `تم استقبال طلبك #${orderId}. سيتم معالجته قريباً.`,
    data: { orderId, type: 'order_confirmed' },
  }),

  orderPreparing: (orderId: string): NotificationPayload => ({
    title: '⏳ جاري تحضير طلبك',
    body: `يتم تحضير أدويتك الآن. رقم الطلب: #${orderId}`,
    data: { orderId, type: 'order_preparing' },
  }),

  orderReady: (orderId: string): NotificationPayload => ({
    title: '✨ طلبك جاهز للتسليم',
    body: `تم تحضير طلبك بنجاح. سيتم توصيله قريباً. #${orderId}`,
    data: { orderId, type: 'order_ready' },
  }),

  driverAssigned: (driverName: string, phone: string): NotificationPayload => ({
    title: '🚗 تم تعيين السائق',
    body: `السائق ${driverName} في الطريق إليك. اضغط للاتصال.`,
    data: { driverName, phone, type: 'driver_assigned' },
  }),

  orderOnWay: (estimatedTime: number): NotificationPayload => ({
    title: '📍 طلبك في الطريق',
    body: `سيصل طلبك خلال ${estimatedTime} دقيقة تقريباً.`,
    data: { estimatedTime, type: 'order_on_way' },
  }),

  orderDelivered: (orderId: string): NotificationPayload => ({
    title: '🎉 تم تسليم طلبك',
    body: `شكراً لك! تم تسليم طلبك #${orderId} بنجاح.`,
    data: { orderId, type: 'order_delivered' },
  }),

  loyaltyPointsEarned: (points: number): NotificationPayload => ({
    title: '⭐ حصلت على نقاط',
    body: `لقد حصلت على ${points} نقطة من آخر عملية شراء.`,
    data: { points, type: 'loyalty_points' },
  }),

  specialOffer: (discount: number, expiryHours: number): NotificationPayload => ({
    title: '🎁 عرض خاص لك',
    body: `احصل على خصم ${discount}% على طلبك التالي. ينتهي خلال ${expiryHours} ساعة.`,
    data: { discount, expiryHours, type: 'special_offer' },
  }),

  reminderMedication: (medicationName: string): NotificationPayload => ({
    title: '💊 تذكير الدواء',
    body: `حان وقت تناول ${medicationName}. تذكر أهمية الالتزام بالجرعات.`,
    data: { medicationName, type: 'medication_reminder' },
  }),

  refillReminder: (medicationName: string): NotificationPayload => ({
    title: '🔄 حان وقت تجديد الدواء',
    body: `دواؤك ${medicationName} على وشك الانتهاء. اطلب الآن.`,
    data: { medicationName, type: 'refill_reminder' },
  }),
};

/**
 * Send notification (mock - would use Firebase Cloud Messaging in production)
 */
export async function sendPushNotification(
  expoPushToken: string,
  payload: NotificationPayload
): Promise<boolean> {
  try {
    const message = {
      to: expoPushToken,
      sound: 'default',
      title: payload.title,
      body: payload.body,
      data: payload.data || {},
      badge: payload.badge || 1,
    };

    // In production, send to Expo Push Notification Service
    // const response = await fetch('https://exp.host/--/api/v2/push/send', {
    //   method: 'POST',
    //   headers: {
    //     Accept: 'application/json',
    //     'Accept-encoding': 'gzip, deflate',
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify(message),
    // });

    console.log('Push notification would be sent:', message);
    return true;
  } catch (error) {
    console.error('Error sending push notification:', error);
    return false;
  }
}

/**
 * Get all scheduled notifications
 */
export async function getScheduledNotifications(): Promise<
  Notifications.NotificationRequest[]
> {
  try {
    return await Notifications.getAllScheduledNotificationsAsync();
  } catch (error) {
    console.error('Error getting scheduled notifications:', error);
    return [];
  }
}

/**
 * Update notification settings
 */
export async function updateNotificationSettings(
  settings: NotificationSettings
): Promise<void> {
  try {
    // Save to local storage or backend
    console.log('Notification settings updated:', settings);
    setNotificationHandler(settings);
  } catch (error) {
    console.error('Error updating notification settings:', error);
  }
}
