import { Check, Clock, Package, Truck, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";

export interface OrderStatus {
  id: string;
  status: "pending" | "preparing" | "ready" | "completed" | "cancelled";
  createdAt: Date;
  updatedAt: Date;
  totalPrice: number;
}

interface OrderTrackerProps {
  order: OrderStatus;
  showTimeline?: boolean;
}

export default function OrderTracker({ order, showTimeline = true }: OrderTrackerProps) {
  const statusSteps = [
    {
      key: "pending",
      label: "قيد الانتظار",
      description: "تم استقبال طلبك",
      icon: Clock,
      color: "text-yellow-500",
      bgColor: "bg-yellow-50",
    },
    {
      key: "preparing",
      label: "قيد التحضير",
      description: "نحن نجهز طلبك",
      icon: Package,
      color: "text-blue-500",
      bgColor: "bg-blue-50",
    },
    {
      key: "ready",
      label: "جاهز للتسليم",
      description: "طلبك جاهز",
      icon: CheckCircle2,
      color: "text-green-500",
      bgColor: "bg-green-50",
    },
    {
      key: "completed",
      label: "تم التسليم",
      description: "تم تسليم طلبك",
      icon: Truck,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
    },
  ];

  const currentStepIndex = statusSteps.findIndex((step) => step.key === order.status);
  const isCompleted = order.status === "completed";
  const isCancelled = order.status === "cancelled";

  return (
    <Card className="p-6 mb-6">
      {/* Order Header */}
      <div className="mb-6">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-lg font-bold text-arabic-bold">رقم الطلب: #{order.id}</h3>
            <p className="text-sm text-gray-600">
              {new Date(order.createdAt).toLocaleDateString("ar-SA", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary">{order.totalPrice} ريال</p>
          </div>
        </div>
      </div>

      {/* Status Badge */}
      {isCancelled ? (
        <div className="mb-6 inline-block px-4 py-2 bg-red-100 text-red-700 rounded-full text-sm font-semibold">
          تم إلغاء الطلب
        </div>
      ) : (
        <div className="mb-6 inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
          {statusSteps[currentStepIndex]?.label || "حالة غير معروفة"}
        </div>
      )}

      {/* Timeline/Progress Tracker */}
      {!isCancelled && showTimeline && (
        <div className="mt-8">
          <div className="flex items-center justify-between relative">
            {/* Progress Bar Background */}
            <div className="absolute top-5 right-0 left-0 h-1 bg-gray-200 z-0" />

            {/* Progress Bar Filled */}
            <div
              className="absolute top-5 right-0 h-1 bg-gradient-to-l from-emerald-500 to-blue-500 z-0 transition-all duration-500"
              style={{
                width: `${((currentStepIndex + 1) / statusSteps.length) * 100}%`,
              }}
            />

            {/* Status Steps */}
            <div className="flex items-center justify-between w-full relative z-10">
              {statusSteps.map((step, index) => {
                const Icon = step.icon;
                const isActive = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;

                return (
                  <div key={step.key} className="flex flex-col items-center">
                    {/* Icon Circle */}
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mb-3 transition-all duration-300 ${
                        isActive ? `${step.bgColor} ${step.color}` : "bg-gray-100 text-gray-400"
                      } ${isCurrent ? "ring-4 ring-offset-2 ring-primary" : ""}`}
                    >
                      {isActive && index < currentStepIndex ? (
                        <Check className="w-6 h-6" />
                      ) : (
                        <Icon className="w-6 h-6" />
                      )}
                    </div>

                    {/* Step Label */}
                    <div className="text-center">
                      <p
                        className={`text-sm font-semibold text-arabic-bold ${
                          isActive ? "text-foreground" : "text-gray-400"
                        }`}
                      >
                        {step.label}
                      </p>
                      <p
                        className={`text-xs mt-1 ${
                          isActive ? "text-gray-600" : "text-gray-400"
                        }`}
                      >
                        {step.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Estimated Delivery */}
      {!isCancelled && (
        <div className="mt-8 pt-6 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">وقت الطلب</p>
              <p className="font-semibold text-arabic-bold">
                {new Date(order.createdAt).toLocaleTimeString("ar-SA", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">آخر تحديث</p>
              <p className="font-semibold text-arabic-bold">
                {new Date(order.updatedAt).toLocaleTimeString("ar-SA", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>

          {/* Estimated Delivery Time */}
          {order.status !== "completed" && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-700 font-semibold">
                ⏱️ الوقت المتوقع للتسليم: <span className="font-bold">خلال 24 ساعة</span>
              </p>
              <p className="text-xs text-blue-600 mt-1">
                سيتم إخطارك بتحديثات الطلب عبر البريد الإلكتروني والإشعارات
              </p>
            </div>
          )}

          {/* Completion Message */}
          {isCompleted && (
            <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm text-green-700 font-semibold">
                ✓ شكراً لك! تم تسليم طلبك بنجاح
              </p>
              <p className="text-xs text-green-600 mt-1">
                نتمنى أن تكون راضياً عن خدمتنا. يمكنك الآن تقييم طلبك أو الاتصال بنا للمساعدة
              </p>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
