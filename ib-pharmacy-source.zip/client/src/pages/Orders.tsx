import { useState } from "react";
import { Link } from "wouter";
import { ShoppingCart, ArrowRight, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import OrderTracker from "@/components/OrderTracker";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Orders() {
  const { user } = useAuth();
  const [selectedStatus, setSelectedStatus] = useState<string>("all");

  // Mock orders data - في الواقع ستأتي من API
  const mockOrders = [
    {
      id: "ORD-001",
      status: "completed" as const,
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
      totalPrice: 450,
      items: [
        { medicineId: 1, name: "بنادول", quantity: 2, price: 150 },
        { medicineId: 2, name: "أسبرين", quantity: 1, price: 150 },
      ],
    },
    {
      id: "ORD-002",
      status: "ready" as const,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 30 * 60 * 1000),
      totalPrice: 320,
      items: [
        { medicineId: 3, name: "ديكلوفيناك", quantity: 1, price: 320 },
      ],
    },
    {
      id: "ORD-003",
      status: "preparing" as const,
      createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
      updatedAt: new Date(Date.now() - 20 * 60 * 1000),
      totalPrice: 580,
      items: [
        { medicineId: 4, name: "أموكسيسيلين", quantity: 2, price: 290 },
        { medicineId: 5, name: "فيتامين سي", quantity: 1, price: 290 },
      ],
    },
    {
      id: "ORD-004",
      status: "pending" as const,
      createdAt: new Date(Date.now() - 10 * 60 * 1000),
      updatedAt: new Date(Date.now() - 10 * 60 * 1000),
      totalPrice: 250,
      items: [
        { medicineId: 6, name: "كريم مرطب", quantity: 1, price: 250 },
      ],
    },
  ];

  const filteredOrders =
    selectedStatus === "all"
      ? mockOrders
      : mockOrders.filter((order) => order.status === selectedStatus);

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: "قيد الانتظار",
      preparing: "قيد التحضير",
      ready: "جاهز للتسليم",
      completed: "مكتمل",
      cancelled: "ملغى",
    };
    return labels[status] || status;
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: "bg-yellow-100 text-yellow-800",
      preparing: "bg-blue-100 text-blue-800",
      ready: "bg-green-100 text-green-800",
      completed: "bg-emerald-100 text-emerald-800",
      cancelled: "bg-red-100 text-red-800",
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <Card className="p-8 text-center max-w-md">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-yellow-500" />
            <h2 className="text-xl font-bold text-arabic-bold mb-2">يجب تسجيل الدخول</h2>
            <p className="text-gray-600 mb-6">يرجى تسجيل الدخول لعرض طلباتك</p>
            <Button className="w-full bg-primary hover:bg-primary/90">
              تسجيل الدخول
            </Button>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-arabic-bold mb-2">طلباتي</h1>
          <p className="text-gray-600">
            تتبع جميع طلباتك وحالتها بسهولة
          </p>
        </div>

        {/* Tabs for Status Filter */}
        <Tabs
          value={selectedStatus}
          onValueChange={setSelectedStatus}
          className="mb-8"
        >
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-5 gap-2 mb-6">
            <TabsTrigger value="all">جميع الطلبات ({mockOrders.length})</TabsTrigger>
            <TabsTrigger value="pending">قيد الانتظار</TabsTrigger>
            <TabsTrigger value="preparing">قيد التحضير</TabsTrigger>
            <TabsTrigger value="ready">جاهز</TabsTrigger>
            <TabsTrigger value="completed">مكتمل</TabsTrigger>
          </TabsList>

          <TabsContent value={selectedStatus} className="space-y-6">
            {filteredOrders.length > 0 ? (
              <div className="space-y-6">
                {filteredOrders.map((order) => (
                  <OrderTracker key={order.id} order={order} showTimeline={true} />
                ))}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-bold text-arabic-bold mb-2">
                  لا توجد طلبات
                </h3>
                <p className="text-gray-600 mb-6">
                  لم تقم بأي طلبات حتى الآن. ابدأ التسوق الآن!
                </p>
                <Link href="/catalog">
                  <Button className="bg-primary hover:bg-primary/90">
                    <ArrowRight className="w-4 h-4 ml-2" />
                    تصفح الكتالوج
                  </Button>
                </Link>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Order Summary Stats */}
        {filteredOrders.length > 0 && (
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-6">
              <h3 className="text-sm text-gray-600 font-semibold mb-2">إجمالي الإنفاق</h3>
              <p className="text-3xl font-bold text-primary">
                {filteredOrders.reduce((sum, order) => sum + order.totalPrice, 0)} ريال
              </p>
            </Card>
            <Card className="p-6">
              <h3 className="text-sm text-gray-600 font-semibold mb-2">عدد الطلبات</h3>
              <p className="text-3xl font-bold text-blue-600">
                {filteredOrders.length}
              </p>
            </Card>
            <Card className="p-6">
              <h3 className="text-sm text-gray-600 font-semibold mb-2">متوسط قيمة الطلب</h3>
              <p className="text-3xl font-bold text-green-600">
                {Math.round(
                  filteredOrders.reduce((sum, order) => sum + order.totalPrice, 0) /
                    filteredOrders.length
                )}{" "}
                ريال
              </p>
            </Card>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
