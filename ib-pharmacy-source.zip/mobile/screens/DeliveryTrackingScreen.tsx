import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
} from 'react-native';
import * as Location from 'expo-location';
import { mapsService } from '../services/mapsService';
import { notificationsService } from '../services/notificationsService';

interface DeliveryInfo {
  orderId: string;
  status: 'pending' | 'assigned' | 'in_transit' | 'delivered';
  driverName: string;
  driverPhone: string;
  driverRating: number;
  vehicleInfo: string;
  licensePlate: string;
  currentLocation: { latitude: number; longitude: number };
  deliveryLocation: { latitude: number; longitude: number };
  estimatedArrival: Date;
  distance: number;
  estimatedTime: number;
}

export default function DeliveryTrackingScreen({ route }: any) {
  const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo | null>(null);
  const [userLocation, setUserLocation] = useState<Location.LocationObject | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get user location
    (async () => {
      const location = await Location.getCurrentPositionAsync({});
      setUserLocation(location);
    })();

    // Mock delivery info - replace with real API call
    const mockDelivery: DeliveryInfo = {
      orderId: 'ORD-001',
      status: 'in_transit',
      driverName: 'محمد علي',
      driverPhone: '967123456789',
      driverRating: 4.9,
      vehicleInfo: 'Toyota Corolla',
      licensePlate: 'YM-1234',
      currentLocation: { latitude: 15.372, longitude: 44.207 },
      deliveryLocation: { latitude: 15.375, longitude: 44.21 },
      estimatedArrival: new Date(Date.now() + 20 * 60000),
      distance: 2.5,
      estimatedTime: 20,
    };

    setDeliveryInfo(mockDelivery);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!deliveryInfo) return;

    const updateTimer = () => {
      const now = new Date();
      const diff = deliveryInfo.estimatedArrival.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeRemaining('وصل!');
      } else {
        const minutes = Math.floor(diff / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        setTimeRemaining(`${minutes}:${seconds.toString().padStart(2, '0')}`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [deliveryInfo]);

  const handleCallDriver = () => {
    if (deliveryInfo) {
      Linking.openURL(`tel:${deliveryInfo.driverPhone}`);
    }
  };

  const handleOpenMap = () => {
    if (deliveryInfo && userLocation) {
      const url = mapsService.generateDirectionsUrl(
        { latitude: userLocation.coords.latitude, longitude: userLocation.coords.longitude },
        deliveryInfo.currentLocation,
        'driving'
      );
      Linking.openURL(url);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  if (!deliveryInfo) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>لم يتم العثور على معلومات التوصيل</Text>
      </View>
    );
  }

  const getStatusText = () => {
    switch (deliveryInfo.status) {
      case 'pending':
        return 'في انتظار السائق';
      case 'assigned':
        return 'تم تعيين السائق';
      case 'in_transit':
        return 'في الطريق';
      case 'delivered':
        return 'تم التسليم';
      default:
        return 'غير معروف';
    }
  };

  const getStatusColor = () => {
    switch (deliveryInfo.status) {
      case 'delivered':
        return '#10b981';
      case 'in_transit':
        return '#2563eb';
      case 'assigned':
        return '#f59e0b';
      default:
        return '#6b7280';
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* Status Card */}
      <View style={[styles.card, { backgroundColor: getStatusColor() + '20', borderLeftColor: getStatusColor(), borderLeftWidth: 4 }]}>
        <Text style={[styles.statusText, { color: getStatusColor() }]}>
          {getStatusText()}
        </Text>
        {deliveryInfo.status === 'in_transit' && (
          <View style={styles.timerContainer}>
            <Text style={styles.timerLabel}>الوقت المتبقي</Text>
            <Text style={styles.timerValue}>{timeRemaining}</Text>
          </View>
        )}
      </View>

      {/* Driver Information */}
      {deliveryInfo.status !== 'pending' && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>معلومات السائق</Text>
          <View style={styles.driverInfo}>
            <View>
              <Text style={styles.driverName}>{deliveryInfo.driverName}</Text>
              <Text style={styles.driverRating}>⭐ {deliveryInfo.driverRating} / 5</Text>
            </View>
            <TouchableOpacity
              style={styles.callButton}
              onPress={handleCallDriver}
            >
              <Text style={styles.callButtonText}>اتصل</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.vehicleInfo}>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>المركبة</Text>
              <Text style={styles.infoValue}>{deliveryInfo.vehicleInfo}</Text>
            </View>
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>اللوحة</Text>
              <Text style={styles.infoValue}>{deliveryInfo.licensePlate}</Text>
            </View>
          </View>
        </View>
      )}

      {/* Delivery Details */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>تفاصيل التوصيل</Text>
        <View style={styles.detailsGrid}>
          <View style={styles.detailBox}>
            <Text style={styles.detailLabel}>المسافة</Text>
            <Text style={styles.detailValue}>{deliveryInfo.distance} كم</Text>
          </View>
          <View style={styles.detailBox}>
            <Text style={styles.detailLabel}>الوقت المتوقع</Text>
            <Text style={styles.detailValue}>{deliveryInfo.estimatedTime} دقيقة</Text>
          </View>
        </View>

        {/* Timeline */}
        <View style={styles.timeline}>
          {[
            { step: 1, label: 'الصيدلية', completed: true },
            {
              step: 2,
              label: 'في الطريق',
              completed: deliveryInfo.status === 'in_transit' || deliveryInfo.status === 'delivered',
            },
            { step: 3, label: 'عند باب منزلك', completed: deliveryInfo.status === 'delivered' },
          ].map((item) => (
            <View key={item.step} style={styles.timelineItem}>
              <View
                style={[
                  styles.timelineCircle,
                  { backgroundColor: item.completed ? '#10b981' : '#d1d5db' },
                ]}
              >
                <Text style={styles.timelineCircleText}>
                  {item.completed ? '✓' : item.step}
                </Text>
              </View>
              <Text style={[styles.timelineLabel, { color: item.completed ? '#10b981' : '#6b7280' }]}>
                {item.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Map Button */}
      <TouchableOpacity
        style={styles.mapButton}
        onPress={handleOpenMap}
      >
        <Text style={styles.mapButtonText}>📍 فتح على الخريطة</Text>
      </TouchableOpacity>

      {/* Help Section */}
      <View style={styles.helpCard}>
        <Text style={styles.helpTitle}>هل تحتاج مساعدة؟</Text>
        <TouchableOpacity style={styles.helpButton}>
          <Text style={styles.helpButtonText}>📞 اتصل بخدمة العملاء</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.helpButton}>
          <Text style={styles.helpButtonText}>⚠️ الإبلاغ عن مشكلة</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
    padding: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statusText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  timerContainer: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  timerLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 4,
  },
  timerValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2563eb',
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#1f2937',
  },
  driverInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    marginBottom: 12,
  },
  driverName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  driverRating: {
    fontSize: 14,
    color: '#6b7280',
  },
  callButton: {
    backgroundColor: '#2563eb',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  callButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  vehicleInfo: {
    flexDirection: 'row',
    gap: 12,
  },
  infoBox: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    padding: 12,
    borderRadius: 8,
  },
  infoLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  detailsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  detailBox: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2563eb',
  },
  timeline: {
    marginTop: 16,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  timelineCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  timelineCircleText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  timelineLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  mapButton: {
    backgroundColor: '#2563eb',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
  },
  mapButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  helpCard: {
    backgroundColor: '#dbeafe',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  helpTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 12,
  },
  helpButton: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#93c5fd',
  },
  helpButtonText: {
    color: '#1e40af',
    fontWeight: '500',
  },
  errorText: {
    fontSize: 16,
    color: '#dc2626',
    textAlign: 'center',
  },
});

