import { useState, useEffect } from "react";
import { MapPin, Phone, Clock, AlertCircle, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface DeliveryInfo {
  status: "pending" | "assigned" | "in_transit" | "delivered" | "failed";
  driverName: string;
  driverPhone: string;
  driverRating: number;
  vehicleInfo: string;
  licensePlate: string;
  currentLocation: { lat: number; lng: number };
  deliveryLocation: { lat: number; lng: number };
  estimatedArrival: Date;
  distance: number; // km
  estimatedTime: number; // minutes
}

interface DeliveryTrackerProps {
  deliveryInfo: DeliveryInfo;
  onContactDriver?: (phone: string) => void;
}

export default function DeliveryTracker({
  deliveryInfo,
  onContactDriver,
}: DeliveryTrackerProps) {
  const [timeRemaining, setTimeRemaining] = useState<string>("");

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const diff = deliveryInfo.estimatedArrival.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeRemaining("وصل!");
      } else {
        const minutes = Math.floor(diff / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        setTimeRemaining(`${minutes}:${seconds.toString().padStart(2, "0")}`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [deliveryInfo.estimatedArrival]);

  const getStatusColor = () => {
    switch (deliveryInfo.status) {
      case "delivered":
        return "bg-green-50 border-green-200";
      case "in_transit":
        return "bg-blue-50 border-blue-200";
      case "assigned":
        return "bg-yellow-50 border-yellow-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const getStatusText = () => {
    switch (deliveryInfo.status) {
      case "pending":
        return "في انتظار السائق";
      case "assigned":
        return "تم تعيين السائق";
      case "in_transit":
        return "في الطريق";
      case "delivered":
        return "تم التسليم";
      case "failed":
        return "فشل التسليم";
      default:
        return "غير معروف";
    }
  };

  return (
    <div className="space-y-4">
      {/* Status Card */}
      <Card className={`border ${getStatusColor()}`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-arabic-bold flex items-center gap-2">
              {deliveryInfo.status === "delivered" ? (
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              ) : (
                <AlertCircle className="w-6 h-6 text-blue-600" />
              )}
              {getStatusText()}
            </CardTitle>
            {deliveryInfo.status === "in_transit" && (
              <div className="text-right">
                <p className="text-sm text-gray-600">الوقت المتبقي</p>
                <p className="text-2xl font-bold text-primary">{timeRemaining}</p>
              </div>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* Driver Information */}
      {deliveryInfo.status !== "pending" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg text-arabic-bold">
              معلومات السائق
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Driver Profile */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-bold text-arabic-bold">
                  {deliveryInfo.driverName}
                </h4>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-sm text-yellow-500">★</span>
                  <span className="text-sm text-gray-600">
                    {deliveryInfo.driverRating} / 5
                  </span>
                </div>
              </div>
              <Button
                onClick={() => {
                  if (onContactDriver) {
                    onContactDriver(deliveryInfo.driverPhone);
                  } else {
                    window.location.href = `tel:${deliveryInfo.driverPhone}`;
                  }
                }}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                <Phone className="w-4 h-4 ml-2" />
                اتصل
              </Button>
            </div>

            {/* Vehicle Information */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-gray-600 mb-1">المركبة</p>
                <p className="font-semibold text-arabic">
                  {deliveryInfo.vehicleInfo}
                </p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-gray-600 mb-1">لوحة الترخيص</p>
                <p className="font-semibold text-arabic">
                  {deliveryInfo.licensePlate}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Delivery Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-arabic-bold">
            تفاصيل التوصيل
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Distance and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg text-center">
              <MapPin className="w-6 h-6 mx-auto mb-2 text-primary" />
              <p className="text-sm text-gray-600 mb-1">المسافة</p>
              <p className="text-2xl font-bold text-arabic-bold">
                {deliveryInfo.distance} كم
              </p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg text-center">
              <Clock className="w-6 h-6 mx-auto mb-2 text-primary" />
              <p className="text-sm text-gray-600 mb-1">الوقت المتوقع</p>
              <p className="text-2xl font-bold text-arabic-bold">
                {deliveryInfo.estimatedTime} دقيقة
              </p>
            </div>
          </div>

          {/* Timeline Steps */}
          <div className="space-y-3 mt-6">
            {[
              {
                step: 1,
                label: "الصيدلية",
                completed: true,
              },
              {
                step: 2,
                label: "في الطريق",
                completed:
                  deliveryInfo.status === "in_transit" ||
                  deliveryInfo.status === "delivered",
              },
              {
                step: 3,
                label: "عند باب منزلك",
                completed: deliveryInfo.status === "delivered",
              },
            ].map((item) => (
              <div key={item.step} className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                    item.completed ? "bg-green-500" : "bg-gray-300"
                  }`}
                >
                  {item.completed ? "✓" : item.step}
                </div>
                <span
                  className={`text-arabic ${
                    item.completed ? "font-semibold" : "text-gray-500"
                  }`}
                >
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Map Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-arabic-bold">
            الموقع على الخريطة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-12 h-12 mx-auto text-gray-400 mb-2" />
              <p className="text-gray-600 text-arabic">
                خريطة Google Maps ستظهر هنا
              </p>
              <p className="text-sm text-gray-500 mt-1">
                الموقع: {deliveryInfo.currentLocation.lat.toFixed(4)},
                {deliveryInfo.currentLocation.lng.toFixed(4)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Help Section */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <h4 className="font-semibold text-arabic-bold mb-3">هل تحتاج مساعدة؟</h4>
          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start text-arabic"
            >
              <Phone className="w-4 h-4 ml-2" />
              اتصل بخدمة العملاء
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start text-arabic"
            >
              <AlertCircle className="w-4 h-4 ml-2" />
              الإبلاغ عن مشكلة
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
