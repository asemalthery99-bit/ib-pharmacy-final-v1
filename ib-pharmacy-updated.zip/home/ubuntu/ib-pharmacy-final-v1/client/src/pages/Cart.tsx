import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Trash2, Plus, Minus, Tag } from "lucide-react";
import { toast } from "sonner";

export default function Cart() {
  const [, navigate] = useLocation();
  const [promoCode, setPromoCode] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<any>(null);

  // Fetch cart
  const { data: cart } = trpc.cart.getCart.useQuery();
  const updateCartMutation = trpc.cart.updateCart.useMutation();
  const validatePromoQuery = trpc.promoCodes.validate.useQuery({ code: promoCode }, { enabled: false });
  const createOrderMutation = trpc.orders.create.useMutation();

  // Parse cart items
  const cartItems = cart?.items ? JSON.parse(typeof cart.items === "string" ? cart.items : JSON.stringify(cart.items)) : [];

  const handleUpdateQuantity = async (medicineId: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(medicineId);
      return;
    }
    const updatedItems = cartItems.map((item: any) =>
      item.medicineId === medicineId ? { ...item, quantity } : item
    );
    await updateCartMutation.mutateAsync({ items: updatedItems });
  };

  const handleRemoveItem = async (medicineId: number) => {
    const updatedItems = cartItems.filter((item: any) => item.medicineId !== medicineId);
    await updateCartMutation.mutateAsync({ items: updatedItems });
    toast.success("تم إزالة العنصر من السلة");
  };

  const handleApplyPromo = async () => {
    try {
      const result = await validatePromoQuery.refetch();
      if (result.data) {
        setAppliedPromo(result.data);
        toast.success("تم تطبيق كود الخصم بنجاح");
      }
    } catch (error: any) {
      toast.error(error.message || "كود الخصم غير صحيح");
    }
  };

  const calculateTotal = () => {
    let total = 0;
    cartItems.forEach((item: any) => {
      total += item.quantity * (item.priceAtTime || 0);
    });
    return total;
  };

  const calculateDiscount = () => {
    const total = calculateTotal();
    if (!appliedPromo) return 0;

    if (appliedPromo.discountType === "percentage") {
      const discount = (total * parseFloat(appliedPromo.discountValue)) / 100;
      return Math.min(discount, appliedPromo.maxDiscount ? parseFloat(appliedPromo.maxDiscount) : discount);
    } else {
      return Math.min(parseFloat(appliedPromo.discountValue), total);
    }
  };

  const total = calculateTotal();
  const discount = calculateDiscount();
  const finalTotal = total - discount;

  const handleCheckout = async () => {
    if (cartItems.length === 0) {
      toast.error("السلة فارغة");
      return;
    }

    try {
      const result = await createOrderMutation.mutateAsync({
        items: cartItems,
        totalPrice: finalTotal.toString(),
        discountAmount: discount.toString(),
        promoCodeId: appliedPromo?.id,
      });
      toast.success("تم إنشاء الطلب بنجاح");
      navigate(`/orders/${result.orderId}`);
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إنشاء الطلب");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container max-w-6xl mx-auto px-4 py-4">
          <h1 className="text-3xl font-bold text-gray-900">سلتي</h1>
        </div>
      </div>

      <div className="container max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            {cartItems.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <p className="text-gray-500 text-lg mb-4">السلة فارغة</p>
                  <Button onClick={() => navigate("/catalog")} className="bg-green-600 hover:bg-green-700">
                    تصفح الأدوية
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {cartItems.map((item: any) => (
                  <Card key={item.medicineId}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{item.medicineName || `الدواء #${item.medicineId}`}</h3>
                          <p className="text-gray-600 text-sm">السعر: {item.priceAtTime} ر.ي</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateQuantity(item.medicineId, item.quantity - 1)}
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <span className="w-8 text-center font-semibold">{item.quantity}</span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateQuantity(item.medicineId, item.quantity + 1)}
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRemoveItem(item.medicineId)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="mt-2 text-right">
                        <p className="font-bold text-lg text-green-600">
                          {(item.quantity * item.priceAtTime).toFixed(2)} ر.ي
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>ملخص الطلب</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Promo Code */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">كود الخصم</label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="أدخل كود الخصم"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      disabled={!!appliedPromo}
                    />
                    {!appliedPromo ? (
                      <Button
                        size="sm"
                        onClick={handleApplyPromo}
                        disabled={!promoCode || validatePromoQuery.isFetching}
                      >
                        <Tag className="w-4 h-4" />
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setAppliedPromo(null);
                          setPromoCode("");
                        }}
                      >
                        إزالة
                      </Button>
                    )}
                  </div>
                  {appliedPromo && (
                    <p className="text-sm text-green-600 mt-2">✓ تم تطبيق الخصم: {appliedPromo.code}</p>
                  )}
                </div>

                {/* Totals */}
                <div className="border-t border-gray-200 pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">الإجمالي</span>
                    <span className="font-semibold">{total.toFixed(2)} ر.ي</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>الخصم</span>
                      <span>-{discount.toFixed(2)} ر.ي</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold border-t border-gray-200 pt-2">
                    <span>الإجمالي النهائي</span>
                    <span className="text-green-600">{finalTotal.toFixed(2)} ر.ي</span>
                  </div>
                </div>

                {/* Checkout Button */}
                <Button
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                  size="lg"
                  onClick={handleCheckout}
                  disabled={cartItems.length === 0 || createOrderMutation.isPending}
                >
                  {createOrderMutation.isPending ? "جاري المعالجة..." : "إتمام الشراء"}
                </Button>

                {/* Continue Shopping */}
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => navigate("/catalog")}
                >
                  متابعة التسوق
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
