import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Star, ShoppingCart, Search } from "lucide-react";
import { toast } from "sonner";

export default function Catalog() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();
  const [minPrice, setMinPrice] = useState<number | undefined>();
  const [maxPrice, setMaxPrice] = useState<number | undefined>();

  // Fetch medicines
  const { data: medicines = [] } = trpc.medicines.list.useQuery();
  const { data: categories = [] } = trpc.categories.list.useQuery();

  // Search medicines
  const { data: searchResults = [] } = trpc.medicines.search.useQuery({
    query: searchQuery || undefined,
    categoryId: selectedCategory,
    minPrice,
    maxPrice,
  });

  // Get ratings for each medicine
  const medicinesWithRatings = useMemo(() => {
    return (searchQuery || selectedCategory || minPrice || maxPrice ? searchResults : medicines).map(medicine => ({
      ...medicine,
      // Rating will be fetched separately
    }));
  }, [medicines, searchResults, searchQuery, selectedCategory, minPrice, maxPrice]);

  const handleAddToCart = (medicineId: number, medicineName: string) => {
    // This will be implemented with cart functionality
    toast.success(`تمت إضافة ${medicineName} إلى السلة`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container max-w-6xl mx-auto px-4 py-4">
          <h1 className="text-3xl font-bold text-gray-900">كتالوج الأدوية</h1>
        </div>
      </div>

      <div className="container max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Filters */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">البحث والفلترة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Search */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">البحث</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="ابحث عن دواء..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Categories */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">الفئة</label>
                  <select
                    value={selectedCategory || ""}
                    onChange={(e) => setSelectedCategory(e.target.value ? parseInt(e.target.value) : undefined)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">جميع الفئات</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نطاق السعر</label>
                  <div className="space-y-2">
                    <Input
                      type="number"
                      placeholder="السعر الأدنى"
                      value={minPrice || ""}
                      onChange={(e) => setMinPrice(e.target.value ? parseInt(e.target.value) : undefined)}
                    />
                    <Input
                      type="number"
                      placeholder="السعر الأعلى"
                      value={maxPrice || ""}
                      onChange={(e) => setMaxPrice(e.target.value ? parseInt(e.target.value) : undefined)}
                    />
                  </div>
                </div>

                {/* Clear Filters */}
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory(undefined);
                    setMinPrice(undefined);
                    setMaxPrice(undefined);
                  }}
                >
                  مسح الفلاتر
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content - Medicines Grid */}
          <div className="lg:col-span-3">
            {medicinesWithRatings.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">لم يتم العثور على أدوية</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {medicinesWithRatings.map((medicine) => (
                  <Card key={medicine.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      {medicine.imageUrl && (
                        <img
                          src={medicine.imageUrl}
                          alt={medicine.name}
                          className="w-full h-40 object-cover rounded-md mb-4"
                        />
                      )}
                      <CardTitle className="text-lg">{medicine.name}</CardTitle>
                      <CardDescription className="text-sm">
                        {medicine.activeIngredient && (
                          <span className="block">المادة الفعالة: {medicine.activeIngredient}</span>
                        )}
                        {medicine.manufacturer && (
                          <span className="block">الشركة المصنعة: {medicine.manufacturer}</span>
                        )}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {medicine.description && (
                        <p className="text-sm text-gray-600 mb-4">{medicine.description}</p>
                      )}

                      {/* Rating */}
                      <div className="flex items-center gap-2 mb-4">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < Math.round(4.5)
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-600">(4.5)</span>
                      </div>

                      {/* Price and Actions */}
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-2xl font-bold text-green-600">
                            {parseFloat(medicine.price as any).toFixed(2)} ر.ي
                          </p>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => handleAddToCart(medicine.id, medicine.name)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          أضف
                        </Button>
                      </div>

                      {medicine.requiresPrescription && (
                        <p className="text-xs text-red-600 mt-2">⚠️ يتطلب وصفة طبية</p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
