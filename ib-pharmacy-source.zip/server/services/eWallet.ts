/**
 * E-Wallet Service
 * Manages digital wallet, balance, and fast payments
 */

export interface Wallet {
  id: string;
  userId: string;
  balance: number; // USD
  currency: string;
  createdAt: Date;
  lastUpdated: Date;
  status: 'active' | 'suspended' | 'closed';
}

export interface WalletTransaction {
  id: string;
  walletId: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'payment' | 'refund' | 'bonus';
  amount: number;
  currency: string;
  description: string;
  relatedOrderId?: string;
  paymentMethod?: 'credit_card' | 'debit_card' | 'bank_transfer' | 'paypal';
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  transactionDate: Date;
  completedDate?: Date;
  reference: string;
  notes?: string;
}

export interface WalletRecharge {
  id: string;
  walletId: string;
  userId: string;
  amount: number;
  paymentMethod: 'credit_card' | 'debit_card' | 'bank_transfer' | 'paypal';
  status: 'pending' | 'completed' | 'failed';
  createdAt: Date;
  completedAt?: Date;
  reference: string;
}

export interface WalletStatement {
  userId: string;
  startDate: Date;
  endDate: Date;
  openingBalance: number;
  closingBalance: number;
  totalDeposits: number;
  totalWithdrawals: number;
  totalPayments: number;
  totalRefunds: number;
  transactions: WalletTransaction[];
}

/**
 * Create wallet for new user
 */
export async function createWallet(userId: string): Promise<Wallet> {
  const wallet: Wallet = {
    id: `WALLET-${userId}`,
    userId,
    balance: 0,
    currency: 'USD',
    createdAt: new Date(),
    lastUpdated: new Date(),
    status: 'active',
  };

  console.log('Wallet created:', wallet);
  return wallet;
}

/**
 * Get wallet balance
 */
export async function getWalletBalance(userId: string): Promise<number> {
  // In production, fetch from database
  // Mock data
  return 150.5;
}

/**
 * Get wallet details
 */
export async function getWallet(userId: string): Promise<Wallet | null> {
  // Mock wallet
  return {
    id: `WALLET-${userId}`,
    userId,
    balance: 150.5,
    currency: 'USD',
    createdAt: new Date('2025-01-01'),
    lastUpdated: new Date(),
    status: 'active',
  };
}

/**
 * Add funds to wallet (recharge)
 */
export async function rechargeWallet(
  userId: string,
  amount: number,
  paymentMethod: 'credit_card' | 'debit_card' | 'bank_transfer' | 'paypal'): Promise<WalletRecharge | null> {
  if (amount <= 0) {
    console.error('Invalid amount');
    return null;
  }

  const recharge: WalletRecharge = {
    id: `RECHARGE-${Date.now()}`,
    walletId: `WALLET-${userId}`,
    userId,
    amount,
    paymentMethod,
    status: 'pending',
    createdAt: new Date(),
    reference: `REF-${Date.now()}`,
  };

  console.log('Wallet recharge initiated:', recharge);
  return recharge;
}

/**
 * Complete wallet recharge
 */
export async function completeRecharge(
  rechargeId: string,
  transactionReference: string
): Promise<boolean> {
  console.log(
    `Recharge ${rechargeId} completed with reference ${transactionReference}`
  );
  return true;
}

/**
 * Pay from wallet
 */
export async function payFromWallet(
  userId: string,
  orderId: string,
  amount: number,
  description: string
): Promise<WalletTransaction | null> {
  // Check balance
  const balance = await getWalletBalance(userId);
  if (balance < amount) {
    console.error('Insufficient balance');
    return null;
  }

  const transaction: WalletTransaction = {
    id: `TXN-${Date.now()}`,
    walletId: `WALLET-${userId}`,
    userId,
    type: 'payment',
    amount,
    currency: 'USD',
    description,
    relatedOrderId: orderId,
    status: 'completed',
    transactionDate: new Date(),
    completedDate: new Date(),
    reference: `PAY-${Date.now()}`,
  };

  console.log('Payment from wallet completed:', transaction);
  return transaction;
}

/**
 * Get wallet transaction history
 */
export async function getWalletTransactionHistory(
  userId: string,
  limit: number = 50,
  offset: number = 0
): Promise<WalletTransaction[]> {
  // Mock transactions
  const mockTransactions: WalletTransaction[] = [
    {
      id: 'TXN-001',
      walletId: `WALLET-${userId}`,
      userId,
      type: 'deposit',
      amount: 100,
      currency: 'USD',
      description: 'Wallet recharge',
      paymentMethod: 'credit_card',
      status: 'completed',
      transactionDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      completedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      reference: 'REF-001',
    },
    {
      id: 'TXN-002',
      walletId: `WALLET-${userId}`,
      userId,
      type: 'payment',
      amount: 25.5,
      currency: 'USD',
      description: 'Order ORD-001 payment',
      relatedOrderId: 'ORD-001',
      status: 'completed',
      transactionDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      completedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      reference: 'PAY-001',
    },
    {
      id: 'TXN-003',
      walletId: `WALLET-${userId}`,
      userId,
      type: 'bonus',
      amount: 10,
      currency: 'USD',
      description: 'Loyalty program bonus',
      status: 'completed',
      transactionDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      completedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      reference: 'BON-001',
    },
  ];

  return mockTransactions.slice(offset, offset + limit);
}

/**
 * Get wallet statement for period
 */
export async function getWalletStatement(
  userId: string,
  startDate: Date,
  endDate: Date
): Promise<WalletStatement> {
  const transactions = await getWalletTransactionHistory(userId, 1000);
  const periodTransactions = transactions.filter(
    (t) =>
      new Date(t.transactionDate) >= startDate &&
      new Date(t.transactionDate) <= endDate
  );

  const totalDeposits = periodTransactions
    .filter((t) => t.type === 'deposit')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalWithdrawals = periodTransactions
    .filter((t) => t.type === 'withdrawal')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalPayments = periodTransactions
    .filter((t) => t.type === 'payment')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalRefunds = periodTransactions
    .filter((t) => t.type === 'refund')
    .reduce((sum, t) => sum + t.amount, 0);

  const currentBalance = await getWalletBalance(userId);
  const openingBalance =
    currentBalance - totalDeposits + totalWithdrawals + totalPayments - totalRefunds;

  return {
    userId,
    startDate,
    endDate,
    openingBalance,
    closingBalance: currentBalance,
    totalDeposits,
    totalWithdrawals,
    totalPayments,
    totalRefunds,
    transactions: periodTransactions,
  };
}

/**
 * Refund to wallet
 */
export async function refundToWallet(
  userId: string,
  orderId: string,
  amount: number,
  reason: string
): Promise<WalletTransaction | null> {
  const transaction: WalletTransaction = {
    id: `TXN-${Date.now()}`,
    walletId: `WALLET-${userId}`,
    userId,
    type: 'refund',
    amount,
    currency: 'USD',
    description: `Refund for order ${orderId}: ${reason}`,
    relatedOrderId: orderId,
    status: 'completed',
    transactionDate: new Date(),
    completedDate: new Date(),
    reference: `REFUND-${Date.now()}`,
  };

  console.log('Refund to wallet processed:', transaction);
  return transaction;
}

/**
 * Add loyalty bonus to wallet
 */
export async function addLoyaltyBonus(
  userId: string,
  amount: number,
  reason: string
): Promise<WalletTransaction | null> {
  const transaction: WalletTransaction = {
    id: `TXN-${Date.now()}`,
    walletId: `WALLET-${userId}`,
    userId,
    type: 'bonus',
    amount,
    currency: 'USD',
    description: `Loyalty bonus: ${reason}`,
    status: 'completed',
    transactionDate: new Date(),
    completedDate: new Date(),
    reference: `BONUS-${Date.now()}`,
  };

  console.log('Loyalty bonus added to wallet:', transaction);
  return transaction;
}

/**
 * Get wallet statistics
 */
export async function getWalletStatistics(userId: string): Promise<{
  totalDeposits: number;
  totalSpent: number;
  averageTransaction: number;
  frequencyPerMonth: number;
  lastTransaction: Date | null;
}> {
  const transactions = await getWalletTransactionHistory(userId, 1000);

  const totalDeposits = transactions
    .filter((t) => t.type === 'deposit')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalSpent = transactions
    .filter((t) => t.type === 'payment')
    .reduce((sum, t) => sum + t.amount, 0);

  const averageTransaction =
    transactions.length > 0 ? totalSpent / transactions.length : 0;

  // Calculate frequency
  const last30Days = transactions.filter(
    (t) =>
      new Date(t.transactionDate).getTime() >
      Date.now() - 30 * 24 * 60 * 60 * 1000
  );
  const frequencyPerMonth = (last30Days.length / 30) * 30;

  const lastTransaction =
    transactions.length > 0
      ? new Date(transactions[0].transactionDate)
      : null;

  return {
    totalDeposits,
    totalSpent,
    averageTransaction: Math.round(averageTransaction * 100) / 100,
    frequencyPerMonth: Math.round(frequencyPerMonth),
    lastTransaction,
  };
}

/**
 * Check if wallet has sufficient balance
 */
export async function hasSufficientBalance(
  userId: string,
  amount: number
): Promise<boolean> {
  const balance = await getWalletBalance(userId);
  return balance >= amount;
}

/**
 * Withdraw from wallet (admin only)
 */
export async function withdrawFromWallet(
  userId: string,
  amount: number,
  reason: string,
  adminId: string
): Promise<WalletTransaction | null> {
  const balance = await getWalletBalance(userId);
  if (balance < amount) {
    console.error('Insufficient balance for withdrawal');
    return null;
  }

  const transaction: WalletTransaction = {
    id: `TXN-${Date.now()}`,
    walletId: `WALLET-${userId}`,
    userId,
    type: 'withdrawal',
    amount,
    currency: 'USD',
    description: `Withdrawal by admin ${adminId}: ${reason}`,
    status: 'completed',
    transactionDate: new Date(),
    completedDate: new Date(),
    reference: `WITHDRAW-${Date.now()}`,
  };

  console.log('Withdrawal from wallet processed:', transaction);
  return transaction;
}

