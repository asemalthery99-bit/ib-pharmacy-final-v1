# دليل التشغيل والنشر - الإصدار 3.7
## صيدلية إب الرقمية - دليل شامل للعمليات التجارية

---

## نظرة عامة

هذا الدليل يشرح كيفية تحويل المشروع من "كود برمجي" إلى "منصة تجارية حقيقية" جاهزة لاستقبال الطلبات والأموال الفعلية.

---

## 1. إعداد ملفات الإعدادات (API Keys Setup)

### 1.1 نسخ ملف الإعدادات

```bash
# انسخ ملف الإعدادات الأساسي
cp .env.example .env.local
cp .env.example .env.production
```

### 1.2 ملء مفاتيح الخدمات الخارجية

افتح ملف `.env.local` وأضف قيمك الخاصة:

#### أ) PayPal API Keys
```bash
# 1. اذهب إلى https://developer.paypal.com
# 2. سجل دخول أو أنشئ حساب
# 3. انتقل إلى "Apps & Credentials"
# 4. انسخ Client ID و Secret

PAYPAL_CLIENT_ID="your_actual_client_id"
PAYPAL_CLIENT_SECRET="your_actual_secret"
PAYPAL_MODE="sandbox"  # استخدم sandbox للاختبار
```

#### ب) Google Maps API Keys
```bash
# 1. اذهب إلى https://console.cloud.google.com
# 2. أنشئ مشروع جديد
# 3. فعّل APIs:
#    - Maps JavaScript API
#    - Places API
#    - Geocoding API
# 4. أنشئ API Key

GOOGLE_MAPS_API_KEY="your_actual_maps_key"
GOOGLE_MAPS_PLACES_API_KEY="your_actual_places_key"
GOOGLE_MAPS_GEOCODING_API_KEY="your_actual_geocoding_key"
```

#### ج) OpenAI API Key
```bash
# 1. اذهب إلى https://platform.openai.com
# 2. انتقل إلى API Keys
# 3. أنشئ مفتاح جديد

OPENAI_API_KEY="your_actual_openai_key"
OPENAI_MODEL="gpt-4o-mini"
```

#### د) Aramex Shipping API
```bash
# 1. اتصل بـ Aramex أو اذهب إلى https://www.aramex.com
# 2. اطلب بيانات API
# 3. احصل على Account Number و Entity ID

ARAMEX_API_KEY="your_actual_key"
ARAMEX_ACCOUNT_NUMBER="your_account_number"
ARAMEX_ENTITY_ID="your_entity_id"
ARAMEX_PASSWORD="your_password"
ARAMEX_MODE="test"  # استخدم test أولاً
```

#### هـ) DHL Shipping API
```bash
# 1. اذهب إلى https://developer.dhl.com
# 2. سجل حساب تطوير
# 3. احصل على API Key

DHL_API_KEY="your_actual_dhl_key"
DHL_ACCOUNT_NUMBER="your_dhl_account"
DHL_MODE="test"
```

#### و) Firebase (للإشعارات)
```bash
# 1. اذهب إلى https://console.firebase.google.com
# 2. أنشئ مشروع جديد
# 3. أضف تطبيق ويب
# 4. انسخ بيانات الاتصال

FIREBASE_API_KEY="your_firebase_api_key"
FIREBASE_PROJECT_ID="your_project_id"
FIREBASE_MESSAGING_SENDER_ID="your_sender_id"
```

#### ز) AWS S3 (لتخزين الصور)
```bash
# 1. أنشئ حساب AWS
# 2. أنشئ bucket جديد
# 3. أنشئ IAM user مع صلاحيات S3
# 4. احصل على Access Key و Secret Key

AWS_ACCESS_KEY_ID="your_access_key"
AWS_SECRET_ACCESS_KEY="your_secret_key"
AWS_S3_BUCKET="your_bucket_name"
```

### 1.3 اختبار الاتصالات

```bash
# اختبر الاتصال بـ PayPal
npm run test:paypal

# اختبر الاتصال بـ Google Maps
npm run test:maps

# اختبر الاتصال بـ OpenAI
npm run test:openai
```

---

## 2. تغذية البيانات الحقيقية (Real Data Seeding)

### 2.1 إعداد قائمة الأدوية

#### الطريقة الأولى: استخدام ملف CSV

```bash
# 1. افتح ملف medicines_template.csv
# 2. أضف أدويتك الحقيقية (استبدل البيانات التجريبية)
# 3. احفظ الملف

# 2. استيراد البيانات
npm run seed:medicines

# أو مع مسار مخصص
npm run seed:medicines -- ./my_medicines.csv
```

#### الطريقة الثانية: إدراج يدوي عبر الواجهة

```bash
# 1. ادخل إلى لوحة التحكم (Admin Dashboard)
# 2. اذهب إلى "إدارة المنتجات"
# 3. انقر "إضافة منتج جديد"
# 4. أملأ التفاصيل وأضف صورة
# 5. انقر "حفظ"
```

### 2.2 هيكل بيانات الدواء

```csv
medicineId,medicineName,arabicName,description,arabicDescription,category,price,quantity,manufacturer,activeIngredient,dosage,sideEffects,contraindications,warnings,imageUrl,barcode,expiryDate,requiresPrescription,isOTC,popularity,rating,reviews
```

**الحقول المطلوبة:**
- `medicineId`: معرّف فريد (مثل: MED-001)
- `medicineName`: الاسم بالإنجليزية
- `arabicName`: الاسم بالعربية
- `price`: السعر بالدولار
- `quantity`: الكمية المتوفرة
- `category`: الفئة (مثل: Pain Relief, Diabetes)
- `expiryDate`: تاريخ انتهاء الصلاحية (YYYY-MM-DD)
- `requiresPrescription`: هل يحتاج وصفة طبية (true/false)
- `isOTC`: هل متاح بدون وصفة (true/false)

### 2.3 مثال على صف واحد من البيانات

```csv
MED-001,Paracetamol,بنادول,Pain reliever and fever reducer,مسكن للألم وخافض للحرارة,Pain Relief,5.99,500,GSK,Paracetamol,500mg,Rare: liver damage,Liver disease,Do not exceed 4000mg daily,https://example.com/paracetamol.jpg,1234567890123,2026-12-31,false,true,95,4.8,1250
```

### 2.4 التحقق من البيانات المستوردة

```bash
# عرض إحصائيات الأدوية
npm run stats:medicines

# النتيجة:
# 📊 Medicine Statistics:
#    Total Medicines: 15
#    Total Inventory Value: $1,250.50
#    Average Price: $8.34
#    Average Rating: 4.6/5
#    Categories: 8
#    Prescription Required: 4
#    OTC Medicines: 11
```

---

## 3. إعداد قاعدة البيانات (Database Setup)

### 3.1 إنشاء قاعدة البيانات

```bash
# تشغيل المهاجرات (Migrations)
npm run db:migrate

# التحقق من الاتصال
npm run db:check
```

### 3.2 إعدادات الاتصال

```bash
# في ملف .env.local
DATABASE_URL="mysql://username:password@localhost:3306/ibpharmacy_db"
```

---

## 4. الاختبار قبل الإطلاق (Pre-Launch Testing)

### 4.1 اختبار الدفع

```bash
# اختبر عملية الدفع بـ PayPal
npm run test:payment

# استخدم بيانات اختبار PayPal:
# البريد: sb-buyer@example.com
# كلمة المرور: test123
```

### 4.2 اختبار الإشعارات

```bash
# أرسل إشعار اختبار
npm run test:notifications
```

### 4.3 اختبار الخرائط

```bash
# اختبر خدمة الخرائط
npm run test:maps
```

### 4.4 اختبار الذكاء الاصطناعي

```bash
# اختبر المساعد الصيدلاني
npm run test:ai-chatbot
```

---

## 5. النشر على الإنتاج (Production Deployment)

### 5.1 اختيار منصة الاستضافة

#### الخيار الأول: Vercel (موصى به للويب)
```bash
# 1. انشئ حساب على https://vercel.com
# 2. ربط مستودع GitHub
# 3. اختر المشروع
# 4. أضف متغيرات البيئة (.env variables)
# 5. انقر Deploy
```

#### الخيار الثاني: AWS (للتحكم الكامل)
```bash
# 1. أنشئ EC2 instance
# 2. ثبّت Node.js و MySQL
# 3. استنسخ المشروع
# 4. شغّل npm install && npm run build
# 5. استخدم PM2 للإشراف على العملية
```

#### الخيار الثالث: DigitalOcean (اقتصادي)
```bash
# 1. أنشئ Droplet
# 2. ثبّت البيئة
# 3. استنسخ المشروع
# 4. استخدم Docker للتوزيع
```

### 5.2 إعدادات الإنتاج

```bash
# انسخ ملف الإعدادات
cp .env.example .env.production

# عدّل القيم للإنتاج
NODE_ENV="production"
PAYPAL_MODE="live"  # استخدم live وليس sandbox
ARAMEX_MODE="production"
DHL_MODE="production"
```

### 5.3 بناء وتشغيل المشروع

```bash
# بناء المشروع
npm run build

# تشغيل الخادم
npm run start

# أو استخدم PM2
pm2 start npm --name "ibpharmacy" -- start
```

---

## 6. المراقبة والصيانة (Monitoring & Maintenance)

### 6.1 مراقبة الأداء

```bash
# عرض السجلات
npm run logs

# مراقبة استخدام الموارد
npm run monitor
```

### 6.2 النسخ الاحتياطية

```bash
# عمل نسخة احتياطية من قاعدة البيانات
npm run backup:db

# استعادة من نسخة احتياطية
npm run restore:db
```

### 6.3 التحديثات

```bash
# تحديث المكتبات
npm update

# تشغيل الاختبارات
npm test

# نشر التحديثات
git push origin main
```

---

## 7. قائمة التحقق قبل الإطلاق (Launch Checklist)

- [ ] تم ملء جميع مفاتيح API
- [ ] تم اختبار جميع الاتصالات
- [ ] تم استيراد قائمة الأدوية
- [ ] تم اختبار عملية الدفع
- [ ] تم اختبار الإشعارات
- [ ] تم اختبار الخرائط
- [ ] تم إضافة سياسة الخصوصية
- [ ] تم إضافة شروط الخدمة
- [ ] تم شراء اسم النطاق
- [ ] تم إعداد شهادة SSL
- [ ] تم تفعيل HTTPS
- [ ] تم إعداد البريد الإلكتروني
- [ ] تم اختبار الأداء تحت الحمل
- [ ] تم إعداد نظام المراقبة
- [ ] تم إعداد النسخ الاحتياطية

---

## 8. استكشاف الأخطاء (Troubleshooting)

### المشكلة: "API Key غير صحيح"
```bash
# الحل:
# 1. تحقق من نسخ المفتاح بشكل صحيح
# 2. تأكد من عدم وجود مسافات إضافية
# 3. تحقق من أن المفتاح نشط في لوحة التحكم
```

### المشكلة: "الدفع لا يعمل"
```bash
# الحل:
# 1. تحقق من أنك في وضع sandbox
# 2. استخدم بيانات اختبار PayPal
# 3. تحقق من السجلات (logs)
```

### المشكلة: "الخرائط لا تظهر"
```bash
# الحل:
# 1. تحقق من تفعيل Maps API
# 2. تحقق من قيود المفتاح (Key restrictions)
# 3. امسح ذاكرة التخزين المؤقتة (cache)
```

---

## 9. الدعم والمساعدة

إذا واجهت أي مشاكل:

1. **تحقق من السجلات:** `npm run logs`
2. **اقرأ الأخطاء بعناية:** غالباً ما تكون واضحة
3. **ابحث في التوثيق:** جميع الخدمات لها توثيق شامل
4. **اطلب المساعدة:** تواصل مع فريق الدعم

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.7
**الحالة:** ✅ جاهز للإطلاق التجاري

