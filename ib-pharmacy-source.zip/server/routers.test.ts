import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

describe("Pharmacy API", () => {
  describe("Medicines Router", () => {
    it("should list all medicines", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      expect(Array.isArray(medicines)).toBe(true);
      expect(medicines.length).toBeGreaterThan(0);
    });

    it("should get medicine by ID", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      if (medicines.length > 0) {
        const medicine = await caller.medicines.getById({ id: medicines[0].id });
        expect(medicine).toBeDefined();
        expect(medicine.id).toBe(medicines[0].id);
      }
    });

    it("should search medicines by category", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.medicines.getByCategory({ category: "pain-relief" });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("Inventory Router", () => {
    it("should get inventory by medicine ID", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      if (medicines.length > 0) {
        const inv = await caller.inventory.getByMedicineId({ medicineId: medicines[0].id });
        if (inv) {
          expect(inv.medicineId).toBe(medicines[0].id);
        }
      }
    });

    it("should get low stock medicines", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const lowStock = await caller.inventory.getLowStock({ threshold: 50 });
      expect(Array.isArray(lowStock)).toBe(true);
    });
  });

  describe("Cart Router", () => {
    it("should handle cart operations with authenticated user", async () => {
      const mockUser = {
        id: 999,
        openId: "test-user-999",
        name: "Test User",
        email: "test@example.com",
        loginMethod: "test",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const caller = appRouter.createCaller({
        user: mockUser,
        req: {} as any,
        res: {} as any,
      });

      const medicines = await caller.medicines.list();
      if (medicines.length > 0) {
        await caller.cart.addItem({
          medicineId: medicines[0].id,
          quantity: 2,
        });

        const cart = await caller.cart.getCart();
        expect(Array.isArray(cart)).toBe(true);
      }
    });
  });
});
