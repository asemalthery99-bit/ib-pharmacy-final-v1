CREATE TABLE `cart` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`items` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cart_id` PRIMARY KEY(`id`),
	CONSTRAINT `cart_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`imageUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `categories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `deliveryStages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`deliveryTrackingId` int NOT NULL,
	`stage` varchar(100) NOT NULL,
	`description` text,
	`lat` decimal(10,8),
	`lng` decimal(11,8),
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `deliveryStages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `deliveryTracking` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`driverId` int,
	`currentStatus` enum('pending','assigned','picked_up','in_transit','delivered','failed') NOT NULL DEFAULT 'pending',
	`currentLat` decimal(10,8),
	`currentLng` decimal(11,8),
	`estimatedDeliveryTime` timestamp,
	`actualDeliveryTime` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `deliveryTracking_id` PRIMARY KEY(`id`),
	CONSTRAINT `deliveryTracking_orderId_unique` UNIQUE(`orderId`)
);
--> statement-breakpoint
CREATE TABLE `driverRatings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`driverId` int NOT NULL,
	`orderId` int NOT NULL,
	`score` int NOT NULL,
	`comment` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `driverRatings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`medicineId` int NOT NULL,
	`quantity` int NOT NULL DEFAULT 0,
	`minThreshold` int DEFAULT 50,
	`maxThreshold` int DEFAULT 1000,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `inventory_id` PRIMARY KEY(`id`),
	CONSTRAINT `inventory_medicineId_unique` UNIQUE(`medicineId`)
);
--> statement-breakpoint
CREATE TABLE `medicines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`categoryId` int NOT NULL,
	`price` decimal(10,2) NOT NULL,
	`imageUrl` text,
	`activeIngredient` varchar(255),
	`manufacturer` varchar(255),
	`expiryDate` timestamp,
	`requiresPrescription` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `medicines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orderItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`medicineId` int NOT NULL,
	`quantity` int NOT NULL,
	`priceAtTime` decimal(10,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`status` enum('pending','confirmed','preparing','ready','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
	`paymentStatus` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
	`totalPrice` decimal(10,2) NOT NULL,
	`discountAmount` decimal(10,2) DEFAULT '0',
	`promoCodeId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `promoCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(50) NOT NULL,
	`discountType` enum('percentage','fixed') NOT NULL,
	`discountValue` decimal(10,2) NOT NULL,
	`maxDiscount` decimal(10,2),
	`minOrderAmount` decimal(10,2) DEFAULT '0',
	`usageLimit` int,
	`usageCount` int DEFAULT 0,
	`validFrom` timestamp NOT NULL,
	`validUntil` timestamp NOT NULL,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `promoCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `promoCodes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `ratings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`medicineId` int,
	`orderId` int,
	`ratingType` enum('medicine','service','delivery','driver') NOT NULL,
	`score` int NOT NULL,
	`comment` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ratings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','pharmacist','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `address` text;--> statement-breakpoint
ALTER TABLE `users` ADD `isActive` boolean DEFAULT true;--> statement-breakpoint
CREATE INDEX `userId_idx` ON `cart` (`userId`);--> statement-breakpoint
CREATE INDEX `deliveryTrackingId_idx` ON `deliveryStages` (`deliveryTrackingId`);--> statement-breakpoint
CREATE INDEX `orderId_idx` ON `deliveryTracking` (`orderId`);--> statement-breakpoint
CREATE INDEX `userId_idx` ON `driverRatings` (`userId`);--> statement-breakpoint
CREATE INDEX `driverId_idx` ON `driverRatings` (`driverId`);--> statement-breakpoint
CREATE INDEX `orderId_idx` ON `driverRatings` (`orderId`);--> statement-breakpoint
CREATE INDEX `categoryId_idx` ON `medicines` (`categoryId`);--> statement-breakpoint
CREATE INDEX `orderId_idx` ON `orderItems` (`orderId`);--> statement-breakpoint
CREATE INDEX `medicineId_idx` ON `orderItems` (`medicineId`);--> statement-breakpoint
CREATE INDEX `userId_idx` ON `orders` (`userId`);--> statement-breakpoint
CREATE INDEX `userId_idx` ON `ratings` (`userId`);--> statement-breakpoint
CREATE INDEX `medicineId_idx` ON `ratings` (`medicineId`);--> statement-breakpoint
CREATE INDEX `orderId_idx` ON `ratings` (`orderId`);