import React from "react";
import { cn } from "@/lib/utils";

/**
 * Loading Skeleton Components
 * Used to display placeholder content while data is loading
 */

export const MedicineSkeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div className={cn("animate-pulse space-y-4", className)}>
    <div className="h-48 bg-gray-200 rounded-lg"></div>
    <div className="space-y-2">
      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
    </div>
    <div className="h-8 bg-gray-200 rounded w-1/3"></div>
  </div>
);

export const MedicineGridSkeleton: React.FC<{ count?: number }> = ({ count = 6 }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    {Array.from({ length: count }).map((_, i) => (
      <MedicineSkeleton key={i} />
    ))}
  </div>
);

export const OrderSkeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div className={cn("animate-pulse space-y-4 p-4 border rounded-lg", className)}>
    <div className="flex justify-between items-center">
      <div className="h-4 bg-gray-200 rounded w-1/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/4"></div>
    </div>
    <div className="space-y-2">
      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
    </div>
    <div className="h-8 bg-gray-200 rounded w-1/3"></div>
  </div>
);

export const OrderListSkeleton: React.FC<{ count?: number }> = ({ count = 5 }) => (
  <div className="space-y-4">
    {Array.from({ length: count }).map((_, i) => (
      <OrderSkeleton key={i} />
    ))}
  </div>
);

export const CartItemSkeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div className={cn("animate-pulse flex gap-4 p-4 border rounded-lg", className)}>
    <div className="h-24 w-24 bg-gray-200 rounded-lg flex-shrink-0"></div>
    <div className="flex-1 space-y-2">
      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-4 bg-gray-200 rounded w-1/4"></div>
    </div>
  </div>
);

export const CartSkeleton: React.FC<{ count?: number }> = ({ count = 3 }) => (
  <div className="space-y-4">
    {Array.from({ length: count }).map((_, i) => (
      <CartItemSkeleton key={i} />
    ))}
  </div>
);

export const DashboardStatSkeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div className={cn("animate-pulse space-y-4 p-4 border rounded-lg", className)}>
    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
    <div className="h-8 bg-gray-200 rounded w-1/3"></div>
    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
  </div>
);

export const DashboardSkeleton: React.FC = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <DashboardStatSkeleton key={i} />
      ))}
    </div>
    <div className="space-y-4">
      <div className="h-6 bg-gray-200 rounded w-1/4"></div>
      <OrderListSkeleton count={5} />
    </div>
  </div>
);

export const PrescriptionSkeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div className={cn("animate-pulse space-y-4 p-4 border rounded-lg", className)}>
    <div className="h-48 bg-gray-200 rounded-lg"></div>
    <div className="space-y-2">
      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
    </div>
    <div className="h-8 bg-gray-200 rounded w-1/3"></div>
  </div>
);

export const TableSkeleton: React.FC<{ rows?: number; columns?: number }> = ({ rows = 5, columns = 4 }) => (
  <div className="border rounded-lg overflow-hidden">
    <table className="w-full">
      <thead>
        <tr className="border-b bg-gray-50">
          {Array.from({ length: columns }).map((_, i) => (
            <th key={i} className="p-4">
              <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse"></div>
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }).map((_, rowIdx) => (
          <tr key={rowIdx} className="border-b">
            {Array.from({ length: columns }).map((_, colIdx) => (
              <td key={colIdx} className="p-4">
                <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse"></div>
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);
