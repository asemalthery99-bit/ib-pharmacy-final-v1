# تحسينات تطبيق الهاتف - صيدلية إب الرقمية
## Mobile App Enhancements - v5.0

---

## 📱 نظرة عامة

تم تطوير تطبيق React Native متكامل لصيدلية إب الرقمية يوفر تجربة مستخدم سلسة على الأجهزة المحمولة (iOS و Android).

---

## ✨ الميزات الرئيسية للتطبيق

### 1. البحث والتصفح
- البحث السريع عن الأدوية بالاسم أو الفئة
- تصفية حسب السعر والتقييمات
- عرض تفاصيل الدواء الكاملة (الجرعة، الآثار الجانبية، الاستخدام)
- قائمة المفضلة (Wishlist)

### 2. رفع الروشتات الطبية
- التقاط صور الروشتات مباشرة من الكاميرا
- رفع صور من معرض الصور
- إضافة ملاحظات على الروشتة
- تتبع حالة الروشتة (معلقة، تمت المراجعة، معروض السعر)
- استقبال إشعارات عند عرض السعر

### 3. إدارة السلة والطلبات
- إضافة/حذف الأدوية من السلة
- تحديث الكميات بسهولة
- عرض الإجمالي والخصومات
- إنشاء طلب جديد
- تتبع الطلبات النشطة
- عرض سجل الطلبات السابقة

### 4. تتبع الطلبات في الوقت الفعلي
- خريطة تفاعلية لتتبع موقع الطلب
- إشعارات فورية عند تحديث حالة الطلب
- معلومات الشخص المسؤول عن التوصيل
- وقت التوصيل المتوقع

### 5. نظام الدفع
- دعم Stripe و PayPal
- حفظ بطاقات الائتمان بأمان
- الدفع عند الاستلام
- فاتورة رقمية بعد الشراء

### 6. نظام نقاط الولاء
- عرض رصيد النقاط الحالي
- عرض المستوى الحالي (برونزي، فضي، ذهبي، بلاتيني)
- عرض المكافآت المتاحة
- استبدال النقاط بمكافآت
- سجل النقاط والعمليات

### 7. التقييمات والمراجعات
- تقييم الأدوية المشتراة
- كتابة مراجعات تفصيلية
- عرض تقييمات المستخدمين الآخرين
- تقييم خدمة التوصيل والصيدلي

### 8. الإشعارات
- إشعارات فورية عند تحديث الطلب
- إشعارات عند توفر الأدوية المفضلة
- إشعارات العروض والخصومات
- إشعارات نقاط الولاء

### 9. الملف الشخصي
- تحديث البيانات الشخصية
- إدارة عناوين التوصيل
- سجل الطلبات
- المفضلة
- الإعدادات والتفضيلات
- تسجيل الخروج

### 10. الدعم والمساعدة
- الدردشة المباشرة مع الدعم
- الأسئلة الشائعة (FAQ)
- معلومات الاتصال
- تقديم الشكاوى والاقتراحات

---

## 🛠 التقنيات المستخدمة

| الفئة | التقنيات |
|------|----------|
| **Framework** | React Native (Expo) |
| **Language** | TypeScript |
| **State Management** | Redux Toolkit / Zustand |
| **API Client** | tRPC Client |
| **UI Components** | React Native Paper / NativeBase |
| **Maps** | Google Maps / Apple Maps |
| **Camera** | Expo Camera |
| **Storage** | AsyncStorage / SQLite |
| **Notifications** | Expo Notifications / Firebase Cloud Messaging |
| **Payment** | Stripe SDK / PayPal SDK |
| **Analytics** | Firebase Analytics |

---

## 📂 هيكل المشروع

```
mobile/
├── src/
│   ├── screens/
│   │   ├── HomeScreen.tsx
│   │   ├── SearchScreen.tsx
│   │   ├── MedicineDetailScreen.tsx
│   │   ├── CartScreen.tsx
│   │   ├── CheckoutScreen.tsx
│   │   ├── OrdersScreen.tsx
│   │   ├── OrderTrackingScreen.tsx
│   │   ├── PrescriptionScreen.tsx
│   │   ├── LoyaltyScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   └── SettingsScreen.tsx
│   ├── components/
│   │   ├── MedicineCard.tsx
│   │   ├── CartItem.tsx
│   │   ├── OrderCard.tsx
│   │   ├── NotificationBanner.tsx
│   │   └── ...
│   ├── services/
│   │   ├── apiService.ts
│   │   ├── mapsService.ts
│   │   ├── notificationsService.ts
│   │   ├── paymentService.ts
│   │   └── storageService.ts
│   ├── store/
│   │   ├── slices/
│   │   │   ├── authSlice.ts
│   │   │   ├── cartSlice.ts
│   │   │   ├── ordersSlice.ts
│   │   │   └── ...
│   │   └── store.ts
│   ├── navigation/
│   │   ├── RootNavigator.tsx
│   │   ├── AuthNavigator.tsx
│   │   ├── MainNavigator.tsx
│   │   └── ...
│   ├── utils/
│   │   ├── validators.ts
│   │   ├── formatters.ts
│   │   └── constants.ts
│   └── App.tsx
├── app.json
├── package.json
└── tsconfig.json
```

---

## 🚀 خطوات التطوير والنشر

### المرحلة 1: إعداد بيئة التطوير

```bash
# تثبيت Expo CLI
npm install -g expo-cli

# إنشاء مشروع جديد
cd mobile
pnpm install

# تشغيل التطبيق
expo start

# على iOS
expo start --ios

# على Android
expo start --android
```

### المرحلة 2: تطوير الشاشات الأساسية

#### 2.1 شاشة البحث والتصفح
```typescript
// src/screens/SearchScreen.tsx
import React, { useState } from 'react';
import { View, TextInput, FlatList } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { trpc } from '../services/apiService';

export const SearchScreen: React.FC = () => {
  const [query, setQuery] = useState('');
  const { data: medicines } = trpc.medicines.search.useQuery(
    { query },
    { enabled: query.length > 0 }
  );

  return (
    <View style={{ flex: 1 }}>
      <TextInput
        placeholder="ابحث عن الأدوية..."
        value={query}
        onChangeText={setQuery}
      />
      <FlatList
        data={medicines}
        renderItem={({ item }) => <MedicineCard medicine={item} />}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};
```

#### 2.2 شاشة رفع الروشتات
```typescript
// src/screens/PrescriptionScreen.tsx
import React, { useState } from 'react';
import { View, Button, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { trpc } from '../services/apiService';

export const PrescriptionScreen: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const uploadMutation = trpc.prescriptions.create.useMutation();

  const pickImage = async () => {
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      base64: true,
    });

    if (!result.cancelled && result.base64) {
      setImage(`data:image/jpeg;base64,${result.base64}`);
    }
  };

  const uploadPrescription = async () => {
    if (image) {
      await uploadMutation.mutateAsync({ imageUrl: image });
    }
  };

  return (
    <View style={{ flex: 1, padding: 16 }}>
      {image && <Image source={{ uri: image }} style={{ width: 200, height: 200 }} />}
      <Button title="التقط صورة الروشتة" onPress={pickImage} />
      <Button title="رفع الروشتة" onPress={uploadPrescription} />
    </View>
  );
};
```

#### 2.3 شاشة تتبع الطلبات
```typescript
// src/screens/OrderTrackingScreen.tsx
import React from 'react';
import { View, Text } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { useRoute } from '@react-navigation/native';
import { trpc } from '../services/apiService';

export const OrderTrackingScreen: React.FC = () => {
  const route = useRoute();
  const { orderId } = route.params as { orderId: number };
  const { data: order } = trpc.orders.getById.useQuery({ id: orderId });

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={{ flex: 1 }}
        initialRegion={{
          latitude: 15.3694,
          longitude: 44.2039,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
      >
        {/* عرض موقع الطلب والتوصيل */}
        <Marker
          coordinate={{
            latitude: 15.3694,
            longitude: 44.2039,
          }}
          title="موقع الطلب"
        />
      </MapView>
      <View style={{ padding: 16 }}>
        <Text>حالة الطلب: {order?.status}</Text>
        <Text>الوقت المتوقع: 30 دقيقة</Text>
      </View>
    </View>
  );
};
```

### المرحلة 3: تفعيل الإشعارات

```typescript
// src/services/notificationsService.ts
import * as Notifications from 'expo-notifications';

export const setupNotifications = async () => {
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') {
    console.warn('Notification permissions not granted');
    return;
  }

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });
};

export const sendLocalNotification = async (title: string, body: string) => {
  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: 'default',
    },
    trigger: { seconds: 1 },
  });
};
```

### المرحلة 4: النشر على App Stores

#### 4.1 نشر على Google Play
```bash
# بناء APK
eas build --platform android --type apk

# بناء AAB (موصى به)
eas build --platform android --type app-bundle

# رفع على Google Play Console
# 1. اذهب إلى Google Play Console
# 2. أنشئ تطبيق جديد
# 3. رفع AAB
# 4. ملء البيانات الوصفية
# 5. نشر
```

#### 4.2 نشر على App Store
```bash
# بناء IPA
eas build --platform ios --type app-store

# رفع على App Store Connect
# 1. اذهب إلى App Store Connect
# 2. أنشئ تطبيق جديد
# 3. رفع IPA باستخدام Transporter
# 4. ملء البيانات الوصفية
# 5. إرسال للمراجعة
```

---

## 🔒 الأمان والخصوصية

### 1. حماية البيانات الحساسة
```typescript
// استخدام Secure Storage
import * as SecureStore from 'expo-secure-store';

export const saveToken = async (token: string) => {
  await SecureStore.setItemAsync('auth_token', token);
};

export const getToken = async () => {
  return await SecureStore.getItemAsync('auth_token');
};
```

### 2. تشفير البيانات المحلية
```typescript
// استخدام SQLite مع تشفير
import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabase('ibpharmacy.db');
// تفعيل التشفير عند الإنشاء
```

### 3. التحقق من الشهادات
```typescript
// تفعيل Certificate Pinning
import { fetch } from 'expo';

const customFetch = async (url: string, options?: RequestInit) => {
  // التحقق من شهادة SSL
  return fetch(url, options);
};
```

---

## 📊 الأداء والتحسينات

### 1. تحسين الأداء
- استخدام FlatList مع optimizeListViewScrollingPerfromance
- تحميل الصور بشكل كسول (Lazy Loading)
- استخدام React.memo لتجنب إعادة الرسم غير الضرورية

### 2. تقليل حجم التطبيق
- استخدام Tree Shaking
- ضغط الصور
- حذف التبعيات غير المستخدمة

### 3. الاختبار
```bash
# اختبارات الوحدة
pnpm test

# اختبارات التكامل
pnpm test:integration

# اختبارات الأداء
pnpm test:performance
```

---

## 📈 المراقبة والتحليلات

```typescript
// استخدام Firebase Analytics
import { initializeApp } from 'firebase/app';
import { getAnalytics, logEvent } from 'firebase/analytics';

const analytics = getAnalytics();

logEvent(analytics, 'medicine_viewed', {
  medicine_id: medicineId,
  medicine_name: medicineName,
});

logEvent(analytics, 'order_completed', {
  order_id: orderId,
  total_price: totalPrice,
});
```

---

## ✅ قائمة التحقق

- [ ] تطوير جميع الشاشات الأساسية
- [ ] تفعيل الإشعارات
- [ ] تفعيل الدفع (Stripe/PayPal)
- [ ] تفعيل الخرائط
- [ ] اختبار شامل على iOS و Android
- [ ] تحسين الأداء
- [ ] نشر على Google Play
- [ ] نشر على App Store
- [ ] إعداد المراقبة والتحليلات
- [ ] توثيق كاملة

---

**تاريخ آخر تحديث:** مارس 2026
**الإصدار:** v5.0
**الحالة:** جاهز للتطوير والنشر

