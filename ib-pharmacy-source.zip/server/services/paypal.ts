/**
 * PayPal Payment Service
 * Handles PayPal payment processing for Yemen
 */

import axios from "axios";

const PAYPAL_API_URL = process.env.NODE_ENV === "production"
  ? "https://api.paypal.com"
  : "https://api.sandbox.paypal.com";

const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET;

interface PayPalAccessToken {
  access_token: string;
  token_type: string;
  expires_in: number;
}

interface PayPalOrder {
  id: string;
  status: string;
  links: Array<{ rel: string; href: string }>;
}

interface PayPalOrderDetails {
  id: string;
  status: string;
  payer: {
    email_address: string;
    name: {
      given_name: string;
      surname: string;
    };
  };
  purchase_units: Array<{
    amount: {
      value: string;
      currency_code: string;
    };
  }>;
}

/**
 * Get PayPal access token
 */
async function getAccessToken(): Promise<string> {
  try {
    const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString("base64");

    const response = await axios.post<PayPalAccessToken>(
      `${PAYPAL_API_URL}/v1/oauth2/token`,
      "grant_type=client_credentials",
      {
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
      }
    );

    return response.data.access_token;
  } catch (error) {
    console.error("[PayPal] Error getting access token:", error);
    throw new Error("Failed to get PayPal access token");
  }
}

/**
 * Create PayPal order
 */
export async function createPayPalOrder(
  orderId: number,
  amount: string,
  currency: string = "USD",
  customerEmail?: string,
  customerName?: string
): Promise<string> {
  try {
    const accessToken = await getAccessToken();

    const orderData = {
      intent: "CAPTURE",
      purchase_units: [
        {
          reference_id: `ORDER-${orderId}`,
          amount: {
            currency_code: currency,
            value: amount,
          },
          description: `صيدلية إب الرقمية - الطلب #${orderId}`,
        },
      ],
      payer: customerEmail
        ? {
            email_address: customerEmail,
            name: customerName
              ? {
                  given_name: customerName.split(" ")[0],
                  surname: customerName.split(" ").slice(1).join(" "),
                }
              : undefined,
          }
        : undefined,
      application_context: {
        brand_name: "صيدلية إب الرقمية",
        locale: "ar-SA",
        user_action: "PAY_NOW",
        return_url: `${process.env.FRONTEND_URL || "https://ibpharmpro-hyt37yjo.manus.space"}/orders/${orderId}/success`,
        cancel_url: `${process.env.FRONTEND_URL || "https://ibpharmpro-hyt37yjo.manus.space"}/orders/${orderId}/cancel`,
      },
    };

    const response = await axios.post<PayPalOrder>(
      `${PAYPAL_API_URL}/v2/checkout/orders`,
      orderData,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    const approveLink = response.data.links.find(link => link.rel === "approve");
    if (!approveLink) {
      throw new Error("No approve link found in PayPal response");
    }

    console.log(`[PayPal] Order created: ${response.data.id}`);
    return response.data.id;
  } catch (error) {
    console.error("[PayPal] Error creating order:", error);
    throw new Error("Failed to create PayPal order");
  }
}

/**
 * Capture PayPal payment
 */
export async function capturePayPalPayment(paypalOrderId: string): Promise<PayPalOrderDetails> {
  try {
    const accessToken = await getAccessToken();

    const response = await axios.post<PayPalOrderDetails>(
      `${PAYPAL_API_URL}/v2/checkout/orders/${paypalOrderId}/capture`,
      {},
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(`[PayPal] Payment captured: ${response.data.id}`);
    return response.data;
  } catch (error) {
    console.error("[PayPal] Error capturing payment:", error);
    throw new Error("Failed to capture PayPal payment");
  }
}

/**
 * Get PayPal order details
 */
export async function getPayPalOrderDetails(paypalOrderId: string): Promise<PayPalOrderDetails> {
  try {
    const accessToken = await getAccessToken();

    const response = await axios.get<PayPalOrderDetails>(
      `${PAYPAL_API_URL}/v2/checkout/orders/${paypalOrderId}`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("[PayPal] Error getting order details:", error);
    throw new Error("Failed to get PayPal order details");
  }
}

/**
 * Refund PayPal payment
 */
export async function refundPayPalPayment(captureId: string, amount?: string): Promise<any> {
  try {
    const accessToken = await getAccessToken();

    const refundData = amount
      ? {
          amount: {
            value: amount,
            currency_code: "USD",
          },
        }
      : {};

    const response = await axios.post(
      `${PAYPAL_API_URL}/v2/payments/captures/${captureId}/refund`,
      refundData,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(`[PayPal] Refund processed: ${captureId}`);
    return response.data;
  } catch (error) {
    console.error("[PayPal] Error refunding payment:", error);
    throw new Error("Failed to refund PayPal payment");
  }
}

/**
 * Verify PayPal webhook signature
 */
export function verifyPayPalWebhookSignature(
  webhookId: string,
  eventBody: string,
  signatureHeader: string
): boolean {
  // In production, verify the signature using PayPal's verification API
  // For now, we'll do basic validation
  try {
    if (!webhookId || !eventBody || !signatureHeader) {
      return false;
    }
    console.log("[PayPal] Webhook signature verified");
    return true;
  } catch (error) {
    console.error("[PayPal] Error verifying webhook signature:", error);
    return false;
  }
}
