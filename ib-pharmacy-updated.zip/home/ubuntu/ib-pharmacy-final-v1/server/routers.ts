import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { notifyOwner } from "./_core/notification";

// ============ MEDICINES ROUTER ============
const medicinesRouter = router({
  list: publicProcedure.query(async () => {
    return db.getMedicines();
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const medicine = await db.getMedicineById(input.id);
      if (!medicine) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Medicine not found" });
      }
      const avgRating = await db.getAverageRating(input.id);
      return { ...medicine, averageRating: avgRating };
    }),

  search: publicProcedure
    .input(z.object({
      query: z.string().optional(),
      categoryId: z.number().optional(),
      minPrice: z.number().optional(),
      maxPrice: z.number().optional(),
    }))
    .query(async ({ input }) => {
      return db.searchMedicines(input.query || "", input.categoryId, input.minPrice, input.maxPrice);
    }),

  create: protectedProcedure
    .input(z.object({
      name: z.string(),
      description: z.string().optional(),
      categoryId: z.number(),
      price: z.string(),
      imageUrl: z.string().optional(),
      activeIngredient: z.string().optional(),
      manufacturer: z.string().optional(),
      requiresPrescription: z.boolean().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.createMedicine(input);
    }),
});

// ============ CATEGORIES ROUTER ============
const categoriesRouter = router({
  list: publicProcedure.query(async () => {
    return db.getCategories();
  }),
});

// ============ INVENTORY ROUTER ============
const inventoryRouter = router({
  getByMedicineId: publicProcedure
    .input(z.object({ medicineId: z.number() }))
    .query(async ({ input }) => {
      return db.getInventoryByMedicineId(input.medicineId);
    }),

  updateQuantity: protectedProcedure
    .input(z.object({ medicineId: z.number(), quantity: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.updateInventoryQuantity(input.medicineId, input.quantity);
    }),
});

// ============ RATINGS ROUTER ============
const ratingsRouter = router({
  create: protectedProcedure
    .input(z.object({
      medicineId: z.number().optional(),
      orderId: z.number().optional(),
      ratingType: z.enum(["medicine", "service", "delivery", "driver"]),
      score: z.number().min(1).max(5),
      comment: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      const rating = await db.createRating({
        userId: ctx.user.id,
        medicineId: input.medicineId,
        orderId: input.orderId,
        ratingType: input.ratingType,
        score: input.score,
        comment: input.comment,
      });

      // إرسال إشعار للمالك عند إضافة تقييم جديد
      await notifyOwner({
        title: "تقييم جديد",
        content: `تم إضافة تقييم جديد (${input.score}/5) من قبل ${ctx.user.name || "مستخدم"}${input.comment ? `: ${input.comment}` : ""}`,
      });

      return rating;
    }),

  getMedicineRatings: publicProcedure
    .input(z.object({ medicineId: z.number() }))
    .query(async ({ input }) => {
      return db.getMedicineRatings(input.medicineId);
    }),

  getAverageRating: publicProcedure
    .input(z.object({ medicineId: z.number() }))
    .query(async ({ input }) => {
      return db.getAverageRating(input.medicineId);
    }),

  getOrderRatings: publicProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      return db.getOrderRatings(input.orderId);
    }),

  update: protectedProcedure
    .input(z.object({
      ratingId: z.number(),
      score: z.number().min(1).max(5),
      comment: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.updateRating(input.ratingId, input.score, input.comment);
    }),

  delete: protectedProcedure
    .input(z.object({ ratingId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.deleteRating(input.ratingId);
    }),
});

// ============ PROMO CODES ROUTER ============
const promoCodesRouter = router({
  create: protectedProcedure
    .input(z.object({
      code: z.string(),
      discountType: z.enum(["percentage", "fixed"]),
      discountValue: z.string(),
      maxDiscount: z.string().optional(),
      minOrderAmount: z.string().optional(),
      usageLimit: z.number().optional(),
      validFrom: z.date(),
      validUntil: z.date(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.createPromoCode({
        code: input.code.toUpperCase(),
        discountType: input.discountType,
        discountValue: input.discountValue,
        maxDiscount: input.maxDiscount,
        minOrderAmount: input.minOrderAmount,
        usageLimit: input.usageLimit,
        validFrom: input.validFrom,
        validUntil: input.validUntil,
        isActive: true,
      });
    }),

  validate: publicProcedure
    .input(z.object({ code: z.string() }))
    .query(async ({ input }) => {
      const promoCode = await db.getPromoCodeByCode(input.code.toUpperCase());
      if (!promoCode) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Promo code not found" });
      }
      if (!promoCode.isActive) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Promo code is not active" });
      }
      if (promoCode.usageLimit && (promoCode.usageCount ?? 0) >= promoCode.usageLimit) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Promo code usage limit exceeded" });
      }
      return promoCode;
    }),

  getActive: publicProcedure.query(async () => {
    return db.getActivePromoCodes();
  }),

  update: protectedProcedure
    .input(z.object({
      promoCodeId: z.number(),
      isActive: z.boolean().optional(),
      usageLimit: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.updatePromoCode(input.promoCodeId, {
        isActive: input.isActive,
        usageLimit: input.usageLimit,
      });
    }),

  delete: protectedProcedure
    .input(z.object({ promoCodeId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.deletePromoCode(input.promoCodeId);
    }),
});

// ============ DELIVERY TRACKING ROUTER ============
const deliveryRouter = router({
  create: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      driverId: z.number().optional(),
      estimatedDeliveryTime: z.date().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.createDeliveryTracking({
        orderId: input.orderId,
        driverId: input.driverId,
        estimatedDeliveryTime: input.estimatedDeliveryTime,
        currentStatus: "pending",
      });
    }),

  getByOrderId: publicProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      return db.getDeliveryTrackingByOrderId(input.orderId);
    }),

  updateStatus: protectedProcedure
    .input(z.object({
      trackingId: z.number(),
      status: z.enum(["pending", "assigned", "picked_up", "in_transit", "delivered", "failed"]),
      lat: z.string().optional(),
      lng: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.updateDeliveryStatus(input.trackingId, input.status, input.lat, input.lng);
    }),

  getStages: publicProcedure
    .input(z.object({ trackingId: z.number() }))
    .query(async ({ input }) => {
      return db.getDeliveryStages(input.trackingId);
    }),

  addStage: protectedProcedure
    .input(z.object({
      trackingId: z.number(),
      stage: z.string(),
      description: z.string().optional(),
      lat: z.string().optional(),
      lng: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.createDeliveryStage({
        deliveryTrackingId: input.trackingId,
        stage: input.stage,
        description: input.description,
        lat: input.lat,
        lng: input.lng,
      });
    }),
});

// ============ DRIVER RATINGS ROUTER ============
const driverRatingsRouter = router({
  create: protectedProcedure
    .input(z.object({
      driverId: z.number(),
      orderId: z.number(),
      score: z.number().min(1).max(5),
      comment: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      return db.createDriverRating({
        userId: ctx.user.id,
        driverId: input.driverId,
        orderId: input.orderId,
        score: input.score,
        comment: input.comment,
      });
    }),

  getDriverRatings: publicProcedure
    .input(z.object({ driverId: z.number() }))
    .query(async ({ input }) => {
      return db.getDriverRatings(input.driverId);
    }),

  getAverageRating: publicProcedure
    .input(z.object({ driverId: z.number() }))
    .query(async ({ input }) => {
      return db.getAverageDriverRating(input.driverId);
    }),
});

// ============ CART ROUTER ============
const cartRouter = router({
  getCart: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
    const userCart = await db.getCartByUserId(ctx.user.id);
    return userCart || { userId: ctx.user.id, items: [] };
  }),

  updateCart: protectedProcedure
    .input(z.object({
      items: z.array(z.object({
        medicineId: z.number(),
        quantity: z.number(),
      })),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
      const existingCart = await db.getCartByUserId(ctx.user.id);
      if (existingCart) {
        return db.updateCart(ctx.user.id, JSON.stringify(input.items));
      } else {
        return db.createCart(ctx.user.id, JSON.stringify(input.items));
      }
    }),

  clearCart: protectedProcedure.mutation(async ({ ctx }) => {
    if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
    return db.deleteCart(ctx.user.id);
  }),
});

// ============ ORDERS ROUTER ============
const ordersRouter = router({
  create: protectedProcedure
    .input(z.object({
      items: z.array(z.object({
        medicineId: z.number(),
        quantity: z.number(),
        priceAtTime: z.string(),
      })),
      totalPrice: z.string(),
      discountAmount: z.string().optional(),
      promoCodeId: z.number().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });

      // Create order
      const orderResult = await db.createOrder({
        userId: ctx.user.id,
        totalPrice: input.totalPrice,
        discountAmount: input.discountAmount,
        promoCodeId: input.promoCodeId,
        notes: input.notes,
        status: "pending",
        paymentStatus: "pending",
      });

      // Create order items
      for (const item of input.items) {
        await db.createOrderItem({
          orderId: (orderResult as any).insertId,
          medicineId: item.medicineId,
          quantity: item.quantity,
          priceAtTime: item.priceAtTime,
        });
      }

      // Update promo code usage
      if (input.promoCodeId) {
        await db.updatePromoCodeUsage(input.promoCodeId);
      }

      // إرسال إشعار للمالك عند إنشاء طلب جديد
      await notifyOwner({
        title: "طلب جديد",
        content: `تم إنشاء طلب جديد من قبل ${ctx.user.name || "مستخدم"} بقيمة ${input.totalPrice} ريال`,
      });

      return { orderId: (orderResult as any).insertId };
    }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const order = await db.getOrderById(input.id);
      if (!order) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
      }
      const items = await db.getOrderItems(input.id);
      return { ...order, items };
    }),

  getUserOrders: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
    return db.getUserOrders(ctx.user.id);
  }),

  updateStatus: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      status: z.enum(["pending", "confirmed", "preparing", "ready", "shipped", "delivered", "cancelled"]),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      const result = await db.updateOrderStatus(input.orderId, input.status);

      // إرسال إشعار للمالك عند تغيير حالة الطلب
      const statusLabels: Record<string, string> = {
        pending: "قيد الانتظار",
        confirmed: "مؤكد",
        preparing: "قيد التحضير",
        ready: "جاهز",
        shipped: "تم الشحن",
        delivered: "تم التسليم",
        cancelled: "ملغى",
      };

      await notifyOwner({
        title: "تحديث حالة الطلب",
        content: `تم تحديث حالة الطلب #${input.orderId} إلى: ${statusLabels[input.status]}`,
      });

      return result;
    }),

  updatePaymentStatus: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin" && ctx.user?.role !== "pharmacist") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return db.updateOrderPaymentStatus(input.orderId, input.paymentStatus);
    }),
});

// ============ MAIN APP ROUTER ============
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  medicines: medicinesRouter,
  categories: categoriesRouter,
  inventory: inventoryRouter,
  ratings: ratingsRouter,
  promoCodes: promoCodesRouter,
  delivery: deliveryRouter,
  driverRatings: driverRatingsRouter,
  cart: cartRouter,
  orders: ordersRouter,
});

export type AppRouter = typeof appRouter;
