import { describe, it, expect, vi } from "vitest";
import {
  notifyNewOrder,
  notifyNewPrescription,
  notifyLowInventory,
  notifyPaymentSuccess,
  notifyPaymentFailure,
  notifyOrderStatusUpdate,
  notifyPrescriptionStatusUpdate,
  notifyMultipleLowInventory,
} from "./services/notifications";

// Mock the notifyOwner function
vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn(async () => true),
}));

describe("Notification Service", () => {
  describe("Order Notifications", () => {
    it("should notify about new order", async () => {
      const result = await notifyNewOrder(1, "500.00", 3);
      expect(result).toBe(true);
    });

    it("should notify about order status update", async () => {
      const result = await notifyOrderStatusUpdate(1, "preparing", "جاري التحضير");
      expect(result).toBe(true);
    });
  });

  describe("Prescription Notifications", () => {
    it("should notify about new prescription", async () => {
      const result = await notifyNewPrescription(1, "أحمد محمد", 5);
      expect(result).toBe(true);
    });

    it("should notify about prescription without patient name", async () => {
      const result = await notifyNewPrescription(1);
      expect(result).toBe(true);
    });

    it("should notify about prescription status update", async () => {
      const result = await notifyPrescriptionStatusUpdate(1, "approved", "موافق عليه");
      expect(result).toBe(true);
    });
  });

  describe("Inventory Notifications", () => {
    it("should notify about low inventory", async () => {
      const result = await notifyLowInventory("بنادول", 10, 50);
      expect(result).toBe(true);
    });

    it("should notify about multiple low inventory items", async () => {
      const items = [
        { name: "بنادول", quantity: 10, threshold: 50 },
        { name: "أسبرين", quantity: 5, threshold: 30 },
        { name: "ديكلوفيناك", quantity: 15, threshold: 40 },
      ];
      const result = await notifyMultipleLowInventory(items);
      expect(result).toBe(true);
    });

    it("should handle empty inventory list", async () => {
      const result = await notifyMultipleLowInventory([]);
      expect(result).toBe(true);
    });
  });

  describe("Payment Notifications", () => {
    it("should notify about successful payment", async () => {
      const result = await notifyPaymentSuccess(1, "500.00", "PayPal");
      expect(result).toBe(true);
    });

    it("should notify about payment failure", async () => {
      const result = await notifyPaymentFailure(1, "بطاقة مرفوضة");
      expect(result).toBe(true);
    });
  });

  describe("Notification Payload Generation", () => {
    it("should generate correct payload for order notification", async () => {
      const result = await notifyNewOrder(123, "1500.00", 5);
      expect(result).toBe(true);
    });

    it("should generate correct payload for prescription notification", async () => {
      const result = await notifyNewPrescription(456, "محمد علي");
      expect(result).toBe(true);
    });

    it("should handle special characters in names", async () => {
      const result = await notifyLowInventory("دواء مركب (معقد)", 5, 20);
      expect(result).toBe(true);
    });
  });
});
