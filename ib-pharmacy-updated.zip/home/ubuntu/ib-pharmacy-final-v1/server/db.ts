import { eq, and, gte, lte, desc, asc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  InsertMedicine, medicines, categories,
  InsertInventory, inventory,
  InsertOrder, InsertOrderItem, orders, orderItems,
  InsertRating, ratings,
  InsertPromoCode, promoCodes,
  InsertDeliveryTracking, InsertDeliveryStage, deliveryTracking, deliveryStages,
  InsertDriverRating, driverRatings,
  InsertCart, cart
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER QUERIES ============
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone", "address"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ MEDICINES QUERIES ============
export async function getMedicines() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(medicines).orderBy(desc(medicines.createdAt));
}

export async function getMedicineById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(medicines).where(eq(medicines.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function searchMedicines(query: string, categoryId?: number, minPrice?: number, maxPrice?: number) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [];
  if (query) {
    conditions.push(sql`${medicines.name} LIKE ${`%${query}%`} OR ${medicines.description} LIKE ${`%${query}%`}`);
  }
  if (categoryId) {
    conditions.push(eq(medicines.categoryId, categoryId));
  }
  if (minPrice !== undefined) {
    conditions.push(gte(medicines.price, minPrice.toString()));
  }
  if (maxPrice !== undefined) {
    conditions.push(lte(medicines.price, maxPrice.toString()));
  }

  return db.select().from(medicines)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(medicines.createdAt));
}

export async function createMedicine(medicine: InsertMedicine) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(medicines).values(medicine);
  return result;
}

// ============ CATEGORIES QUERIES ============
export async function getCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).orderBy(asc(categories.name));
}

// ============ INVENTORY QUERIES ============
export async function getInventoryByMedicineId(medicineId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(inventory).where(eq(inventory.medicineId, medicineId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateInventoryQuantity(medicineId: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(inventory).set({ quantity }).where(eq(inventory.medicineId, medicineId));
}

export async function createInventory(inv: InsertInventory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(inventory).values(inv);
}

// ============ ORDERS QUERIES ============
export async function createOrder(order: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orders).values(order);
  return result;
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

export async function updateOrderStatus(orderId: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(orders).set({ status: status as any }).where(eq(orders.id, orderId));
}

export async function updateOrderPaymentStatus(orderId: number, paymentStatus: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(orders).set({ paymentStatus: paymentStatus as any }).where(eq(orders.id, orderId));
}

// ============ ORDER ITEMS QUERIES ============
export async function createOrderItem(item: InsertOrderItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(orderItems).values(item);
}

export async function getOrderItems(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
}

// ============ RATINGS QUERIES ============
export async function createRating(rating: InsertRating) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(ratings).values(rating);
}

export async function getMedicineRatings(medicineId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(ratings)
    .where(and(eq(ratings.medicineId, medicineId), eq(ratings.ratingType, "medicine")))
    .orderBy(desc(ratings.createdAt));
}

export async function getAverageRating(medicineId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({
    avg: sql`AVG(${ratings.score})`
  }).from(ratings)
    .where(and(eq(ratings.medicineId, medicineId), eq(ratings.ratingType, "medicine")));
  
  return result.length > 0 ? parseFloat(result[0].avg as string) : 0;
}

export async function getOrderRatings(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(ratings).where(eq(ratings.orderId, orderId));
}

export async function updateRating(ratingId: number, score: number, comment?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(ratings).set({ score, comment }).where(eq(ratings.id, ratingId));
}

export async function deleteRating(ratingId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(ratings).where(eq(ratings.id, ratingId));
}

// ============ PROMO CODES QUERIES ============
export async function createPromoCode(promoCode: InsertPromoCode) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(promoCodes).values(promoCode);
}

export async function getPromoCodeByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(promoCodes).where(eq(promoCodes.code, code)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getActivePromoCodes() {
  const db = await getDb();
  if (!db) return [];
  const now = new Date();
  return db.select().from(promoCodes)
    .where(and(
      eq(promoCodes.isActive, true),
      lte(promoCodes.validFrom, now),
      gte(promoCodes.validUntil, now)
    ))
    .orderBy(desc(promoCodes.createdAt));
}

export async function updatePromoCodeUsage(promoCodeId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(promoCodes)
    .set({ usageCount: sql`${promoCodes.usageCount} + 1` })
    .where(eq(promoCodes.id, promoCodeId));
}

export async function updatePromoCode(promoCodeId: number, updates: Partial<InsertPromoCode>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(promoCodes).set(updates).where(eq(promoCodes.id, promoCodeId));
}

export async function deletePromoCode(promoCodeId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(promoCodes).where(eq(promoCodes.id, promoCodeId));
}

// ============ DELIVERY TRACKING QUERIES ============
export async function createDeliveryTracking(tracking: InsertDeliveryTracking) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(deliveryTracking).values(tracking);
}

export async function getDeliveryTrackingByOrderId(orderId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(deliveryTracking).where(eq(deliveryTracking.orderId, orderId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateDeliveryStatus(trackingId: number, status: string, lat?: string, lng?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updates: any = { currentStatus: status };
  if (lat) updates.currentLat = lat;
  if (lng) updates.currentLng = lng;
  return db.update(deliveryTracking).set(updates).where(eq(deliveryTracking.id, trackingId));
}

// ============ DELIVERY STAGES QUERIES ============
export async function createDeliveryStage(stage: InsertDeliveryStage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(deliveryStages).values(stage);
}

export async function getDeliveryStages(trackingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(deliveryStages)
    .where(eq(deliveryStages.deliveryTrackingId, trackingId))
    .orderBy(asc(deliveryStages.createdAt));
}

export async function completeDeliveryStage(stageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(deliveryStages).set({ completedAt: new Date() }).where(eq(deliveryStages.id, stageId));
}

// ============ DRIVER RATINGS QUERIES ============
export async function createDriverRating(rating: InsertDriverRating) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(driverRatings).values(rating);
}

export async function getDriverRatings(driverId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(driverRatings).where(eq(driverRatings.driverId, driverId));
}

export async function getAverageDriverRating(driverId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({
    avg: sql`AVG(${driverRatings.score})`
  }).from(driverRatings)
    .where(eq(driverRatings.driverId, driverId));
  
  return result.length > 0 ? parseFloat(result[0].avg as string) : 0;
}

// ============ CART QUERIES ============
export async function getCartByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(cart).where(eq(cart.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateCart(userId: number, items: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(cart).set({ items }).where(eq(cart.userId, userId));
}

export async function createCart(userId: number, items: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(cart).values({ userId, items });
}

export async function deleteCart(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(cart).where(eq(cart.userId, userId));
}
