import { useCallback } from "react";
import { toast } from "sonner";

/**
 * Custom hook for managing toast notifications
 * Provides consistent toast notifications across the app
 */

export type ToastType = "success" | "error" | "info" | "warning";

export interface ToastOptions {
  duration?: number;
  position?: "top-left" | "top-center" | "top-right" | "bottom-left" | "bottom-center" | "bottom-right";
}

export const useToast = () => {
  const showToast = useCallback((
    message: string,
    type: ToastType = "info",
    options?: ToastOptions
  ) => {
    const defaultDuration = options?.duration ?? 3000;

    switch (type) {
      case "success":
        toast.success(message, {
          duration: defaultDuration,
          position: options?.position,
        });
        break;
      case "error":
        toast.error(message, {
          duration: defaultDuration,
          position: options?.position,
        });
        break;
      case "warning":
        toast.warning(message, {
          duration: defaultDuration,
          position: options?.position,
        });
        break;
      case "info":
      default:
        toast.info(message, {
          duration: defaultDuration,
          position: options?.position,
        });
        break;
    }
  }, []);

  const success = useCallback((message: string, options?: ToastOptions) => {
    showToast(message, "success", options);
  }, [showToast]);

  const error = useCallback((message: string, options?: ToastOptions) => {
    showToast(message, "error", options);
  }, [showToast]);

  const warning = useCallback((message: string, options?: ToastOptions) => {
    showToast(message, "warning", options);
  }, [showToast]);

  const info = useCallback((message: string, options?: ToastOptions) => {
    showToast(message, "info", options);
  }, [showToast]);

  return {
    showToast,
    success,
    error,
    warning,
    info,
  };
};
