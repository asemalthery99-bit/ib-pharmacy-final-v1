import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Truck, MessageCircle, Shield, Clock } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center text-right">
          {/* Left Content (Right-aligned in RTL) */}
          <div className="space-y-6 fade-in-right order-2 md:order-1">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight">
              صيدليتك الموثوقة أونلاين
            </h1>
            <p className="text-lg text-foreground/70 leading-relaxed">
              احصل على أدويتك بسهولة من منزلك مع توصيل آمن وسريع في إب، واستشارات صيدلانية مجانية من صيادلة معتمدين.
            </p>
            <div className="flex flex-col sm:flex-row-reverse gap-4 pt-4 justify-start">
              <Link href="/catalog">
                <Button className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-base font-semibold rounded-lg button-hover">
                  تصفح الأدوية
                </Button>
              </Link>
              <Button variant="outline" className="border-primary text-primary hover:bg-primary/5 px-8 py-6 text-base font-semibold rounded-lg button-hover">
                ابدأ الاستشارة
              </Button>
            </div>
          </div>

          {/* Right Image (Left-aligned in RTL) */}
          <div className="relative h-96 md:h-full fade-in-left scale-in order-1 md:order-2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663367109927/NeL8VUujHiGornCcRhBAGa/pharmacy-hero-W2CubovVe8W8e4cFVJMj3d.webp"
              alt="صيدلية إب"
              className="w-full h-full object-cover rounded-2xl shadow-lg transition-smooth hover:shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 text-right">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              مميزاتنا
            </h2>
            <p className="text-lg text-foreground/70">
              نقدم لك أفضل الخدمات الصيدلانية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Feature 1 */}
            <Card className="p-6 card-hover stagger-item text-right">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-smooth mr-auto ml-0 md:ml-auto md:mr-0">
                <Truck className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">توصيل سريع وآمن</h3>
              <p className="text-foreground/70 text-sm">
                توصيل موثوق إلى عنوانك في إب مع ضمان سلامة الأدوية والحفاظ على درجة الحرارة المناسبة.
              </p>
            </Card>

            {/* Feature 2 */}
            <Card className="p-6 card-hover stagger-item text-right">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-smooth mr-auto ml-0 md:ml-auto md:mr-0">
                <MessageCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">استشارات صيدلانية</h3>
              <p className="text-foreground/70 text-sm">
                احصل على استشارات مجانية من صيادلة معتمدين حول الأدوية والجرعات الصحيحة.
              </p>
            </Card>

            {/* Feature 3 */}
            <Card className="p-6 card-hover stagger-item text-right">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-smooth mr-auto ml-0 md:ml-auto md:mr-0">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">أدوية أصلية</h3>
              <p className="text-foreground/70 text-sm">
                جميع الأدوية أصلية ومن مصادر موثوقة معتمدة من الهيئة العليا للأدوية.
              </p>
            </Card>

            {/* Feature 4 */}
            <Card className="p-6 card-hover stagger-item text-right">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-smooth mr-auto ml-0 md:ml-auto md:mr-0">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">خدمة 24/7</h3>
              <p className="text-foreground/70 text-sm">
                نحن متاحون على مدار الساعة للإجابة على استفساراتك وتلقي طلباتك.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 fade-in-down">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              كيف يعمل؟
            </h2>
            <p className="text-lg text-foreground/70">
              4 خطوات سهلة للحصول على أدويتك
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Step 1 */}
            <div className="text-center stagger-item">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 transition-smooth hover:scale-110 hover:shadow-lg">
                1
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">البحث</h3>
              <p className="text-foreground/70">ابحث عن الدواء الذي تحتاجه</p>
            </div>

            {/* Step 2 */}
            <div className="text-center stagger-item">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 transition-smooth hover:scale-110 hover:shadow-lg">
                2
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">الإضافة</h3>
              <p className="text-foreground/70">أضف الدواء إلى سلة التسوق</p>
            </div>

            {/* Step 3 */}
            <div className="text-center stagger-item">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 transition-smooth hover:scale-110 hover:shadow-lg">
                3
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">الطلب</h3>
              <p className="text-foreground/70">أكمل عملية الطلب والدفع</p>
            </div>

            {/* Step 4 */}
            <div className="text-center stagger-item">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 transition-smooth hover:scale-110 hover:shadow-lg">
                4
              </div>
              <h3 className="font-bold text-lg mb-2 text-foreground">التوصيل</h3>
              <p className="text-foreground/70">استقبل طلبك في منزلك</p>
            </div>
          </div>
        </div>
      </section>

      {/* Delivery Section */}
      <section className="py-20 bg-secondary/10">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center text-right">
          {/* Image */}
          <div className="relative h-96 md:h-full order-2 md:order-1 fade-in-left">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663367109927/NeL8VUujHiGornCcRhBAGa/medicine-delivery-EzC4V9ASnEuAyvkDNGEbce.webp"
              alt="التوصيل السريع"
              className="w-full h-full object-cover rounded-2xl shadow-lg transition-smooth hover:shadow-2xl"
            />
          </div>

          {/* Content */}
          <div className="space-y-6 order-1 md:order-2 fade-in-right">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              توصيل سريع وآمن
            </h2>
            <p className="text-lg text-foreground/70 leading-relaxed">
              نضمن لك توصيل أدويتك بسرعة وأمان تام. فريقنا المتخصص يتعامل مع كل طلب بعناية فائقة، مع الحفاظ على درجة الحرارة المناسبة للأدوية.
            </p>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 justify-end">
                <span className="text-foreground">توصيل في نفس اليوم للطلبات المحلية</span>
                <span className="w-2 h-2 bg-accent rounded-full"></span>
              </li>
              <li className="flex items-center gap-3 justify-end">
                <span className="text-foreground">تتبع الطلب في الوقت الفعلي</span>
                <span className="w-2 h-2 bg-accent rounded-full"></span>
              </li>
              <li className="flex items-center gap-3 justify-end">
                <span className="text-foreground">ضمان سلامة الأدوية والعبوات</span>
                <span className="w-2 h-2 bg-accent rounded-full"></span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Consultation Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center text-right">
          {/* Content */}
          <div className="space-y-6 fade-in-right order-2 md:order-1">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              استشارات صيدلانية مجانية
            </h2>
            <p className="text-lg text-foreground/70 leading-relaxed">
              صيادلتنا المعتمدون متاحون دائماً للإجابة على أسئلتك حول الأدوية والجرعات والتفاعلات الدوائية.
            </p>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-base font-semibold rounded-lg button-hover">
              ابدأ الاستشارة الآن
            </Button>
          </div>

          {/* Image */}
          <div className="relative h-96 md:h-full fade-in-left order-1 md:order-2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663367109927/NeL8VUujHiGornCcRhBAGa/consultation-nMjxTFtNw2j6hpRbvthqXU.webp"
              alt="الاستشارات الصيدلانية"
              className="w-full h-full object-cover rounded-2xl shadow-lg transition-smooth hover:shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center fade-in-up">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            هل أنت مستعد للبدء؟
          </h2>
          <p className="text-lg mb-8 opacity-90">
            انضم إلى آلاف العملاء الذين يثقون بنا للحصول على أدويتك بسهولة وأمان
          </p>
          <Link href="/catalog">
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-10 py-6 text-base font-semibold rounded-lg button-hover pulse-glow">
              ابدأ التسوق الآن
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
