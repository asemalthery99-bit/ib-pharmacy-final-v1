import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Plus, Edit2, Trash2, Package, ShoppingCart, Users, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("medicines");

  // Check if user is admin
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <p className="text-lg font-semibold">ليس لديك صلاحيات كافية</p>
        </Card>
      </div>
    );
  }

  // Fetch data
  const { data: medicines = [] } = trpc.medicines.list.useQuery();
  const { data: orders = [] } = trpc.orders.getUserOrders.useQuery();
  const { data: promoCodes = [] } = trpc.promoCodes.getActive.useQuery();

  // Calculate statistics
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum: number, order: any) => sum + Number(order.totalPrice), 0);
  const totalMedicines = medicines.length;
  const totalUsers = 0; // سيتم إضافة هذا لاحقاً

  const menuItems = [
    { label: "الأدوية", value: "medicines", icon: Package },
    { label: "الطلبات", value: "orders", icon: ShoppingCart },
    { label: "أكواد الخصم", value: "promoCodes", icon: TrendingUp },
    { label: "المستخدمين", value: "users", icon: Users },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">إجمالي الطلبات</p>
                <p className="text-3xl font-bold text-emerald-600">{totalOrders}</p>
              </div>
              <ShoppingCart className="w-12 h-12 text-emerald-100" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">إجمالي الإيرادات</p>
                <p className="text-3xl font-bold text-blue-600">{totalRevenue.toFixed(2)} ريال</p>
              </div>
              <TrendingUp className="w-12 h-12 text-blue-100" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">عدد الأدوية</p>
                <p className="text-3xl font-bold text-purple-600">{totalMedicines}</p>
              </div>
              <Package className="w-12 h-12 text-purple-100" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">أكواد الخصم النشطة</p>
                <p className="text-3xl font-bold text-orange-600">{promoCodes.length}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-orange-100" />
            </div>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="medicines">الأدوية</TabsTrigger>
            <TabsTrigger value="orders">الطلبات</TabsTrigger>
            <TabsTrigger value="promoCodes">الخصومات</TabsTrigger>
            <TabsTrigger value="users">المستخدمين</TabsTrigger>
          </TabsList>

          {/* Medicines Tab */}
          <TabsContent value="medicines" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة الأدوية</h2>
              <Button className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                إضافة دواء جديد
              </Button>
            </div>
            <Card className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right py-3 px-4">اسم الدواء</th>
                      <th className="text-right py-3 px-4">السعر</th>
                      <th className="text-right py-3 px-4">الفئة</th>
                      <th className="text-right py-3 px-4">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {medicines.map((medicine: any) => (
                      <tr key={medicine.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">{medicine.name}</td>
                        <td className="py-3 px-4">{medicine.price} ريال</td>
                        <td className="py-3 px-4">
                          <Badge variant="outline">{medicine.categoryId}</Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-4">
            <h2 className="text-2xl font-bold">إدارة الطلبات</h2>
            <Card className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right py-3 px-4">رقم الطلب</th>
                      <th className="text-right py-3 px-4">المستخدم</th>
                      <th className="text-right py-3 px-4">المبلغ</th>
                      <th className="text-right py-3 px-4">الحالة</th>
                      <th className="text-right py-3 px-4">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((order: any) => (
                      <tr key={order.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">#{order.id}</td>
                        <td className="py-3 px-4">مستخدم</td>
                        <td className="py-3 px-4">{order.totalPrice} ريال</td>
                        <td className="py-3 px-4">
                          <Badge variant={order.status === "delivered" ? "default" : "secondary"}>
                            {order.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <Button size="sm" variant="outline">
                            عرض التفاصيل
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          {/* Promo Codes Tab */}
          <TabsContent value="promoCodes" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">أكواد الخصم</h2>
              <Button className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                إضافة كود جديد
              </Button>
            </div>
            <Card className="p-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right py-3 px-4">الكود</th>
                      <th className="text-right py-3 px-4">نوع الخصم</th>
                      <th className="text-right py-3 px-4">القيمة</th>
                      <th className="text-right py-3 px-4">الاستخدامات</th>
                      <th className="text-right py-3 px-4">الحالة</th>
                      <th className="text-right py-3 px-4">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {promoCodes.map((promo: any) => (
                      <tr key={promo.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4 font-mono">{promo.code}</td>
                        <td className="py-3 px-4">
                          {promo.discountType === "percentage" ? "نسبة %" : "مبلغ ثابت"}
                        </td>
                        <td className="py-3 px-4">{promo.discountValue}</td>
                        <td className="py-3 px-4">
                          {promo.usageCount}/{promo.usageLimit || "بلا حد"}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={promo.isActive ? "default" : "secondary"}>
                            {promo.isActive ? "نشط" : "معطل"}\n                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <h2 className="text-2xl font-bold">إدارة المستخدمين</h2>
            <Card className="p-6 text-center text-gray-600">
              <p>سيتم إضافة إدارة المستخدمين قريباً</p>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
