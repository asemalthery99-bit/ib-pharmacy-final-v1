import { useState } from "react";
import { Link } from "wouter";
import {
  Eye,
  CheckCircle2,
  Clock,
  AlertCircle,
  Send,
  X,
  ChevronRight,
  MessageSquare,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { usePrescription, Prescription } from "@/contexts/PrescriptionContext";
import { toast } from "sonner";

export default function PharmacistDashboard() {
  const {
    prescriptions,
    updatePrescriptionStatus,
    addPharmacistReview,
    getPendingPrescriptions,
  } = usePrescription();

  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);
  const [pharmacistNotes, setPharmacistNotes] = useState("");
  const [quotedPrice, setQuotedPrice] = useState("");
  const [selectedMedicines, setSelectedMedicines] = useState<string[]>([]);
  const [medicineInput, setMedicineInput] = useState("");
  const [filter, setFilter] = useState<"all" | "pending" | "reviewed" | "quoted">("pending");

  const pendingCount = getPendingPrescriptions().length;

  const filteredPrescriptions = prescriptions.filter((rx) => {
    if (filter === "all") return true;
    return rx.status === filter;
  });

  const handleRejectPrescription = (id: string) => {
    updatePrescriptionStatus(id, "rejected");
    toast.success("تم رفض الروشتة");
    setSelectedPrescription(null);
  };

  const handleSendQuote = (id: string) => {
    if (!quotedPrice || !selectedMedicines.length) {
      toast.error("يرجى إدخال السعر والأدوية");
      return;
    }

    addPharmacistReview(id, pharmacistNotes, parseFloat(quotedPrice), selectedMedicines);
    toast.success("تم إرسال عرض السعر للمستخدم");
    
    // إعادة تعيين النموذج
    setSelectedPrescription(null);
    setPharmacistNotes("");
    setQuotedPrice("");
    setSelectedMedicines([]);
    setMedicineInput("");
  };

  const handleAddMedicine = () => {
    if (!medicineInput.trim()) return;
    setSelectedMedicines([...selectedMedicines, medicineInput]);
    setMedicineInput("");
  };

  const handleRemoveMedicine = (index: number) => {
    setSelectedMedicines(selectedMedicines.filter((_, i) => i !== index));
  };

  const getStatusBadge = (status: Prescription["status"]) => {
    const statusMap = {
      pending: { label: "قيد الانتظار", variant: "default" as const },
      reviewed: { label: "تمت المراجعة", variant: "secondary" as const },
      quoted: { label: "تم إرسال عرض", variant: "outline" as const },
      completed: { label: "مكتمل", variant: "secondary" as const },
      rejected: { label: "مرفوض", variant: "destructive" as const },
    };
    return statusMap[status];
  };

  const getStatusIcon = (status: Prescription["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "reviewed":
        return <Eye className="w-4 h-4" />;
      case "quoted":
        return <CheckCircle2 className="w-4 h-4" />;
      case "completed":
        return <CheckCircle2 className="w-4 h-4" />;
      case "rejected":
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-foreground mb-2">لوحة تحكم الصيدلي</h1>
          <p className="text-muted-foreground">
            مراجعة الروشتات المرفوعة وإرسال عروض الأسعار للمستخدمين
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-border">
            <CardContent className="p-4">
              <div className="text-right">
                <p className="text-muted-foreground text-sm mb-1">الإجمالي</p>
                <p className="text-3xl font-bold text-foreground">{prescriptions.length}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-yellow-50 border-yellow-200">
            <CardContent className="p-4">
              <div className="text-right">
                <p className="text-muted-foreground text-sm mb-1">قيد الانتظار</p>
                <p className="text-3xl font-bold text-yellow-600">{pendingCount}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="text-right">
                <p className="text-muted-foreground text-sm mb-1">تمت المراجعة</p>
                <p className="text-3xl font-bold text-blue-600">
                  {prescriptions.filter((rx) => rx.status === "reviewed").length}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-green-50 border-green-200">
            <CardContent className="p-4">
              <div className="text-right">
                <p className="text-muted-foreground text-sm mb-1">عروض مرسلة</p>
                <p className="text-3xl font-bold text-green-600">
                  {prescriptions.filter((rx) => rx.status === "quoted").length}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Prescriptions List */}
          <div className="lg:col-span-2 space-y-4">
            {/* Filter Buttons */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {(["pending", "all", "reviewed", "quoted"] as const).map((f) => (
                <Button
                  key={f}
                  variant={filter === f ? "default" : "outline"}
                  onClick={() => setFilter(f)}
                  className="whitespace-nowrap"
                >
                  {f === "pending" && "قيد الانتظار"}
                  {f === "all" && "الكل"}
                  {f === "reviewed" && "تمت المراجعة"}
                  {f === "quoted" && "عروض مرسلة"}
                </Button>
              ))}
            </div>

            {/* Prescriptions Cards */}
            {filteredPrescriptions.length > 0 ? (
              filteredPrescriptions.map((rx) => (
                <Card
                  key={rx.id}
                  className={`border-border cursor-pointer hover:shadow-md transition ${
                    selectedPrescription?.id === rx.id ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setSelectedPrescription(rx)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 text-right">
                        <div className="flex items-center justify-end gap-2 mb-2">
                          <Badge
                            variant={getStatusBadge(rx.status).variant}
                            className="gap-1"
                          >
                            {getStatusIcon(rx.status)}
                            {getStatusBadge(rx.status).label}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          رقم الروشتة: {rx.id}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          المستخدم: {rx.userId}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(rx.uploadedAt).toLocaleDateString("ar-SA")}
                        </p>
                        {rx.quotedPrice && (
                          <p className="text-lg font-bold text-primary mt-2">
                            {rx.quotedPrice.toLocaleString()} ريال
                          </p>
                        )}
                      </div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-12 bg-muted/30 rounded-lg border-2 border-dashed border-border">
                <p className="text-muted-foreground">لا توجد روشتات في هذا القسم</p>
              </div>
            )}
          </div>

          {/* Details Panel */}
          {selectedPrescription ? (
            <div className="lg:col-span-1 space-y-4">
              <Card className="border-border sticky top-4">
                <CardHeader>
                  <CardTitle className="text-right">تفاصيل الروشتة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Prescription Image */}
                  <div className="rounded-lg overflow-hidden bg-muted">
                    <img
                      src={selectedPrescription.imageUrl}
                      alt="الروشتة"
                      className="w-full h-48 object-cover"
                    />
                  </div>

                  {/* User Notes */}
                  {selectedPrescription.notes && (
                    <div className="bg-muted/30 p-3 rounded-lg text-right">
                      <p className="text-sm font-semibold text-foreground mb-1">
                        ملاحظات المستخدم:
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {selectedPrescription.notes}
                      </p>
                    </div>
                  )}

                  {/* Pharmacist Review Form */}
                  {selectedPrescription.status === "pending" && (
                    <div className="space-y-4 border-t border-border pt-4">
                      <div>
                        <label className="text-sm font-semibold text-foreground block text-right mb-2">
                          ملاحظات الصيدلي
                        </label>
                        <Textarea
                          placeholder="أضف ملاحظاتك عن الروشتة والأدوية المقترحة..."
                          value={pharmacistNotes}
                          onChange={(e) => setPharmacistNotes(e.target.value)}
                          className="text-right min-h-24"
                        />
                      </div>

                      {/* Medicines List */}
                      <div>
                        <label className="text-sm font-semibold text-foreground block text-right mb-2">
                          الأدوية المقترحة
                        </label>
                        <div className="flex gap-2 mb-2">
                          <Button
                            size="sm"
                            onClick={handleAddMedicine}
                            disabled={!medicineInput.trim()}
                            className="bg-primary hover:bg-primary/90 text-white"
                          >
                            إضافة
                          </Button>
                          <Input
                            placeholder="اسم الدواء..."
                            value={medicineInput}
                            onChange={(e) => setMedicineInput(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === "Enter") handleAddMedicine();
                            }}
                            className="text-right"
                          />
                        </div>

                        {/* Selected Medicines */}
                        <div className="space-y-2">
                          {selectedMedicines.map((med, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between bg-muted/30 p-2 rounded"
                            >
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRemoveMedicine(idx)}
                                className="h-6 w-6 p-0"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                              <span className="text-sm text-foreground">{med}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Price Input */}
                      <div>
                        <label className="text-sm font-semibold text-foreground block text-right mb-2">
                          السعر المقترح (ريال)
                        </label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={quotedPrice}
                          onChange={(e) => setQuotedPrice(e.target.value)}
                          className="text-right"
                        />
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-2 pt-4 border-t border-border">
                        <Button
                          onClick={() => handleRejectPrescription(selectedPrescription.id)}
                          variant="destructive"
                          className="flex-1"
                        >
                          رفض
                        </Button>
                        <Button
                          onClick={() => handleSendQuote(selectedPrescription.id)}
                          className="flex-1 bg-primary hover:bg-primary/90 text-white gap-2"
                        >
                          <Send className="w-4 h-4" />
                          إرسال عرض
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Quoted Info */}
                  {selectedPrescription.status === "quoted" && (
                    <div className="space-y-3 border-t border-border pt-4">
                      <div className="bg-accent/10 p-3 rounded-lg">
                        <p className="text-sm font-semibold text-accent mb-1">
                          ✓ تم إرسال عرض السعر
                        </p>
                        <p className="text-2xl font-bold text-primary">
                          {selectedPrescription.quotedPrice?.toLocaleString()} ريال
                        </p>
                      </div>

                      {selectedPrescription.pharmacistNotes && (
                        <div className="bg-muted/30 p-3 rounded-lg text-right">
                          <p className="text-sm font-semibold text-foreground mb-1">
                            ملاحظات الصيدلي:
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {selectedPrescription.pharmacistNotes}
                          </p>
                        </div>
                      )}

                      {selectedPrescription.quotedMedicines && (
                        <div className="space-y-2">
                          <p className="text-sm font-semibold text-foreground">
                            الأدوية المقترحة:
                          </p>
                          {selectedPrescription.quotedMedicines.map((med, idx) => (
                            <div key={idx} className="text-sm text-muted-foreground">
                              • {med}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Rejected Info */}
                  {selectedPrescription.status === "rejected" && (
                    <div className="bg-destructive/10 p-3 rounded-lg border border-destructive/20">
                      <p className="text-sm font-semibold text-destructive">
                        ✗ تم رفض هذه الروشتة
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="lg:col-span-1 border-border">
              <CardContent className="p-8 text-center">
                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-20" />
                <p className="text-muted-foreground">
                  اختر روشتة لعرض التفاصيل والمراجعة
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
