import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Pill, Truck, Star, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-200">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Pill className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-gray-900">صيدلية إب الرقمية</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Button variant="outline" onClick={() => navigate("/catalog")}>
                  الكتالوج
                </Button>
                <Button variant="outline" onClick={() => navigate("/orders")}>
                  طلباتي
                </Button>
                <Button variant="outline" onClick={() => navigate("/cart")}>
                  السلة
                </Button>
                <Button variant="outline" onClick={() => navigate("/profile")}>
                  {user?.name || "ملفي"}
                </Button>
              </>
            ) : (
              <Button onClick={() => window.location.href = getLoginUrl()}>
                تسجيل الدخول
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container max-w-6xl mx-auto px-4 py-20 text-center">
        <h2 className="text-5xl font-bold text-gray-900 mb-6">
          صيدليتك الموثوقة في متناول يدك
        </h2>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          احصل على الأدوية والعلاجات بسهولة وسرعة مع خدمة توصيل موثوقة وأسعار منافسة
        </p>
        <div className="flex gap-4 justify-center">
          <Button size="lg" onClick={() => navigate("/catalog")} className="bg-green-600 hover:bg-green-700">
            تصفح الأدوية
          </Button>
          <Button size="lg" variant="outline">
            تعرف على الخدمة
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="container max-w-6xl mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">لماذا تختار صيدليتنا؟</h3>
          <div className="grid md:grid-cols-4 gap-8">
            <Card className="text-center">
              <CardHeader>
                <Pill className="w-12 h-12 mx-auto text-green-600 mb-4" />
                <CardTitle>أدوية أصلية</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">جميع الأدوية مرخصة وأصلية من الشركات المعروفة</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Truck className="w-12 h-12 mx-auto text-blue-600 mb-4" />
                <CardTitle>توصيل سريع</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">توصيل في نفس اليوم مع تتبع مباشر للطلب</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Star className="w-12 h-12 mx-auto text-yellow-600 mb-4" />
                <CardTitle>تقييمات موثوقة</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">اقرأ تقييمات العملاء الحقيقية لكل دواء</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Zap className="w-12 h-12 mx-auto text-orange-600 mb-4" />
                <CardTitle>عروض حصرية</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">احصل على خصومات وعروض خاصة طوال العام</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-16">
        <div className="container max-w-6xl mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-4">ابدأ التسوق الآن</h3>
          <p className="text-lg mb-8 opacity-90">
            اختر من آلاف الأدوية والعلاجات بأسعار منافسة
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => navigate("/catalog")}
            className="bg-white text-green-600 hover:bg-gray-100"
          >
            تصفح الكتالوج
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-white mb-4">عن الصيدلية</h4>
              <p className="text-sm">صيدلية إب الرقمية توفر أدوية أصلية وموثوقة مع خدمة توصيل سريعة</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">الخدمات</h4>
              <ul className="text-sm space-y-2">
                <li><a href="#" className="hover:text-white">الأدوية</a></li>
                <li><a href="#" className="hover:text-white">التوصيل</a></li>
                <li><a href="#" className="hover:text-white">الاستشارات</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">المساعدة</h4>
              <ul className="text-sm space-y-2">
                <li><a href="#" className="hover:text-white">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-white">التواصل</a></li>
                <li><a href="#" className="hover:text-white">الشروط والأحكام</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">تابعنا</h4>
              <p className="text-sm">للمزيد من المعلومات والعروض الحصرية</p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2026 صيدلية إب الرقمية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
