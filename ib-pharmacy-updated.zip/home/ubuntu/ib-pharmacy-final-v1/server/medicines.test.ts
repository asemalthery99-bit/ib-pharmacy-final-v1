import { describe, it, expect, beforeAll } from "vitest";
import * as db from "./db";

describe("Medicines Router", () => {
  let medicineId: number;

  beforeAll(async () => {
    // Fetch existing medicines for testing
    const medicines = await db.getMedicines();
    if (medicines.length > 0) {
      medicineId = medicines[0].id;
    }
  });

  it("should fetch all medicines", async () => {
    const medicines = await db.getMedicines();
    expect(Array.isArray(medicines)).toBe(true);
    expect(medicines.length).toBeGreaterThan(0);
  });

  it("should fetch a medicine by ID", async () => {
    if (!medicineId) {
      console.log("Skipping test: no medicines found");
      return;
    }
    const medicine = await db.getMedicineById(medicineId);
    expect(medicine).toBeDefined();
    expect(medicine?.id).toBe(medicineId);
  });

  it("should search medicines by query", async () => {
    const results = await db.searchMedicines("باراسيتامول");
    expect(Array.isArray(results)).toBe(true);
  });

  it("should get average rating for a medicine", async () => {
    if (!medicineId) {
      console.log("Skipping test: no medicines found");
      return;
    }
    const rating = await db.getAverageRating(medicineId);
    expect(typeof rating).toBe("number");
  });
});

describe("Categories Router", () => {
  it("should fetch all categories", async () => {
    const categories = await db.getCategories();
    expect(Array.isArray(categories)).toBe(true);
    expect(categories.length).toBeGreaterThan(0);
  });
});

describe("Inventory Router", () => {
  it("should fetch inventory by medicine ID", async () => {
    const medicines = await db.getMedicines();
    if (medicines.length === 0) {
      console.log("Skipping test: no medicines found");
      return;
    }
    const inventory = await db.getInventoryByMedicineId(medicines[0].id);
    expect(inventory).toBeDefined();
  });
});

describe("Promo Codes Router", () => {
  it("should fetch active promo codes", async () => {
    const promoCodes = await db.getActivePromoCodes();
    expect(Array.isArray(promoCodes)).toBe(true);
  });

  it("should validate a promo code", async () => {
    const promoCodes = await db.getActivePromoCodes();
    if (promoCodes.length === 0) {
      console.log("Skipping test: no active promo codes found");
      return;
    }
    const promoCode = await db.getPromoCodeByCode(promoCodes[0].code);
    expect(promoCode).toBeDefined();
    expect(promoCode?.code).toBe(promoCodes[0].code);
  });
});
