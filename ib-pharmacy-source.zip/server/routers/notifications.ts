import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import {
  notifyNewOrder,
  notifyNewPrescription,
  notifyLowInventory,
  notifyPaymentSuccess,
  notifyPaymentFailure,
  notifyOrderStatusUpdate,
  notifyPrescriptionStatusUpdate,
  notifyMultipleLowInventory,
} from "../services/notifications";

export const notificationsRouter = router({
  /**
   * Send manual notification (admin only)
   */
  sendManual: protectedProcedure
    .input(z.object({
      title: z.string(),
      content: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Only admins can send manual notifications");
      }

      try {
        const result = await notifyNewOrder(0, "0", 0);
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error sending manual notification:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about new order
   */
  notifyOrder: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      totalPrice: z.string(),
      itemCount: z.number(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyNewOrder(input.orderId, input.totalPrice, input.itemCount);
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying order:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about new prescription
   */
  notifyPrescription: protectedProcedure
    .input(z.object({
      prescriptionId: z.number(),
      patientName: z.string().optional(),
      medicineCount: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyNewPrescription(
          input.prescriptionId,
          input.patientName,
          input.medicineCount
        );
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying prescription:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about low inventory
   */
  notifyLowStock: protectedProcedure
    .input(z.object({
      medicineName: z.string(),
      currentQuantity: z.number(),
      threshold: z.number(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyLowInventory(
          input.medicineName,
          input.currentQuantity,
          input.threshold
        );
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying low stock:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about payment success
   */
  notifyPaymentSuccess: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      totalPrice: z.string(),
      paymentMethod: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyPaymentSuccess(
          input.orderId,
          input.totalPrice,
          input.paymentMethod
        );
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying payment success:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about payment failure
   */
  notifyPaymentFailure: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      reason: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyPaymentFailure(input.orderId, input.reason);
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying payment failure:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about order status update
   */
  notifyOrderStatus: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      status: z.string(),
      statusArabic: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyOrderStatusUpdate(
          input.orderId,
          input.status,
          input.statusArabic
        );
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying order status:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about prescription status update
   */
  notifyPrescriptionStatus: protectedProcedure
    .input(z.object({
      prescriptionId: z.number(),
      status: z.string(),
      statusArabic: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyPrescriptionStatusUpdate(
          input.prescriptionId,
          input.status,
          input.statusArabic
        );
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying prescription status:", error);
        return { success: false, error: String(error) };
      }
    }),

  /**
   * Notify about multiple low inventory items
   */
  notifyMultipleLowStock: protectedProcedure
    .input(z.object({
      items: z.array(z.object({
        name: z.string(),
        quantity: z.number(),
        threshold: z.number(),
      })),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await notifyMultipleLowInventory(input.items);
        return { success: result };
      } catch (error) {
        console.error("[Notifications] Error notifying multiple low stock:", error);
        return { success: false, error: String(error) };
      }
    }),
});
