import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Pill, Truck, Star, Lock, ShoppingCart, Heart, Zap, Users } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-white to-emerald-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Pill className="w-8 h-8 text-emerald-600" />
            <span className="text-2xl font-bold text-emerald-600">صيدلية إب</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Button variant="ghost" onClick={() => navigate("/catalog")}>
                  الكتالوج
                </Button>
                <Button variant="ghost" onClick={() => navigate("/orders")}>
                  طلباتي
                </Button>
                <Button variant="ghost" onClick={() => navigate("/cart")}>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  السلة
                </Button>
                {user?.role === "admin" && (
                  <Button variant="ghost" onClick={() => navigate("/admin")}>
                    لوحة التحكم
                  </Button>
                )}
                {user?.role === "pharmacist" && (
                  <Button variant="ghost" onClick={() => navigate("/pharmacist")}>
                    لوحة الصيدلي
                  </Button>
                )}
              </>
            ) : (
              <Button
                onClick={() => window.location.href = getLoginUrl()}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                تسجيل الدخول
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
              صيدليتك الموثوقة
              <span className="text-emerald-600"> أونلاين</span>
            </h1>
            <p className="text-xl text-gray-600">
              احصل على أدويتك بسهولة وسرعة مع ضمان الجودة والأمان. توصيل سريع وآمن لجميع أنحاء المدينة.
            </p>
            <div className="flex gap-4">
              <Button
                onClick={() => navigate("/catalog")}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-6 text-lg"
              >
                تصفح الأدوية
              </Button>
              <Button
                variant="outline"
                className="px-8 py-6 text-lg"
              >
                اتصل بنا
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="bg-gradient-to-br from-emerald-100 to-emerald-50 rounded-3xl p-12 flex items-center justify-center h-96">
              <Pill className="w-48 h-48 text-emerald-200 opacity-50" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">لماذا تختار صيدليتنا؟</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Pill className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">أدوية أصلية</h3>
              <p className="text-gray-600">جميع الأدوية مرخصة وأصلية من الشركات المصنعة الموثوقة</p>
            </Card>
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Truck className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">توصيل سريع</h3>
              <p className="text-gray-600">توصيل في نفس اليوم لجميع الطلبات قبل الساعة 3 عصراً</p>
            </Card>
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Star className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">تقييمات عالية</h3>
              <p className="text-gray-600">آلاف العملاء الراضين عن خدماتنا وجودة أدويتنا</p>
            </Card>
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Lock className="w-12 h-12 text-red-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">آمن وموثوق</h3>
              <p className="text-gray-600">معاملات آمنة وحماية كاملة لبيانات العملاء</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="text-center">
            <p className="text-4xl font-bold text-emerald-600">10K+</p>
            <p className="text-gray-600 mt-2">عميل سعيد</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-emerald-600">5K+</p>
            <p className="text-gray-600 mt-2">دواء متاح</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-emerald-600">24/7</p>
            <p className="text-gray-600 mt-2">خدمة عملاء</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-emerald-600">99%</p>
            <p className="text-gray-600 mt-2">رضا العملاء</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-emerald-600 to-emerald-700 py-16">
        <div className="container mx-auto px-4 text-center text-white">
          <h2 className="text-4xl font-bold mb-4">ابدأ التسوق الآن</h2>
          <p className="text-xl mb-8 opacity-90">
            احصل على خصم 20% على أول طلب لك
          </p>
          <Button
            onClick={() => navigate("/catalog")}
            className="bg-white text-emerald-600 hover:bg-gray-100 px-8 py-6 text-lg font-semibold"
          >
            تصفح الآن
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Pill className="w-6 h-6 text-emerald-400" />
                <span className="text-xl font-bold">صيدلية إب</span>
              </div>
              <p className="text-gray-400">صيدليتك الموثوقة للحصول على الأدوية بسهولة وأمان</p>
            </div>
            <div>
              <h3 className="font-bold mb-4">الروابط السريعة</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-emerald-400">الرئيسية</a></li>
                <li><a href="#" className="hover:text-emerald-400">الكتالوج</a></li>
                <li><a href="#" className="hover:text-emerald-400">عن الصيدلية</a></li>
                <li><a href="#" className="hover:text-emerald-400">التواصل</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">المساعدة</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-emerald-400">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-emerald-400">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-emerald-400">شروط الاستخدام</a></li>
                <li><a href="#" className="hover:text-emerald-400">سياسة الاسترجاع</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">تواصل معنا</h3>
              <ul className="space-y-2 text-gray-400">
                <li>📞 +966 9 XXXX XXXX</li>
                <li>📧 info@ibpharmacy.com</li>
                <li>📍 مدينة إب، اليمن</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
            <p>&copy; 2026 صيدلية إب. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
