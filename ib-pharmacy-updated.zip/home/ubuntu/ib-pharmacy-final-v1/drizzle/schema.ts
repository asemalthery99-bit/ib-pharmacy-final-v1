import { decimal, int, json, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, index } from "drizzle-orm/mysql-core";

/**
 * صيدلية إب الرقمية - قاعدة البيانات الشاملة
 * تتضمن جميع الجداول المطلوبة للنظام المتكامل
 */

// ============ Users Table ============
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "pharmacist", "admin"]).default("user").notNull(),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============ Categories Table ============
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  imageUrl: text("imageUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

// ============ Medicines Table ============
export const medicines = mysqlTable("medicines", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  categoryId: int("categoryId").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  imageUrl: text("imageUrl"),
  activeIngredient: varchar("activeIngredient", { length: 255 }),
  manufacturer: varchar("manufacturer", { length: 255 }),
  expiryDate: timestamp("expiryDate"),
  requiresPrescription: boolean("requiresPrescription").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  categoryIdIdx: index("categoryId_idx").on(table.categoryId),
}));

export type Medicine = typeof medicines.$inferSelect;
export type InsertMedicine = typeof medicines.$inferInsert;

// ============ Inventory Table ============
export const inventory = mysqlTable("inventory", {
  id: int("id").autoincrement().primaryKey(),
  medicineId: int("medicineId").notNull().unique(),
  quantity: int("quantity").default(0).notNull(),
  minThreshold: int("minThreshold").default(50),
  maxThreshold: int("maxThreshold").default(1000),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = typeof inventory.$inferInsert;

// ============ Orders Table ============
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["pending", "confirmed", "preparing", "ready", "shipped", "delivered", "cancelled"]).default("pending").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed", "refunded"]).default("pending").notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  discountAmount: decimal("discountAmount", { precision: 10, scale: 2 }).default("0"),
  promoCodeId: int("promoCodeId"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("userId_idx").on(table.userId),
}));

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// ============ Order Items Table ============
export const orderItems = mysqlTable("orderItems", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  medicineId: int("medicineId").notNull(),
  quantity: int("quantity").notNull(),
  priceAtTime: decimal("priceAtTime", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  orderIdIdx: index("orderId_idx").on(table.orderId),
  medicineIdIdx: index("medicineId_idx").on(table.medicineId),
}));

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;

// ============ Ratings Table ============
export const ratings = mysqlTable("ratings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  medicineId: int("medicineId"),
  orderId: int("orderId"),
  ratingType: mysqlEnum("ratingType", ["medicine", "service", "delivery", "driver"]).notNull(),
  score: int("score").notNull(), // 1-5
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("userId_idx").on(table.userId),
  medicineIdIdx: index("medicineId_idx").on(table.medicineId),
  orderIdIdx: index("orderId_idx").on(table.orderId),
}));

export type Rating = typeof ratings.$inferSelect;
export type InsertRating = typeof ratings.$inferInsert;

// ============ Promo Codes Table ============
export const promoCodes = mysqlTable("promoCodes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  discountType: mysqlEnum("discountType", ["percentage", "fixed"]).notNull(),
  discountValue: decimal("discountValue", { precision: 10, scale: 2 }).notNull(),
  maxDiscount: decimal("maxDiscount", { precision: 10, scale: 2 }),
  minOrderAmount: decimal("minOrderAmount", { precision: 10, scale: 2 }).default("0"),
  usageLimit: int("usageLimit"),
  usageCount: int("usageCount").default(0),
  validFrom: timestamp("validFrom").notNull(),
  validUntil: timestamp("validUntil").notNull(),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PromoCode = typeof promoCodes.$inferSelect;
export type InsertPromoCode = typeof promoCodes.$inferInsert;

// ============ Delivery Tracking Table ============
export const deliveryTracking = mysqlTable("deliveryTracking", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull().unique(),
  driverId: int("driverId"),
  currentStatus: mysqlEnum("currentStatus", ["pending", "assigned", "picked_up", "in_transit", "delivered", "failed"]).default("pending").notNull(),
  currentLat: decimal("currentLat", { precision: 10, scale: 8 }),
  currentLng: decimal("currentLng", { precision: 11, scale: 8 }),
  estimatedDeliveryTime: timestamp("estimatedDeliveryTime"),
  actualDeliveryTime: timestamp("actualDeliveryTime"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  orderIdIdx: index("orderId_idx").on(table.orderId),
}));

export type DeliveryTracking = typeof deliveryTracking.$inferSelect;
export type InsertDeliveryTracking = typeof deliveryTracking.$inferInsert;

// ============ Delivery Stages Table ============
export const deliveryStages = mysqlTable("deliveryStages", {
  id: int("id").autoincrement().primaryKey(),
  deliveryTrackingId: int("deliveryTrackingId").notNull(),
  stage: varchar("stage", { length: 100 }).notNull(),
  description: text("description"),
  lat: decimal("lat", { precision: 10, scale: 8 }),
  lng: decimal("lng", { precision: 11, scale: 8 }),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  deliveryTrackingIdIdx: index("deliveryTrackingId_idx").on(table.deliveryTrackingId),
}));

export type DeliveryStage = typeof deliveryStages.$inferSelect;
export type InsertDeliveryStage = typeof deliveryStages.$inferInsert;

// ============ Driver Ratings Table ============
export const driverRatings = mysqlTable("driverRatings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  driverId: int("driverId").notNull(),
  orderId: int("orderId").notNull(),
  score: int("score").notNull(), // 1-5
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("userId_idx").on(table.userId),
  driverIdIdx: index("driverId_idx").on(table.driverId),
  orderIdIdx: index("orderId_idx").on(table.orderId),
}));

export type DriverRating = typeof driverRatings.$inferSelect;
export type InsertDriverRating = typeof driverRatings.$inferInsert;

// ============ Cart Table (Session-based) ============
export const cart = mysqlTable("cart", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  items: json("items").notNull(), // JSON array of {medicineId, quantity}
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("userId_idx").on(table.userId),
}));

export type Cart = typeof cart.$inferSelect;
export type InsertCart = typeof cart.$inferInsert;
