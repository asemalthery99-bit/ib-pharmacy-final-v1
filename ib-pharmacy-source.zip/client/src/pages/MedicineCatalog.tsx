import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Search, Filter, ShoppingCart, ChevronLeft } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { medicines, categories } from "@/lib/data";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

export default function MedicineCatalog() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const { addToCart } = useCart();

  const filteredMedicines = useMemo(() => {
    return medicines.filter((med) => {
      const matchesSearch = 
        med.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        med.arabicName.includes(searchQuery);
      const matchesCategory = 
        selectedCategory === "all" || med.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">كتالوج الأدوية</h1>
            <p className="text-muted-foreground">ابحث عن الأدوية والمنتجات الصحية التي تحتاجها</p>
          </div>
          
          <div className="relative w-full md:w-96">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="ابحث بالاسم العربي أو الإنجليزي..."
              className="pr-10 h-12 text-right"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Categories Section */}
        <div className="mb-10 overflow-x-auto pb-2">
          <div className="flex items-center gap-3 min-w-max">
            <div className="flex items-center gap-2 text-primary font-bold ml-4">
              <Filter className="w-5 h-5" />
              <span>التصنيفات:</span>
            </div>
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? "default" : "outline"}
                className={`rounded-full px-6 transition-all ${
                  selectedCategory === cat.id ? "bg-primary text-white" : "hover:border-primary hover:text-primary"
                }`}
                onClick={() => setSelectedCategory(cat.id)}
              >
                {cat.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Results Grid */}
        {filteredMedicines.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredMedicines.map((med) => (
              <Card key={med.id} className="card-hover overflow-hidden border-border group">
                <Link href={`/medicine/${med.id}`}>
                  <div className="aspect-square overflow-hidden relative cursor-pointer">
                    <img
                      src={med.image}
                      alt={med.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <Badge className="absolute top-3 right-3 bg-white/90 text-primary hover:bg-white">
                      {categories.find(c => c.id === med.category)?.name}
                    </Badge>
                  </div>
                </Link>
                <CardHeader className="p-4 text-right">
                  <Link href={`/medicine/${med.id}`}>
                    <CardTitle className="text-xl font-bold mb-1 hover:text-primary transition cursor-pointer">
                      {med.arabicName}
                    </CardTitle>
                  </Link>
                  <p className="text-sm text-muted-foreground">{med.name}</p>
                </CardHeader>
                <CardContent className="px-4 pb-2 text-right">
                  <p className="text-lg font-bold text-primary">{med.price.toLocaleString()} ريال</p>
                </CardContent>
                <CardFooter className="p-4 pt-0 flex gap-2">
                  <Button 
                    className="flex-1 bg-primary hover:bg-primary/90 text-white gap-2"
                    onClick={() => {
                      addToCart(parseInt(med.id), 1);
                      toast.success(`تم إضافة ${med.arabicName} إلى السلة`);
                    }}
                  >
                    <ShoppingCart className="w-4 h-4" />
                    أضف للسلة
                  </Button>
                  <Link href={`/medicine/${med.id}`} className="flex-1">
                    <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/10">
                      التفاصيل
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-muted/30 rounded-2xl border-2 border-dashed border-border">
            <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-20" />
            <h3 className="text-xl font-bold mb-2">لا توجد نتائج بحث</h3>
            <p className="text-muted-foreground">جرب البحث بكلمات مختلفة أو تغيير التصنيف</p>
            <Button 
              variant="link" 
              className="mt-4 text-primary"
              onClick={() => {setSearchQuery(""); setSelectedCategory("all");}}
            >
              إعادة تعيين الفلاتر
            </Button>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
