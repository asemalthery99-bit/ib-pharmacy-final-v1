import nodemailer from "nodemailer";

/**
 * Email Service
 * Handles sending emails to customers and pharmacists
 * Supports both SendGrid and direct SMTP
 */

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

interface OrderEmailData {
  orderId: number;
  customerName: string;
  customerEmail: string;
  totalPrice: number;
  itemsCount: number;
  orderStatus: string;
}

interface PrescriptionEmailData {
  prescriptionId: number;
  customerName: string;
  customerEmail: string;
  pharmacistEmail: string;
  status: string;
}

class EmailService {
  private transporter: nodemailer.Transporter | null = null;

  constructor() {
    this.initializeTransporter();
  }

  private initializeTransporter() {
    const smtpHost = process.env.SMTP_HOST || "smtp.gmail.com";
    const smtpPort = parseInt(process.env.SMTP_PORT || "587");
    const smtpUser = process.env.SMTP_USER;
    const smtpPassword = process.env.SMTP_PASSWORD;

    if (smtpUser && smtpPassword) {
      this.transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: {
          user: smtpUser,
          pass: smtpPassword,
        },
      });
    } else {
      console.warn("[EmailService] SMTP credentials not configured. Email service disabled.");
    }
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.transporter) {
      console.warn("[EmailService] Email service not configured");
      return false;
    }

    try {
      const mailOptions = {
        from: process.env.SMTP_FROM || "noreply@ibpharmacy.com",
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text,
      };

      const info = await this.transporter.sendMail(mailOptions);
      console.log(`[EmailService] Email sent successfully to ${options.to}. Message ID: ${info.messageId}`);
      return true;
    } catch (error) {
      console.error("[EmailService] Failed to send email:", error);
      return false;
    }
  }

  async sendOrderConfirmation(data: OrderEmailData): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; direction: rtl; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #0066cc; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .order-details { margin: 20px 0; border: 1px solid #ddd; padding: 15px; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .button { background-color: #0066cc; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>تأكيد الطلب</h1>
          </div>
          <div class="content">
            <p>السلام عليكم ورحمة الله وبركاته</p>
            <p>شكراً لك ${data.customerName}، تم استقبال طلبك بنجاح!</p>
            
            <div class="order-details">
              <h3>تفاصيل الطلب:</h3>
              <p><strong>رقم الطلب:</strong> #${data.orderId}</p>
              <p><strong>عدد المنتجات:</strong> ${data.itemsCount}</p>
              <p><strong>الإجمالي:</strong> ${data.totalPrice} ريال</p>
              <p><strong>حالة الطلب:</strong> ${this.getStatusInArabic(data.orderStatus)}</p>
            </div>

            <p>سيتم إخطارك بتحديثات الطلب عبر البريد الإلكتروني.</p>
            
            <p>
              <a href="${process.env.CLIENT_URL}/orders/${data.orderId}" class="button">
                عرض تفاصيل الطلب
              </a>
            </p>
          </div>
          <div class="footer">
            <p>صيدلية إب الرقمية</p>
            <p>© 2026 جميع الحقوق محفوظة</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: data.customerEmail,
      subject: `تأكيد الطلب #${data.orderId}`,
      html,
    });
  }

  async sendOrderStatusUpdate(data: OrderEmailData): Promise<boolean> {
    const statusMessages: Record<string, string> = {
      pending: "جاري المراجعة",
      preparing: "جاري التحضير",
      ready: "جاهز للاستلام",
      completed: "تم تسليم الطلب",
      cancelled: "تم إلغاء الطلب",
    };

    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; direction: rtl; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #0066cc; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .status-box { background-color: #e8f4f8; padding: 15px; border-right: 4px solid #0066cc; margin: 20px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>تحديث حالة الطلب</h1>
          </div>
          <div class="content">
            <p>السلام عليكم ورحمة الله وبركاته</p>
            
            <div class="status-box">
              <h3>حالة الطلب الجديدة:</h3>
              <p style="font-size: 18px; color: #0066cc; font-weight: bold;">
                ${statusMessages[data.orderStatus] || data.orderStatus}
              </p>
            </div>

            <p><strong>رقم الطلب:</strong> #${data.orderId}</p>
            <p>سيتم إخطارك بأي تحديثات جديدة.</p>
          </div>
          <div class="footer">
            <p>صيدلية إب الرقمية</p>
            <p>© 2026 جميع الحقوق محفوظة</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: data.customerEmail,
      subject: `تحديث حالة الطلب #${data.orderId}`,
      html,
    });
  }

  async sendPrescriptionNotification(data: PrescriptionEmailData): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; direction: rtl; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #28a745; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>روشتة طبية جديدة</h1>
          </div>
          <div class="content">
            <p>السلام عليكم ورحمة الله وبركاته</p>
            <p>تم استقبال روشتة طبية جديدة من ${data.customerName}</p>
            
            <p><strong>رقم الروشتة:</strong> #${data.prescriptionId}</p>
            <p><strong>الحالة:</strong> ${this.getPrescriptionStatusInArabic(data.status)}</p>
            
            <p>يرجى مراجعة الروشتة وإرسال عرض السعر في أقرب وقت.</p>
          </div>
          <div class="footer">
            <p>صيدلية إب الرقمية</p>
            <p>© 2026 جميع الحقوق محفوظة</p>
          </div>
        </div>
      </body>
      </html>
    `;

    // Send to pharmacist
    return this.sendEmail({
      to: data.pharmacistEmail,
      subject: `روشتة طبية جديدة #${data.prescriptionId}`,
      html,
    });
  }

  async sendWelcomeEmail(customerName: string, customerEmail: string): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; direction: rtl; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #0066cc; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>أهلاً وسهلاً بك</h1>
          </div>
          <div class="content">
            <p>السلام عليكم ورحمة الله وبركاته ${customerName}</p>
            <p>شكراً لتسجيلك في صيدلية إب الرقمية!</p>
            
            <p>نحن هنا لخدمتك بأفضل الأدوية والخدمات الصيدلانية.</p>
            
            <h3>ما الذي يمكنك فعله:</h3>
            <ul>
              <li>البحث عن الأدوية والمنتجات الصيدلانية</li>
              <li>رفع الروشتات الطبية للحصول على عروض أسعار</li>
              <li>تتبع طلباتك في الوقت الفعلي</li>
              <li>الحصول على نقاط الولاء والمكافآت</li>
            </ul>
          </div>
          <div class="footer">
            <p>صيدلية إب الرقمية</p>
            <p>© 2026 جميع الحقوق محفوظة</p>
          </div>
        </div>
      </body>
      </html>
    `;

    return this.sendEmail({
      to: customerEmail,
      subject: "أهلاً وسهلاً بك في صيدلية إب الرقمية",
      html,
    });
  }

  private getStatusInArabic(status: string): string {
    const statusMap: Record<string, string> = {
      pending: "قيد الانتظار",
      preparing: "جاري التحضير",
      ready: "جاهز للاستلام",
      completed: "مكتمل",
      cancelled: "ملغى",
    };
    return statusMap[status] || status;
  }

  private getPrescriptionStatusInArabic(status: string): string {
    const statusMap: Record<string, string> = {
      pending: "قيد الانتظار",
      reviewed: "تمت المراجعة",
      quoted: "معروض السعر",
      completed: "مكتملة",
      rejected: "مرفوضة",
    };
    return statusMap[status] || status;
  }
}

export const emailService = new EmailService();
