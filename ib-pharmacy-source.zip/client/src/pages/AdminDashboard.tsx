import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Users, Package, ShoppingCart, DollarSign, TrendingUp, AlertTriangle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

export default function AdminDashboard() {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("month");

  // Check admin role
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-xl font-semibold mb-2">غير مصرح</h2>
          <p className="text-gray-600">لا تملك صلاحية الوصول إلى لوحة التحكم</p>
        </Card>
      </div>
    );
  }

  // Mock data for charts
  const salesData = [
    { name: "السبت", sales: 4000, orders: 24 },
    { name: "الأحد", sales: 3000, orders: 13 },
    { name: "الاثنين", sales: 2000, orders: 9 },
    { name: "الثلاثاء", sales: 2780, orders: 39 },
    { name: "الأربعاء", sales: 1890, orders: 22 },
    { name: "الخميس", sales: 2390, orders: 22 },
    { name: "الجمعة", sales: 3490, orders: 29 },
  ];

  const topMedicines = [
    { name: "بنادول", value: 30 },
    { name: "أسبرين", value: 25 },
    { name: "ديكلوفيناك", value: 20 },
    { name: "أموكسيسيلين", value: 15 },
    { name: "أخرى", value: 10 },
  ];

  const stats = [
    {
      label: "إجمالي المستخدمين",
      value: "1,234",
      icon: Users,
      color: "bg-blue-100 text-blue-600",
      trend: "+12%",
    },
    {
      label: "الطلبات اليوم",
      value: "42",
      icon: ShoppingCart,
      color: "bg-green-100 text-green-600",
      trend: "+8%",
    },
    {
      label: "الإيرادات اليوم",
      value: "$2,450",
      icon: DollarSign,
      color: "bg-purple-100 text-purple-600",
      trend: "+15%",
    },
    {
      label: "الأدوية المتوفرة",
      value: "156",
      icon: Package,
      color: "bg-orange-100 text-orange-600",
      trend: "-2%",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم</h1>
          <p className="text-gray-600 mt-2">مرحباً بك {user?.name}</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">{stat.label}</p>
                    <p className="text-2xl font-bold mt-2">{stat.value}</p>
                    <p className="text-green-600 text-xs mt-2">{stat.trend}</p>
                  </div>
                  <div className={`p-3 rounded-lg ${stat.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Sales Chart */}
          <Card className="lg:col-span-2 p-6">
            <h3 className="text-lg font-semibold mb-4">المبيعات والطلبات</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="sales" stroke="#3b82f6" name="المبيعات ($)" />
                <Line type="monotone" dataKey="orders" stroke="#10b981" name="الطلبات" />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Top Medicines */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">الأدوية الأكثر طلباً</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={topMedicines}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {topMedicines.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="orders" className="space-y-4">
          <TabsList>
            <TabsTrigger value="orders">الطلبات</TabsTrigger>
            <TabsTrigger value="users">المستخدمين</TabsTrigger>
            <TabsTrigger value="medicines">الأدوية</TabsTrigger>
            <TabsTrigger value="inventory">المخزون</TabsTrigger>
          </TabsList>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">آخر الطلبات</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-right">رقم الطلب</th>
                      <th className="px-4 py-2 text-right">العميل</th>
                      <th className="px-4 py-2 text-right">المبلغ</th>
                      <th className="px-4 py-2 text-right">الحالة</th>
                      <th className="px-4 py-2 text-right">التاريخ</th>
                      <th className="px-4 py-2 text-right">الإجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[1, 2, 3, 4, 5].map(i => (
                      <tr key={i} className="border-t">
                        <td className="px-4 py-2">#{1000 + i}</td>
                        <td className="px-4 py-2">عميل {i}</td>
                        <td className="px-4 py-2">$250.00</td>
                        <td className="px-4 py-2">
                          <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
                            قيد الانتظار
                          </span>
                        </td>
                        <td className="px-4 py-2">2026-03-18</td>
                        <td className="px-4 py-2">
                          <Button variant="outline" size="sm">عرض</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">المستخدمين</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-right">الاسم</th>
                      <th className="px-4 py-2 text-right">البريد الإلكتروني</th>
                      <th className="px-4 py-2 text-right">الدور</th>
                      <th className="px-4 py-2 text-right">تاريخ الانضمام</th>
                      <th className="px-4 py-2 text-right">الإجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[1, 2, 3, 4, 5].map(i => (
                      <tr key={i} className="border-t">
                        <td className="px-4 py-2">مستخدم {i}</td>
                        <td className="px-4 py-2">user{i}@example.com</td>
                        <td className="px-4 py-2">
                          <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                            عميل
                          </span>
                        </td>
                        <td className="px-4 py-2">2026-01-15</td>
                        <td className="px-4 py-2">
                          <Button variant="outline" size="sm">تعديل</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          {/* Medicines Tab */}
          <TabsContent value="medicines">
            <Card className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">الأدوية</h3>
                <Button>إضافة دواء</Button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-right">اسم الدواء</th>
                      <th className="px-4 py-2 text-right">الفئة</th>
                      <th className="px-4 py-2 text-right">السعر</th>
                      <th className="px-4 py-2 text-right">الكمية</th>
                      <th className="px-4 py-2 text-right">الإجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[1, 2, 3, 4, 5].map(i => (
                      <tr key={i} className="border-t">
                        <td className="px-4 py-2">دواء {i}</td>
                        <td className="px-4 py-2">مسكنات</td>
                        <td className="px-4 py-2">$5.99</td>
                        <td className="px-4 py-2">150</td>
                        <td className="px-4 py-2">
                          <Button variant="outline" size="sm">تعديل</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </TabsContent>

          {/* Inventory Tab */}
          <TabsContent value="inventory">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">تنبيهات المخزون</h3>
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="p-4 bg-orange-50 border border-orange-200 rounded-lg flex items-center justify-between">
                    <div>
                      <p className="font-semibold">دواء {i}</p>
                      <p className="text-sm text-gray-600">الكمية المتبقية: 10 وحدات (الحد الأدنى: 50)</p>
                    </div>
                    <Button variant="outline">إعادة تخزين</Button>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
