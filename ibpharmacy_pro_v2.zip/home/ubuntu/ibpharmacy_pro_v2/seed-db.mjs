import { drizzle } from "drizzle-orm/mysql2";
import { categories, medicines, inventory, promoCodes } from "./drizzle/schema.js";
import mysql from "mysql2/promise";

const db = drizzle(process.env.DATABASE_URL);

async function seed() {
  console.log("Starting database seed...");

  // Add categories
  const categoryData = [
    { name: "مسكنات الألم", description: "أدوية لتسكين الألم" },
    { name: "أدوية البرد والإنفلونزا", description: "أدوية لعلاج البرد والإنفلونزا" },
    { name: "أدوية الجهاز الهضمي", description: "أدوية لعلاج مشاكل الجهاز الهضمي" },
    { name: "أدوية القلب والأوعية", description: "أدوية لصحة القلب والأوعية الدموية" },
    { name: "فيتامينات ومكملات", description: "فيتامينات ومكملات غذائية" },
    { name: "أدوية الجلد", description: "أدوية لعلاج مشاكل الجلد" },
  ];

  for (const cat of categoryData) {
    await db.insert(categories).values(cat).catch(() => {});
  }

  console.log("Categories added");

  // Add medicines
  const medicinesData = [
    { name: "باراسيتامول 500mg", categoryId: 1, price: "2.50", activeIngredient: "Paracetamol", manufacturer: "شركة الدواء" },
    { name: "إيبوبروفين 400mg", categoryId: 1, price: "3.00", activeIngredient: "Ibuprofen", manufacturer: "شركة الدواء" },
    { name: "أسبرين 500mg", categoryId: 1, price: "2.00", activeIngredient: "Aspirin", manufacturer: "شركة الدواء" },
    { name: "شراب السعال", categoryId: 2, price: "5.00", activeIngredient: "Dextromethorphan", manufacturer: "شركة الدواء" },
    { name: "أقراص الزكام", categoryId: 2, price: "4.50", activeIngredient: "Pseudoephedrine", manufacturer: "شركة الدواء" },
    { name: "مضاد للحموضة", categoryId: 3, price: "3.50", activeIngredient: "Aluminum Hydroxide", manufacturer: "شركة الدواء" },
    { name: "أقراص الإسهال", categoryId: 3, price: "2.75", activeIngredient: "Loperamide", manufacturer: "شركة الدواء" },
    { name: "أدوية القلب", categoryId: 4, price: "8.00", activeIngredient: "Atorvastatin", manufacturer: "شركة الدواء", requiresPrescription: true },
    { name: "فيتامين C", categoryId: 5, price: "4.00", activeIngredient: "Vitamin C", manufacturer: "شركة الدواء" },
    { name: "فيتامين D", categoryId: 5, price: "5.50", activeIngredient: "Vitamin D", manufacturer: "شركة الدواء" },
    { name: "كريم الجلد", categoryId: 6, price: "6.00", activeIngredient: "Hydrocortisone", manufacturer: "شركة الدواء" },
    { name: "مرهم الحروق", categoryId: 6, price: "7.00", activeIngredient: "Silver Sulfadiazine", manufacturer: "شركة الدواء" },
  ];

  for (const med of medicinesData) {
    const result = await db.insert(medicines).values(med).catch(() => null);
    if (result) {
      const medicineId = result.insertId;
      // Add inventory
      await db.insert(inventory).values({
        medicineId,
        quantity: Math.floor(Math.random() * 500) + 100,
        minThreshold: 50,
        maxThreshold: 1000,
      }).catch(() => {});
    }
  }

  console.log("Medicines and inventory added");

  // Add promo codes
  const now = new Date();
  const future = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days from now

  const promoCodesToAdd = [
    {
      code: "WELCOME10",
      discountType: "percentage",
      discountValue: "10",
      validFrom: now,
      validUntil: future,
      isActive: true,
    },
    {
      code: "SUMMER20",
      discountType: "percentage",
      discountValue: "20",
      maxDiscount: "50",
      minOrderAmount: "100",
      validFrom: now,
      validUntil: future,
      isActive: true,
    },
    {
      code: "SAVE5",
      discountType: "fixed",
      discountValue: "5",
      validFrom: now,
      validUntil: future,
      isActive: true,
    },
  ];

  for (const promo of promoCodesToAdd) {
    await db.insert(promoCodes).values(promo).catch(() => {});
  }

  console.log("Promo codes added");
  console.log("Database seeding completed!");
}

seed().catch(console.error).finally(() => process.exit(0));
