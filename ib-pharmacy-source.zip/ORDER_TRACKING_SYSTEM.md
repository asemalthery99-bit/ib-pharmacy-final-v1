# نظام تتبع الطلبات المباشر (Visual Order Tracking System)

## نظرة عامة

تم إضافة نظام متقدم وشامل لتتبع الطلبات في مشروع **صيدلية إب الرقمية (v3.0)**. يوفر النظام واجهة رسومية جميلة وسهلة الاستخدام لعرض حالة الطلب في الوقت الفعلي.

---

## 1. المكونات الجديدة

### مكون `OrderTracker`

**الملف:** `client/src/components/OrderTracker.tsx`

يعرض حالة الطلب بشكل مرئي مع:
- شريط تقدم بصري (Progress Bar)
- أيقونات ملونة لكل مرحلة
- معلومات الطلب الكاملة
- رسائل تقدير عند الاكتمال

#### الخصائص (Props)

```typescript
interface OrderTrackerProps {
  order: OrderStatus;
  showTimeline?: boolean;
}

interface OrderStatus {
  id: string;
  status: "pending" | "preparing" | "ready" | "completed" | "cancelled";
  createdAt: Date;
  updatedAt: Date;
  totalPrice: number;
}
```

#### الاستخدام

```jsx
import OrderTracker from "@/components/OrderTracker";

<OrderTracker 
  order={order} 
  showTimeline={true}
/>
```

---

## 2. صفحة الطلبات الجديدة

### صفحة `Orders`

**الملف:** `client/src/pages/Orders.tsx`

**المسار:** `/orders`

#### الميزات

1. **عرض جميع الطلبات**
   - قائمة كاملة بجميع طلبات المستخدم
   - تصميم متجاوب (Responsive)

2. **تصفية الطلبات**
   - جميع الطلبات
   - قيد الانتظار
   - قيد التحضير
   - جاهز للتسليم
   - مكتمل

3. **إحصائيات الطلبات**
   - إجمالي الإنفاق
   - عدد الطلبات
   - متوسط قيمة الطلب

4. **دعم كامل للعربية**
   - جميع النصوص بالعربية
   - دعم RTL
   - خطوط عربية احترافية

---

## 3. مراحل الطلب

### المراحل الأربع

| المرحلة | الرمز | الوصف | اللون |
|--------|------|-------|-------|
| **قيد الانتظار** (Pending) | 🕐 | تم استقبال الطلب | أصفر |
| **قيد التحضير** (Preparing) | 📦 | نحن نجهز طلبك | أزرق |
| **جاهز للتسليم** (Ready) | ✅ | طلبك جاهز | أخضر |
| **تم التسليم** (Completed) | 🚚 | تم تسليم طلبك | أخضر غامق |

### حالات خاصة

- **ملغى** (Cancelled) - عرض رسالة خاصة بالإلغاء

---

## 4. الواجهة الرسومية

### شريط التقدم (Progress Bar)

```
┌─────────────────────────────────────────────┐
│  قيد الانتظار → قيد التحضير → جاهز → مكتمل  │
│  ●─────────────●───────────────○───────────○  │
└─────────────────────────────────────────────┘
```

**الميزات:**
- تحديث تلقائي للشريط حسب حالة الطلب
- ألوان متدرجة جميلة
- أيقونات واضحة لكل مرحلة
- رسائل وصفية تحت كل أيقونة

### بطاقة الطلب (Order Card)

```
┌────────────────────────────────────┐
│ رقم الطلب: #ORD-001    500 ريال   │
│ التاريخ: 18 مارس 2026             │
│                                    │
│ [جاهز للتسليم]                     │
│                                    │
│ ●─────────────●────────────●────○ │
│ قيد الانتظار  قيد التحضير  جاهز  مكتمل│
│                                    │
│ وقت الطلب: 10:30                   │
│ آخر تحديث: 10:45                   │
│                                    │
│ ⏱️ الوقت المتوقع: خلال 24 ساعة    │
└────────────────────────────────────┘
```

---

## 5. البيانات والتكامل

### البيانات الحالية

حالياً، الصفحة تستخدم **بيانات وهمية (Mock Data)** لأغراض التطوير:

```typescript
const mockOrders = [
  {
    id: "ORD-001",
    status: "completed",
    createdAt: new Date(...),
    updatedAt: new Date(...),
    totalPrice: 450,
    items: [...]
  },
  // ...
];
```

### التكامل مع API

لربط النظام بـ API الحقيقي، قم بـ:

1. **استبدال البيانات الوهمية:**
```typescript
// بدلاً من mockOrders
const { data: orders = [] } = trpc.orders.getUserOrders.useQuery();
```

2. **استخدام tRPC:**
```typescript
const { data: orders } = trpc.orders.getUserOrders.useQuery();
const { data: orderDetails } = trpc.orders.getById.useQuery({ id: orderId });
```

3. **معالجة الأخطاء:**
```typescript
const { data: orders, isLoading, error } = trpc.orders.getUserOrders.useQuery();

if (isLoading) return <LoadingSpinner />;
if (error) return <ErrorMessage error={error} />;
```

---

## 6. التنسيق والألوان

### نظام الألوان

```css
/* المراحل */
--pending-color: #EAB308;    /* أصفر */
--preparing-color: #3B82F6;  /* أزرق */
--ready-color: #10B981;      /* أخضر */
--completed-color: #059669;  /* أخضر غامق */

/* الحالات */
--cancelled-color: #EF4444;  /* أحمر */
```

### الخطوط

```css
/* العناوين */
.text-arabic-bold {
  font-family: 'Cairo', 'Tajawal', sans-serif;
  font-weight: 700;
}

/* النصوص العادية */
.text-arabic {
  font-family: 'Cairo', 'Tajawal', sans-serif;
  font-weight: 500;
}
```

---

## 7. الرسائل والإشعارات

### رسائل النجاح

عند اكتمال الطلب:
```
✓ شكراً لك! تم تسليم طلبك بنجاح
نتمنى أن تكون راضياً عن خدمتنا. 
يمكنك الآن تقييم طلبك أو الاتصال بنا للمساعدة
```

### رسائل التنبيه

للطلبات قيد الانتظار:
```
⏱️ الوقت المتوقع للتسليم: خلال 24 ساعة
سيتم إخطارك بتحديثات الطلب عبر البريد الإلكتروني والإشعارات
```

### رسائل الخطأ

للطلبات الملغاة:
```
تم إلغاء الطلب
```

---

## 8. الميزات المتقدمة

### 1. تصفية الطلبات

```jsx
<Tabs value={selectedStatus} onValueChange={setSelectedStatus}>
  <TabsTrigger value="all">جميع الطلبات</TabsTrigger>
  <TabsTrigger value="pending">قيد الانتظار</TabsTrigger>
  <TabsTrigger value="preparing">قيد التحضير</TabsTrigger>
  <TabsTrigger value="ready">جاهز</TabsTrigger>
  <TabsTrigger value="completed">مكتمل</TabsTrigger>
</Tabs>
```

### 2. الإحصائيات

```jsx
<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
  <Card>إجمالي الإنفاق</Card>
  <Card>عدد الطلبات</Card>
  <Card>متوسط قيمة الطلب</Card>
</div>
```

### 3. التحقق من المصادقة

```jsx
if (!user) {
  return <LoginPrompt />;
}
```

---

## 9. أفضل الممارسات

### عند تطوير ميزات جديدة

1. **استخدم مكون OrderTracker:**
```jsx
<OrderTracker order={order} showTimeline={true} />
```

2. **تطبيق الفئات العربية:**
```jsx
<h2 className="text-arabic-bold">عنوان</h2>
```

3. **معالجة الحالات الخاصة:**
```jsx
if (order.status === "cancelled") {
  return <CancelledOrderMessage />;
}
```

---

## 10. الملفات المضافة والمعدلة

| الملف | النوع | الوصف |
|------|-------|-------|
| `client/src/components/OrderTracker.tsx` | جديد | مكون تتبع الطلبات |
| `client/src/pages/Orders.tsx` | جديد | صفحة الطلبات |
| `client/src/App.tsx` | معدل | إضافة مسار `/orders` |
| `client/src/components/Header.tsx` | معدل | إضافة رابط "طلباتي" |

---

## 11. الخطوات التالية

### قصير الأجل
1. ✅ ربط النظام بـ API الحقيقي
2. ✅ إضافة إشعارات فورية (Real-time Notifications)
3. ✅ تحسين الأداء والتحميل

### متوسط الأجل
1. إضافة خريطة تتبع الموقع (Google Maps)
2. إضافة نظام التقييمات والمراجعات
3. إضافة خيارات الإلغاء والاسترجاع

### طويل الأجل
1. تطبيق الهاتف المحمول
2. نظام الإشعارات المتقدم (SMS, WhatsApp)
3. تقارير متقدمة للمديرين

---

## 12. الموارد والمراجع

- [React Documentation](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [Lucide Icons](https://lucide.dev)
- [Recharts](https://recharts.org)

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.1
**الحالة:** ✅ مكتمل وجاهز للاستخدام
