import crypto from "crypto";

/**
 * Encryption Service
 * Handles encryption and decryption of sensitive patient data
 * Uses AES-256-GCM for secure encryption
 */

class EncryptionService {
  private encryptionKey: Buffer;
  private algorithm: crypto.CipherGCMTypes = "aes-256-gcm";

  constructor() {
    // In production, this should be loaded from environment variables
    const keyString = process.env.ENCRYPTION_KEY || "your-256-bit-encryption-key-here-must-be-32-chars";
    this.encryptionKey = Buffer.from(keyString.padEnd(32, "0").substring(0, 32), "utf-8");
  }

  /**
   * Encrypt sensitive data
   * @param data - Plain text data to encrypt
   * @returns Encrypted data in format: iv:authTag:encryptedData
   */
  encrypt(data: string): string {
    try {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(this.algorithm, this.encryptionKey, iv) as crypto.CipherGCM;

      let encrypted = cipher.update(data, "utf-8", "hex");
      encrypted += cipher.final("hex");

      const authTag = cipher.getAuthTag();

      // Return IV:AuthTag:EncryptedData
      return `${iv.toString("hex")}:${authTag.toString("hex")}:${encrypted}`;
    } catch (error) {
      console.error("[EncryptionService] Encryption failed:", error);
      throw new Error("Failed to encrypt data");
    }
  }

  /**
   * Decrypt sensitive data
   * @param encryptedData - Encrypted data in format: iv:authTag:encryptedData
   * @returns Decrypted plain text
   */
  decrypt(encryptedData: string): string {
    try {
      const parts = encryptedData.split(":");
      if (parts.length !== 3) {
        throw new Error("Invalid encrypted data format");
      }

      const iv = Buffer.from(parts[0], "hex");
      const authTag = Buffer.from(parts[1], "hex");
      const encrypted = parts[2];

      const decipher = crypto.createDecipheriv(this.algorithm, this.encryptionKey, iv) as crypto.DecipherGCM;
      decipher.setAuthTag(authTag);

      let decrypted = decipher.update(encrypted, "hex", "utf-8");
      decrypted += decipher.final("utf-8");

      return decrypted;
    } catch (error) {
      console.error("[EncryptionService] Decryption failed:", error);
      throw new Error("Failed to decrypt data");
    }
  }

  /**
   * Hash sensitive data (one-way)
   * @param data - Data to hash
   * @returns SHA-256 hash
   */
  hash(data: string): string {
    return crypto.createHash("sha256").update(data).digest("hex");
  }

  /**
   * Generate a random token
   * @param length - Token length in bytes
   * @returns Random token in hex format
   */
  generateToken(length: number = 32): string {
    return crypto.randomBytes(length).toString("hex");
  }

  /**
   * Encrypt patient medical data
   * @param patientData - Patient medical information
   * @returns Encrypted patient data
   */
  encryptPatientData(patientData: {
    name?: string;
    email?: string;
    phone?: string;
    medicalHistory?: string;
    allergies?: string;
  }): Record<string, string> {
    const encrypted: Record<string, string> = {};

    if (patientData.name) encrypted.name = this.encrypt(patientData.name);
    if (patientData.email) encrypted.email = this.encrypt(patientData.email);
    if (patientData.phone) encrypted.phone = this.encrypt(patientData.phone);
    if (patientData.medicalHistory) encrypted.medicalHistory = this.encrypt(patientData.medicalHistory);
    if (patientData.allergies) encrypted.allergies = this.encrypt(patientData.allergies);

    return encrypted;
  }

  /**
   * Decrypt patient medical data
   * @param encryptedData - Encrypted patient data
   * @returns Decrypted patient data
   */
  decryptPatientData(encryptedData: Record<string, string>): Record<string, string> {
    const decrypted: Record<string, string> = {};

    for (const [key, value] of Object.entries(encryptedData)) {
      if (value) {
        try {
          decrypted[key] = this.decrypt(value);
        } catch (error) {
          console.error(`[EncryptionService] Failed to decrypt ${key}:`, error);
          decrypted[key] = "";
        }
      }
    }

    return decrypted;
  }

  /**
   * Mask sensitive data for display (e.g., phone numbers)
   * @param data - Data to mask
   * @param visibleChars - Number of characters to show at the end
   * @returns Masked data
   */
  maskData(data: string, visibleChars: number = 4): string {
    if (data.length <= visibleChars) return data;
    const masked = "*".repeat(data.length - visibleChars);
    return masked + data.slice(-visibleChars);
  }
}

export const encryptionService = new EncryptionService();
