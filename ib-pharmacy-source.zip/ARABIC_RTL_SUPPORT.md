# دعم اللغة العربية والاتجاه من اليمين لليسار (RTL)

## نظرة عامة

تم تحديث مشروع **صيدلية إب الرقمية (v3.0)** ليوفر دعماً كاملاً وشاملاً للغة العربية مع دعم الاتجاه من اليمين لليسار (RTL). هذا المستند يوضح جميع التحسينات المطبقة.

---

## 1. تحديثات HTML والرأس (Head)

### ملف `client/index.html`

تم تحديث الملف بالتالي:

```html
<html lang="ar" dir="rtl">
```

**التحسينات:**
- تعيين اللغة إلى العربية (`lang="ar"`)
- تفعيل اتجاه النص من اليمين لليسار (`dir="rtl"`)
- إضافة وصف ميتا بالعربية للمحركات البحثية
- استيراد خطوط عربية احترافية من Google Fonts

### الخطوط المضافة

تم إضافة ثلاث خطوط عربية احترافية:

1. **Cairo** - خط عصري وقابل للقراءة بسهولة
2. **Tajawal** - خط هندسي نظيف وحديث
3. **Poppins** - خط انجليزي احتياطي للمحتوى الإنجليزي

```html
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800&family=Tajawal:wght@300;400;500;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
```

---

## 2. تحديثات CSS (index.css)

### الخطوط والاتجاه

```css
html {
  direction: rtl;
  text-align: right;
}

body {
  font-family: 'Cairo', 'Tajawal', 'Poppins', sans-serif;
}
```

**الفوائد:**
- جميع العناصر ترث الاتجاه RTL تلقائياً
- الخطوط العربية تُستخدم بشكل افتراضي
- تحسين قابلية القراءة للنصوص العربية

### فئات CSS مخصصة للعربية

تم إضافة فئات مساعدة:

```css
.text-arabic {
  font-family: 'Cairo', 'Tajawal', sans-serif;
  font-weight: 500;
  letter-spacing: 0.3px;
}

.text-arabic-bold {
  font-family: 'Cairo', 'Tajawal', sans-serif;
  font-weight: 700;
  letter-spacing: 0.5px;
}

.text-arabic-light {
  font-family: 'Cairo', 'Tajawal', sans-serif;
  font-weight: 300;
  letter-spacing: 0.2px;
}
```

**الاستخدام:**
```jsx
<h1 className="text-arabic-bold">عنوان رئيسي</h1>
<p className="text-arabic">نص عادي</p>
<span className="text-arabic-light">نص خفيف</span>
```

### دعم RTL في الهوامش والحشوات

```css
.ml-auto {
  margin-right: auto;
  margin-left: 0;
}

.mr-auto {
  margin-left: auto;
  margin-right: 0;
}
```

---

## 3. تحديثات المكونات (Components)

### مكون Header

تم تحديث الرأس بالتالي:

- إضافة فئة `text-arabic` لجميع الروابط والأزرار
- تصحيح موضع شارة عدد العناصر في السلة (من `right-1` إلى `left-1`)
- إضافة رابط جديد "طلباتي" للوصول إلى صفحة الطلبات

```jsx
<Link href="/orders" className="text-arabic">
  طلباتي
</Link>
```

---

## 4. صفحات جديدة

### صفحة Orders (الطلبات)

تم إنشاء صفحة جديدة كاملة لتتبع الطلبات مع:

- واجهة رسومية لتتبع حالة الطلب
- دعم كامل للغة العربية
- تصميم متجاوب (Responsive)
- إحصائيات الطلبات

**المسار:** `/orders`

---

## 5. مكون OrderTracker (تتبع الطلبات)

### الميزات

تم إنشاء مكون متقدم لعرض حالة الطلب بشكل مرئي:

```jsx
<OrderTracker order={order} showTimeline={true} />
```

**المراحل المدعومة:**
1. **قيد الانتظار** (Pending) - 🕐
2. **قيد التحضير** (Preparing) - 📦
3. **جاهز للتسليم** (Ready) - ✅
4. **تم التسليم** (Completed) - 🚚

**المميزات:**
- شريط تقدم بصري (Progress Bar)
- ألوان مختلفة لكل مرحلة
- عرض الوقت والتاريخ
- رسالة تقدير عند اكتمال الطلب
- دعم كامل للعربية

---

## 6. أفضل الممارسات (Best Practices)

### عند إضافة نصوص عربية جديدة

1. استخدم الفئات المخصصة:
```jsx
<h2 className="text-arabic-bold">عنوان</h2>
```

2. تأكد من أن الاتجاه صحيح:
```jsx
<div dir="rtl">محتوى عربي</div>
```

3. للمحتوى الإنجليزي داخل النص العربي:
```jsx
<div>
  هذا نص عربي مع كلمة <span dir="ltr">English</span> فيه
</div>
```

### عند تصميم مكونات جديدة

1. تجنب استخدام `left` و `right` مباشرة:
```css
/* ❌ خطأ */
.icon {
  margin-left: 10px;
}

/* ✅ صحيح */
.icon {
  margin-inline-start: 10px;
}
```

2. استخدم `margin-inline` و `padding-inline`:
```css
.card {
  padding-inline: 20px;
  margin-inline: auto;
}
```

---

## 7. اختبار RTL

### خطوات الاختبار

1. فتح المتصفح وتفعيل أدوات المطور (F12)
2. في Console، قم بتنفيذ:
```javascript
document.documentElement.dir = 'rtl';
document.documentElement.lang = 'ar';
```

3. تحقق من:
   - اتجاه النصوص
   - موضع الأيقونات والأزرار
   - محاذاة الصور
   - الهوامش والحشوات

---

## 8. الملفات المعدلة

| الملف | التعديلات |
|------|----------|
| `client/index.html` | إضافة lang="ar" و dir="rtl"، استيراد خطوط عربية |
| `client/src/index.css` | تحديث الخطوط، إضافة فئات عربية، دعم RTL |
| `client/src/components/Header.tsx` | إضافة رابط طلباتي، تطبيق فئات عربية |
| `client/src/pages/Orders.tsx` | صفحة جديدة لتتبع الطلبات |
| `client/src/components/OrderTracker.tsx` | مكون جديد لعرض حالة الطلب |
| `client/src/App.tsx` | إضافة مسار `/orders` |

---

## 9. الخطوات التالية المقترحة

1. **اختبار شامل** - اختبر جميع الصفحات والمكونات بالعربية
2. **تحسينات الأداء** - تحسين تحميل الخطوط العربية
3. **دعم لغات إضافية** - إضافة دعم للإنجليزية والعبرية إذا لزم الأمر
4. **توطين كامل** - ترجمة جميع الرسائل والتنبيهات

---

## 10. الموارد المفيدة

- [Google Fonts Arabic](https://fonts.google.com/?subset=arabic)
- [MDN: CSS Logical Properties](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Logical_Properties)
- [W3C: Structural Markup and Right-to-Left Text](https://www.w3.org/International/questions/qa-html-dir)

---

**آخر تحديث:** 18 مارس 2026
**الإصدار:** 3.1
**الحالة:** ✅ مكتمل وجاهز للاستخدام
