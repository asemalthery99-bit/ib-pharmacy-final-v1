import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Spinner } from "@/components/ui/spinner";
import { Star, ShoppingCart, AlertCircle, Pill, Factory, Droplet } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function MedicineDetail() {
  const { id } = useParams<{ id: string }>();
  const medicineId = parseInt(id || "0", 10);
  const { user } = useAuth();
  const [quantity, setQuantity] = useState(1);

  // Fetch medicine details
  const { data: medicine, isLoading: medicineLoading } = trpc.medicines.getById.useQuery(
    { id: medicineId },
    { enabled: medicineId > 0 }
  );

  // Fetch medicine ratings
  const { data: ratings = [] } = trpc.ratings.getMedicineRatings.useQuery(
    { medicineId },
    { enabled: medicineId > 0 }
  );

  // Get cart mutation
  const { mutate: updateCart } = trpc.cart.updateCart.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة الدواء إلى السلة");
      setQuantity(1);
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ");
    },
  });

  // Get current cart
  const { data: currentCart } = trpc.cart.getCart.useQuery();

  const handleAddToCart = () => {
    if (!user) {
      toast.error("يرجى تسجيل الدخول أولاً");
      return;
    }

    if (!medicine) return;

    const cartItems = (currentCart?.items as any[]) || [];
    const existingItem = cartItems.find((item: any) => item.medicineId === medicineId);

    const updatedItems = existingItem
      ? cartItems.map((item: any) =>
          item.medicineId === medicineId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      : [...cartItems, { medicineId, quantity }];

    updateCart({ items: updatedItems });
  };

  const averageRating = ratings.length > 0
    ? (ratings.reduce((sum, r) => sum + r.score, 0) / ratings.length).toFixed(1)
    : 0;

  if (medicineLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  if (!medicine) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <p className="text-lg font-semibold">الدواء غير موجود</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="mb-6 text-sm text-gray-600">
          <a href="/catalog" className="hover:text-emerald-600">الكتالوج</a>
          <span className="mx-2">/</span>
          <span>{medicine.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Medicine Image and Basic Info */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-20">
              {medicine.imageUrl && (
                <img
                  src={medicine.imageUrl}
                  alt={medicine.name}
                  className="w-full h-64 object-cover rounded-lg mb-4"
                />
              )}
              <div className="space-y-4">
                {medicine.requiresPrescription && (
                  <Badge variant="destructive" className="w-full justify-center">
                    يتطلب وصفة طبية
                  </Badge>
                )}
                <div>
                  <p className="text-sm text-gray-600 mb-1">السعر</p>
                  <p className="text-3xl font-bold text-emerald-600">
                    {medicine.price} ريال
                  </p>
                </div>

                {/* Quantity Selector */}
                <div>
                  <label className="block text-sm font-medium mb-2">الكمية</label>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 border border-gray-300 rounded hover:bg-gray-100"
                    >
                      −
                    </button>
                    <input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded text-center"
                      min="1"
                    />
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 border border-gray-300 rounded hover:bg-gray-100"
                    >
                      +
                    </button>
                  </div>
                </div>

                <Button
                  onClick={handleAddToCart}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  إضافة إلى السلة
                </Button>
              </div>
            </Card>
          </div>

          {/* Medicine Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Title and Rating */}
            <Card className="p-6">
              <h1 className="text-3xl font-bold mb-4">{medicine.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.round(Number(averageRating))
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg font-semibold">{averageRating}</span>
                <span className="text-gray-600">({ratings.length} تقييم)</span>
              </div>
              <p className="text-gray-700">{medicine.description}</p>
            </Card>

            {/* Medicine Information */}
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">معلومات الدواء</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {medicine.activeIngredient && (
                  <div className="flex items-start gap-3">
                    <Droplet className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-600">المادة الفعالة</p>
                      <p className="font-semibold">{medicine.activeIngredient}</p>
                    </div>
                  </div>
                )}
                {medicine.manufacturer && (
                  <div className="flex items-start gap-3">
                    <Factory className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-600">الشركة المصنعة</p>
                      <p className="font-semibold">{medicine.manufacturer}</p>
                    </div>
                  </div>
                )}
                {medicine.expiryDate && (
                  <div className="flex items-start gap-3">
                    <Pill className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-600">تاريخ الانتهاء</p>
                      <p className="font-semibold">
                        {new Date(medicine.expiryDate).toLocaleDateString("ar-SA")}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </Card>

            {/* Ratings Section */}
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">التقييمات ({ratings.length})</h2>
              {ratings.length > 0 ? (
                <div className="space-y-4">
                  {ratings.map((rating) => (
                    <div key={rating.id} className="border-b pb-4 last:border-b-0">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < rating.score
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-600">
                          {new Date(rating.createdAt).toLocaleDateString("ar-SA")}
                        </span>
                      </div>
                      {rating.comment && (
                        <p className="text-gray-700">{rating.comment}</p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600 text-center py-8">لا توجد تقييمات حتى الآن</p>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
