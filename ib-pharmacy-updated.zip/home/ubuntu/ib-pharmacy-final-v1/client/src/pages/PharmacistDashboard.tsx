import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, CheckCircle, Clock, Truck, Star } from "lucide-react";
import { toast } from "sonner";

export default function PharmacistDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("pending");

  // Check if user is pharmacist or admin
  if (user?.role !== "pharmacist" && user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <p className="text-lg font-semibold">ليس لديك صلاحيات كافية</p>
        </Card>
      </div>
    );
  }

  // Fetch orders
  const { data: orders = [] } = trpc.orders.getUserOrders.useQuery();

  // Update order status
  const { mutate: updateOrderStatus } = trpc.orders.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث حالة الطلب");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ");
    },
  });

  const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
    pending: { label: "قيد الانتظار", color: "bg-yellow-100 text-yellow-800", icon: Clock },
    confirmed: { label: "مؤكد", color: "bg-blue-100 text-blue-800", icon: CheckCircle },
    preparing: { label: "قيد التحضير", color: "bg-purple-100 text-purple-800", icon: Clock },
    ready: { label: "جاهز", color: "bg-green-100 text-green-800", icon: CheckCircle },
    shipped: { label: "تم الشحن", color: "bg-indigo-100 text-indigo-800", icon: Truck },
    delivered: { label: "تم التسليم", color: "bg-emerald-100 text-emerald-800", icon: CheckCircle },
    cancelled: { label: "ملغى", color: "bg-red-100 text-red-800", icon: AlertCircle },
  };

  const getOrdersByStatus = (status: string) => {
    return orders.filter((order: any) => order.status === status);
  };

  const handleStatusUpdate = (orderId: number, newStatus: string) => {
    updateOrderStatus({
      orderId,
      status: newStatus as any,
    });
  };

  const renderOrderCard = (order: any) => {
    const config = statusConfig[order.status] || statusConfig.pending;
    const Icon = config.icon;

    return (
      <Card key={order.id} className="p-4 border-l-4 border-l-emerald-600">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="font-semibold text-lg">الطلب #{order.id}</p>
            <p className="text-sm text-gray-600">
              {new Date(order.createdAt).toLocaleDateString("ar-SA")}
            </p>
          </div>
          <Badge className={config.color}>
            <Icon className="w-3 h-3 mr-1" />
            {config.label}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
          <div>
            <p className="text-gray-600">المبلغ</p>
            <p className="font-semibold">{order.totalPrice} ريال</p>
          </div>
          <div>
            <p className="text-gray-600">حالة الدفع</p>
            <p className="font-semibold">
              {order.paymentStatus === "paid" ? "مدفوع" : "قيد الانتظار"}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 flex-wrap">
          {order.status === "pending" && (
            <Button
              size="sm"
              onClick={() => handleStatusUpdate(order.id, "confirmed")}
              className="bg-blue-600 hover:bg-blue-700"
            >
              تأكيد الطلب
            </Button>
          )}
          {order.status === "confirmed" && (
            <Button
              size="sm"
              onClick={() => handleStatusUpdate(order.id, "preparing")}
              className="bg-purple-600 hover:bg-purple-700"
            >
              بدء التحضير
            </Button>
          )}
          {order.status === "preparing" && (
            <Button
              size="sm"
              onClick={() => handleStatusUpdate(order.id, "ready")}
              className="bg-green-600 hover:bg-green-700"
            >
              الطلب جاهز
            </Button>
          )}
          {order.status === "ready" && (
            <Button
              size="sm"
              onClick={() => handleStatusUpdate(order.id, "shipped")}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              تم الشحن
            </Button>
          )}
          {order.status !== "delivered" && order.status !== "cancelled" && (
            <Button
              size="sm"
              variant="destructive"
              onClick={() => handleStatusUpdate(order.id, "cancelled")}
            >
              إلغاء الطلب
            </Button>
          )}
        </div>
      </Card>
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">الطلبات المعلقة</p>
                <p className="text-3xl font-bold text-yellow-600">
                  {getOrdersByStatus("pending").length}
                </p>
              </div>
              <Clock className="w-12 h-12 text-yellow-100" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">قيد التحضير</p>
                <p className="text-3xl font-bold text-purple-600">
                  {getOrdersByStatus("preparing").length}
                </p>
              </div>
              <Clock className="w-12 h-12 text-purple-100" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">جاهزة للتسليم</p>
                <p className="text-3xl font-bold text-green-600">
                  {getOrdersByStatus("ready").length}
                </p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-100" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">إجمالي الطلبات</p>
                <p className="text-3xl font-bold text-emerald-600">{orders.length}</p>
              </div>
              <Truck className="w-12 h-12 text-emerald-100" />
            </div>
          </Card>
        </div>

        {/* Orders by Status */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending">
              قيد الانتظار ({getOrdersByStatus("pending").length})
            </TabsTrigger>
            <TabsTrigger value="preparing">
              قيد التحضير ({getOrdersByStatus("preparing").length})
            </TabsTrigger>
            <TabsTrigger value="ready">
              جاهزة ({getOrdersByStatus("ready").length})
            </TabsTrigger>
            <TabsTrigger value="all">الكل</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            <h2 className="text-2xl font-bold">الطلبات المعلقة</h2>
            <div className="space-y-4">
              {getOrdersByStatus("pending").length > 0 ? (
                getOrdersByStatus("pending").map((order: any) => renderOrderCard(order))
              ) : (
                <Card className="p-8 text-center text-gray-600">
                  <p>لا توجد طلبات معلقة</p>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="preparing" className="space-y-4">
            <h2 className="text-2xl font-bold">الطلبات قيد التحضير</h2>
            <div className="space-y-4">
              {getOrdersByStatus("preparing").length > 0 ? (
                getOrdersByStatus("preparing").map((order: any) => renderOrderCard(order))
              ) : (
                <Card className="p-8 text-center text-gray-600">
                  <p>لا توجد طلبات قيد التحضير</p>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="ready" className="space-y-4">
            <h2 className="text-2xl font-bold">الطلبات الجاهزة</h2>
            <div className="space-y-4">
              {getOrdersByStatus("ready").length > 0 ? (
                getOrdersByStatus("ready").map((order: any) => renderOrderCard(order))
              ) : (
                <Card className="p-8 text-center text-gray-600">
                  <p>لا توجد طلبات جاهزة</p>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="all" className="space-y-4">
            <h2 className="text-2xl font-bold">جميع الطلبات</h2>
            <div className="space-y-4">
              {orders.length > 0 ? (
                orders.map((order: any) => renderOrderCard(order))
              ) : (
                <Card className="p-8 text-center text-gray-600">
                  <p>لا توجد طلبات</p>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
