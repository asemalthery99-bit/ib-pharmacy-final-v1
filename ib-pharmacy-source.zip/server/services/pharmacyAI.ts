import { OpenAI } from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Drug interaction database - simplified version
 * In production, this should be connected to a real pharmacological database
 */
const DRUG_INTERACTIONS: Record<string, string[]> = {
  "أسبرين": ["وارفارين", "كلوبيدوجريل", "إيبوبروفين"],
  "وارفارين": ["أسبرين", "إيبوبروفين", "نابروكسين", "ديكلوفيناك"],
  "إيبوبروفين": ["أسبرين", "وارفارين", "نابروكسين"],
  "ديكلوفيناك": ["وارفارين", "أسبرين", "ليثيوم"],
  "ميتفورمين": ["الكحول", "أدوية القلب"],
  "ليثيوم": ["ديكلوفيناك", "مدرات البول", "الملح"],
  "أموكسيسيلين": ["وارفارين", "ميثوتريكسيت"],
  "سيمفاستاتين": ["إريثروميسين", "كيتوكونازول"],
};

/**
 * Dosage guidelines for common medications
 */
const DOSAGE_GUIDELINES: Record<
  string,
  {
    standard: string;
    maxDaily: string;
    warnings: string[];
    sideEffects: string[];
  }
> = {
  "أسبرين": {
    standard: "500 ملغ كل 4-6 ساعات",
    maxDaily: "4000 ملغ",
    warnings: ["تجنب إذا كنت تعاني من قرحة المعدة", "قد يزيد النزيف"],
    sideEffects: ["اضطراب المعدة", "حموضة", "طفح جلدي"],
  },
  "بنادول": {
    standard: "500-1000 ملغ كل 4-6 ساعات",
    maxDaily: "3000-4000 ملغ",
    warnings: ["تجنب الإفراط لتجنب تلف الكبد", "آمن نسبياً للحوامل"],
    sideEffects: ["نادرة", "طفح جلدي في حالات نادرة"],
  },
  "ديكلوفيناك": {
    standard: "50 ملغ كل 8 ساعات",
    maxDaily: "150 ملغ",
    warnings: ["قد يؤثر على الكلى", "تجنب مع أدوية القلب"],
    sideEffects: ["اضطراب المعدة", "دوار", "صداع"],
  },
  "أموكسيسيلين": {
    standard: "500 ملغ كل 8 ساعات",
    maxDaily: "1500 ملغ",
    warnings: ["قد يسبب حساسية", "تجنب مع الحليب"],
    sideEffects: ["حساسية", "اضطراب المعدة", "إسهال"],
  },
};

/**
 * Check for drug interactions between multiple medications
 */
export async function checkDrugInteractions(
  medicines: string[]
): Promise<{
  hasInteractions: boolean;
  interactions: Array<{ drug1: string; drug2: string; severity: string }>;
  warnings: string[];
}> {
  const interactions: Array<{
    drug1: string;
    drug2: string;
    severity: string;
  }> = [];
  const warnings: string[] = [];

  // Check each pair of medicines
  for (let i = 0; i < medicines.length; i++) {
    for (let j = i + 1; j < medicines.length; j++) {
      const drug1 = medicines[i];
      const drug2 = medicines[j];

      // Check if interaction exists
      if (
        DRUG_INTERACTIONS[drug1]?.includes(drug2) ||
        DRUG_INTERACTIONS[drug2]?.includes(drug1)
      ) {
        interactions.push({
          drug1,
          drug2,
          severity: "عالية", // In production, would have different severity levels
        });
        warnings.push(
          `⚠️ تحذير: قد يوجد تعارض بين ${drug1} و ${drug2}. يرجى استشارة الصيدلي.`
        );
      }
    }
  }

  return {
    hasInteractions: interactions.length > 0,
    interactions,
    warnings,
  };
}

/**
 * Analyze dosage and provide recommendations
 */
export async function analyzeDosage(
  medicine: string,
  prescribedDosage: string,
  patientAge?: number,
  patientConditions?: string[]
): Promise<{
  isValid: boolean;
  recommendations: string[];
  warnings: string[];
  sideEffects: string[];
}> {
  const guidelines = DOSAGE_GUIDELINES[medicine];
  const recommendations: string[] = [];
  const warnings: string[] = [];

  if (!guidelines) {
    return {
      isValid: true,
      recommendations: [
        "لا توجد معلومات محددة عن هذا الدواء في قاعدة البيانات",
      ],
      warnings: ["يرجى التحقق من التعليمات مع الصيدلي"],
      sideEffects: [],
    };
  }

  // Add standard dosage recommendation
  recommendations.push(`الجرعة الموصى بها: ${guidelines.standard}`);
  recommendations.push(`الحد الأقصى اليومي: ${guidelines.maxDaily}`);

  // Age-based recommendations
  if (patientAge) {
    if (patientAge < 12) {
      warnings.push("⚠️ قد تحتاج الجرعة إلى تعديل للأطفال");
    } else if (patientAge > 65) {
      warnings.push("⚠️ قد تحتاج الجرعة إلى تخفيض للمسنين");
    }
  }

  // Condition-based warnings
  if (patientConditions) {
    patientConditions.forEach((condition) => {
      if (guidelines.warnings.some((w) => w.includes(condition))) {
        warnings.push(
          `⚠️ تحذير: هذا الدواء قد لا يكون مناسباً للمريض الذي يعاني من ${condition}`
        );
      }
    });
  }

  return {
    isValid: true,
    recommendations,
    warnings: [...warnings, ...guidelines.warnings],
    sideEffects: guidelines.sideEffects,
  };
}

/**
 * Generate pharmaceutical advice using GPT-4o-mini
 */
export async function generatePharmaceuticalAdvice(
  userQuery: string,
  context?: {
    medicines?: string[];
    allergies?: string[];
    conditions?: string[];
  }
): Promise<{
  response: string;
  disclaimer: string;
  recommendations: string[];
}> {
  const systemPrompt = `أنت مساعد صيدلاني ذكي متخصص في تقديم معلومات دوائية موثوقة وآمنة.
  
  تعليمات مهمة:
  1. قدم معلومات دقيقة عن الأدوية والجرعات والآثار الجانبية
  2. أضف تحذيرات طبية واضحة عند الحاجة
  3. اطلب استشارة الصيدلي أو الطبيب في الحالات الخطيرة
  4. كن حذراً من التفاعلات الدوائية
  5. قدم النصائح بطريقة سهلة الفهم بالعربية
  6. لا تقدم تشخيصاً طبياً، بل معلومات عامة فقط
  
  الأدوية المتاحة: ${context?.medicines?.join(", ") || "متعددة"}
  الحساسيات المعروفة: ${context?.allergies?.join(", ") || "لا توجد"}
  الحالات الطبية: ${context?.conditions?.join(", ") || "لا توجد"}`;

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      max_tokens: 1024,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userQuery },
      ],
    });

    const responseText = response.choices[0].message.content || "";

    return {
      response: responseText,
      disclaimer:
        "⚠️ تنبيه: هذه المعلومات لأغراض تعليمية فقط وليست بديلاً عن استشارة الطبيب أو الصيدلي المختص.",
      recommendations: [
        "استشر الصيدلي قبل تناول أي دواء جديد",
        "اتبع التعليمات المرفقة مع الدواء",
        "أخبر الصيدلي عن جميع الأدوية التي تتناولها",
      ],
    };
  } catch (error) {
    console.error("Error calling GPT-4o-mini:", error);
    throw new Error("فشل في توليد الاستشارة الدوائية");
  }
}

/**
 * Analyze prescription for potential issues
 */
export async function analyzePrescription(
  medicines: Array<{ name: string; dosage: string; frequency: string }>,
  patientHistory?: {
    age?: number;
    allergies?: string[];
    conditions?: string[];
    currentMedicines?: string[];
  }
): Promise<{
  isValid: boolean;
  issues: string[];
  warnings: string[];
  recommendations: string[];
}> {
  const issues: string[] = [];
  const warnings: string[] = [];
  const recommendations: string[] = [];

  // Check for interactions with current medicines
  if (patientHistory?.currentMedicines) {
    const allMedicines = [
      ...medicines.map((m) => m.name),
      ...patientHistory.currentMedicines,
    ];
    const interactionResult = await checkDrugInteractions(allMedicines);

    if (interactionResult.hasInteractions) {
      issues.push(...interactionResult.warnings);
    }
  }

  // Check each medicine in the prescription
  for (const medicine of medicines) {
    const dosageResult = await analyzeDosage(
      medicine.name,
      medicine.dosage,
      patientHistory?.age,
      patientHistory?.conditions
    );

    warnings.push(...dosageResult.warnings);
    recommendations.push(...dosageResult.recommendations);

    // Check for allergies
    if (patientHistory?.allergies?.includes(medicine.name)) {
      issues.push(`❌ خطر: المريض لديه حساسية من ${medicine.name}`);
    }
  }

  return {
    isValid: issues.length === 0,
    issues,
    warnings,
    recommendations,
  };
}

/**
 * Get alternative medicines for a given drug
 */
export function getAlternativeMedicines(
  medicine: string,
  availableMedicines: string[]
): string[] {
  // In production, this would use a real pharmaceutical database
  const alternatives: Record<string, string[]> = {
    "أسبرين": ["بنادول", "إيبوبروفين"],
    "بنادول": ["أسبرين", "ديكلوفيناك"],
    "إيبوبروفين": ["بنادول", "ديكلوفيناك"],
    "ديكلوفيناك": ["بنادول", "إيبوبروفين"],
    "أموكسيسيلين": ["أزيثروميسين", "سيفالكسين"],
  };

  const medicineAlternatives = alternatives[medicine] || [];
  return medicineAlternatives.filter((alt) =>
    availableMedicines.includes(alt)
  );
}
