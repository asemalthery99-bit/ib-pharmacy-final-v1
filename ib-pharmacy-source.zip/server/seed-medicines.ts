/**
 * Data Seeding Script for Medicines
 * استيراد بيانات الأدوية من ملف CSV إلى قاعدة البيانات
 */

import { db } from './db';
import { medicines } from '../drizzle/schema';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface MedicineData {
  medicineName: string;
  arabicName: string;
  description: string;
  arabicDescription: string;
  category: string;
  price: string;
  dosage: string;
  sideEffects: string;
  imageUrl: string;
}

/**
 * Parse CSV file and return array of medicine data
 */
function parseCSV(filePath: string): MedicineData[] {
  const fileContent = fs.readFileSync(filePath, 'utf-8');
  const lines = fileContent.split('\n').filter((line) => line.trim() && !line.startsWith('#'));

  if (lines.length === 0) {
    throw new Error('CSV file is empty');
  }

  const headers = lines[0].split(',').map((h) => h.trim());
  const medicinesList: MedicineData[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map((v) => v.trim());

    if (values.length < 5) {
      console.warn(`Skipping row ${i + 1}: insufficient columns`);
      continue;
    }

    const medicine: MedicineData = {
      medicineName: values[0],
      arabicName: values[1],
      category: values[2],
      price: values[3],
      description: values[4],
      arabicDescription: values[5] || "",
      dosage: values[6] || "",
      sideEffects: values[7] || "",
      imageUrl: values[8] || "",
    };

    medicinesList.push(medicine);
  }

  return medicinesList;
}

/**
 * Seed medicines into database
 */
export async function seedMedicines(csvFilePath?: string) {
  try {
    const filePath = csvFilePath || path.join(__dirname, '../medicines_template.csv');

    if (!fs.existsSync(filePath)) {
      console.error(`CSV file not found: ${filePath}`);
      return;
    }

    console.log(`📖 Reading medicines from: ${filePath}`);
    const medicinesList = parseCSV(filePath);

    if (medicinesList.length === 0) {
      console.warn('No medicines to seed');
      return;
    }

    console.log(`📊 Found ${medicinesList.length} medicines to import`);

    let successCount = 0;
    let errorCount = 0;

    for (const medicine of medicinesList) {
      try {
        await db.insert(medicines).values({
          name: medicine.medicineName,
          arabicName: medicine.arabicName,
          category: medicine.category,
          price: medicine.price,
          description: medicine.description,
          arabicDescription: medicine.arabicDescription,
          dosage: medicine.dosage,
          sideEffects: medicine.sideEffects,
          imageUrl: medicine.imageUrl,
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        successCount++;
        console.log(`✅ Imported: ${medicine.medicineName}`);
      } catch (error) {
        errorCount++;
        console.error(`❌ Failed to import ${medicine.medicineName}:`, error);
      }
    }

    console.log(`\n📈 Seeding Summary:`);
    console.log(`   ✅ Success: ${successCount}`);
    console.log(`   ❌ Failed: ${errorCount}`);
    console.log(`   📊 Total: ${medicinesList.length}`);
  } catch (error) {
    console.error('Error seeding medicines:', error);
    throw error;
  }
}

/**
 * Get medicine statistics after seeding
 */
export async function getMedicineStats() {
  try {
    // Note: This requires a properly typed db with schema
    const allMedicines = await (db as any).select().from(medicines);

    const stats = {
      totalMedicines: allMedicines.length,
      totalValue: allMedicines.reduce((sum: number, m: any) => sum + (parseFloat(m.price) || 0), 0),
      averagePrice: allMedicines.length > 0
        ? allMedicines.reduce((sum: number, m: any) => sum + (parseFloat(m.price) || 0), 0) / allMedicines.length
        : 0,
      categories: [...new Set(allMedicines.map((m: any) => m.category))].length,
    };

    return stats;
  } catch (error) {
    console.error('Error getting medicine stats:', error);
    throw error;
  }
}

export default seedMedicines;
