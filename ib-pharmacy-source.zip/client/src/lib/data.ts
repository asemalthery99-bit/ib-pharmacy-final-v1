export interface Medicine {
  id: string;
  name: string;
  arabicName: string;
  category: string;
  price: number;
  description: string;
  arabicDescription: string;
  image: string;
  dosage: string;
  sideEffects: string;
  arabicSideEffects: string;
  usage: string;
  arabicUsage: string;
}

export const categories = [
  { id: "all", name: "الكل" },
  { id: "pain-relief", name: "مسكنات الألم" },
  { id: "antibiotics", name: "المضادات الحيوية" },
  { id: "vitamins", name: "الفيتامينات" },
  { id: "chronic-diseases", name: "الأمراض المزمنة" },
  { id: "skincare", name: "العناية بالبشرة" },
  { id: "first-aid", name: "الإسعافات الأولية" },
];

export const medicines: Medicine[] = [
  {
    id: "1",
    name: "Panadol Advance",
    arabicName: "بنادول أدفانس",
    category: "pain-relief",
    price: 1500,
    description: "Effective pain relief for headaches, toothaches, and fever.",
    arabicDescription: "مسكن فعال للآلام للصداع وآلام الأسنان والحمى.",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?q=80&w=800&auto=format&fit=crop",
    dosage: "500mg - 1000mg every 4-6 hours",
    sideEffects: "Rare: Nausea, allergic reactions.",
    arabicSideEffects: "نادر: غثيان، ردود فعل تحسسية.",
    usage: "Swallow with water. Do not exceed 8 tablets in 24 hours.",
    arabicUsage: "يبلع مع الماء. لا تتجاوز 8 أقراص في 24 ساعة.",
  },
  {
    id: "2",
    name: "Amoxicillin",
    arabicName: "أموكسيسيلين",
    category: "antibiotics",
    price: 3500,
    description: "Broad-spectrum antibiotic used to treat bacterial infections.",
    arabicDescription: "مضاد حيوي واسع الطيف يستخدم لعلاج العدوى البكتيرية.",
    image: "https://images.unsplash.com/photo-1471864190281-ad5f9f33d70e?q=80&w=800&auto=format&fit=crop",
    dosage: "500mg three times daily",
    sideEffects: "Diarrhea, nausea, skin rash.",
    arabicSideEffects: "إسهال، غثيان، طفح جلدي.",
    usage: "Finish the entire course as prescribed by your doctor.",
    arabicUsage: "أكمل الجرعة كاملة كما وصفها الطبيب.",
  },
  {
    id: "3",
    name: "Vitamin C 1000mg",
    arabicName: "فيتامين سي 1000 ملجم",
    category: "vitamins",
    price: 2000,
    description: "Supports immune system health and provides antioxidant protection.",
    arabicDescription: "يدعم صحة جهاز المناعة ويوفر حماية مضادة للأكسدة.",
    image: "https://images.unsplash.com/photo-1616671285410-0950be03714c?q=80&w=800&auto=format&fit=crop",
    dosage: "One tablet daily",
    sideEffects: "Stomach upset if taken in large doses.",
    arabicSideEffects: "اضطراب المعدة إذا تم تناوله بجرعات كبيرة.",
    usage: "Dissolve in a glass of water and drink.",
    arabicUsage: "يذاب في كوب من الماء ويشرب.",
  },
  {
    id: "4",
    name: "Metformin 500mg",
    arabicName: "ميتفورمين 500 ملجم",
    category: "chronic-diseases",
    price: 1200,
    description: "Used to control high blood sugar in people with type 2 diabetes.",
    arabicDescription: "يستخدم للسيطرة على ارتفاع نسبة السكر في الدم لدى مرضى السكري من النوع الثاني.",
    image: "https://images.unsplash.com/photo-1550572017-edd951b55104?q=80&w=800&auto=format&fit=crop",
    dosage: "500mg twice daily with meals",
    sideEffects: "Digestive issues, metallic taste in mouth.",
    arabicSideEffects: "مشاكل هضمية، طعم معدني في الفم.",
    usage: "Take with food to reduce stomach side effects.",
    arabicUsage: "يؤخذ مع الطعام لتقليل الآثار الجانبية للمعدة.",
  },
  {
    id: "5",
    name: "La Roche-Posay Effaclar",
    arabicName: "لاروش بوزيه إيفاكلار",
    category: "skincare",
    price: 8500,
    description: "Gel cleanser for oily, acne-prone skin.",
    arabicDescription: "جل منظف للبشرة الدهنية والمعرضة لحب الشباب.",
    image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=800&auto=format&fit=crop",
    dosage: "Use twice daily",
    sideEffects: "Dryness if overused.",
    arabicSideEffects: "جفاف في حال الاستخدام المفرط.",
    usage: "Apply to wet face, massage gently, then rinse.",
    arabicUsage: "يوضع على وجه مبلل، يدلك بلطف، ثم يشطف.",
  },
  {
    id: "6",
    name: "Sterile Bandages",
    arabicName: "ضمادات معقمة",
    category: "first-aid",
    price: 500,
    description: "Individually wrapped sterile bandages for minor cuts.",
    arabicDescription: "ضمادات معقمة مغلفة بشكل فردي للجروح البسيطة.",
    image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?q=80&w=800&auto=format&fit=crop",
    dosage: "As needed",
    sideEffects: "Skin irritation from adhesive (rare).",
    arabicSideEffects: "تهيج الجلد من اللاصق (نادر).",
    usage: "Clean the wound before applying the bandage.",
    arabicUsage: "نظف الجرح قبل وضع الضمادة.",
  },
];
