import { useMemo, useState } from "react";
import { Link, useParams, useLocation } from "wouter";
import { ChevronRight, ShoppingCart, Info, AlertCircle, CheckCircle2, Package, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { medicines, categories } from "@/lib/data";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

export default function MedicineDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  
  const medicine = useMemo(() => {
    return medicines.find((m) => m.id === id);
  }, [id]);

  if (!medicine) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <AlertCircle className="w-16 h-16 text-destructive mb-4" />
        <h1 className="text-2xl font-bold mb-2">الدواء غير موجود</h1>
        <p className="text-muted-foreground mb-6">عذراً، لم نتمكن من العثور على الدواء الذي تبحث عنه.</p>
        <Link href="/catalog">
          <Button className="bg-primary hover:bg-primary/90 text-white">العودة للكتالوج</Button>
        </Link>
      </div>
    );
  }

  const categoryName = categories.find(c => c.id === medicine.category)?.name;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8 overflow-x-auto whitespace-nowrap pb-2">
          <Link href="/" className="hover:text-primary transition">الرئيسية</Link>
          <ChevronRight className="w-4 h-4 shrink-0" />
          <Link href="/catalog" className="hover:text-primary transition">كتالوج الأدوية</Link>
          <ChevronRight className="w-4 h-4 shrink-0" />
          <span className="text-foreground font-medium">{medicine.arabicName}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Image Section */}
          <div className="relative group rounded-3xl overflow-hidden border border-border shadow-lg">
            <img
              src={medicine.image}
              alt={medicine.arabicName}
              className="w-full h-full object-cover aspect-square transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <Badge className="bg-primary text-white text-sm px-4 py-1">{categoryName}</Badge>
              <Badge variant="outline" className="bg-white/90 text-accent border-accent text-sm px-4 py-1">متوفر</Badge>
            </div>
          </div>

          {/* Details Section */}
          <div className="flex flex-col gap-8 text-right">
            <div>
              <div className="flex items-center gap-2 mb-2 justify-end">
                <div className="flex items-center text-yellow-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">(4.8/5) من تقييمات العملاء</span>
              </div>
              <h1 className="text-4xl font-bold text-foreground mb-2">{medicine.arabicName}</h1>
              <p className="text-xl text-muted-foreground font-medium mb-4">{medicine.name}</p>
              <div className="flex items-center justify-end gap-4 mb-6">
                <p className="text-3xl font-bold text-primary">{medicine.price.toLocaleString()} ريال</p>
                <div className="h-8 w-[1px] bg-border"></div>
                <p className="text-sm text-muted-foreground">شامل الضريبة</p>
              </div>
              <p className="text-lg text-foreground leading-relaxed bg-muted/30 p-4 rounded-2xl border-r-4 border-primary">
                {medicine.arabicDescription}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-2xl border border-border shadow-sm flex flex-col items-center text-center">
                <Package className="w-8 h-8 text-primary mb-2" />
                <p className="text-sm text-muted-foreground mb-1">الكمية المتوفرة</p>
                <p className="font-bold">أكثر من 50 عبوة</p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-border shadow-sm flex flex-col items-center text-center">
                <CheckCircle2 className="w-8 h-8 text-accent mb-2" />
                <p className="text-sm text-muted-foreground mb-1">سرعة التوصيل</p>
                <p className="font-bold">خلال 30-60 دقيقة</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="flex-[2] h-14 bg-primary hover:bg-primary/90 text-white text-lg font-bold gap-3 rounded-2xl pulse-glow"
                onClick={() => {
                  addToCart(parseInt(medicine.id), quantity);
                  toast.success(`تم إضافة ${medicine.arabicName} إلى السلة`);
                }}
              >
                <ShoppingCart className="w-6 h-6" />
                أضف إلى سلة المشتريات
              </Button>
              <Button variant="outline" className="flex-1 h-14 border-primary text-primary hover:bg-primary/10 text-lg font-bold rounded-2xl">
                طلب سريع
              </Button>
            </div>

            {/* Quantity Selector */}
            <div className="flex items-center justify-end gap-4 bg-muted/30 p-4 rounded-2xl border border-border">
              <span className="text-lg font-semibold text-foreground">الكمية:</span>
              <div className="flex items-center gap-3 bg-white rounded-lg border border-border p-1">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 p-0"
                >
                  -
                </Button>
                <span className="w-8 text-center font-bold">{quantity}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-8 h-8 p-0"
                >
                  +
                </Button>
              </div>
            </div>

            {/* Tabs Content */}
            <div className="space-y-6 mt-4">
              <Card className="border-border overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex border-b border-border bg-muted/30">
                    <button className="px-6 py-3 border-b-2 border-primary text-primary font-bold">معلومات طبية</button>
                    <button className="px-6 py-3 text-muted-foreground hover:text-foreground transition">الآثار الجانبية</button>
                  </div>
                  <div className="p-6 space-y-6">
                    <div>
                      <h3 className="flex items-center gap-2 text-lg font-bold mb-3 justify-end">
                        طريقة الاستخدام
                        <Info className="w-5 h-5 text-primary" />
                      </h3>
                      <p className="text-muted-foreground">{medicine.arabicUsage}</p>
                    </div>
                    <div className="h-[1px] bg-border"></div>
                    <div>
                      <h3 className="flex items-center gap-2 text-lg font-bold mb-3 justify-end">
                        الجرعة الموصى بها
                        <Package className="w-5 h-5 text-primary" />
                      </h3>
                      <p className="text-muted-foreground">{medicine.dosage}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-destructive/5 border border-destructive/20 p-4 rounded-2xl flex items-start gap-3 justify-end">
                <div className="text-right">
                  <p className="text-destructive font-bold mb-1">تحذير طبي</p>
                  <p className="text-sm text-destructive/80">يرجى استشارة الصيدلي أو الطبيب قبل تناول أي دواء جديد.</p>
                </div>
                <AlertCircle className="w-6 h-6 text-destructive shrink-0 mt-1" />
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
