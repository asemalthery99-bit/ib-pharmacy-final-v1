/**
 * Subscription Service
 * Manages recurring orders for chronic disease patients
 */

export interface MedicineSubscription {
  id: string;
  userId: string;
  medicineId: string;
  medicineName: string;
  quantity: number;
  frequency: 'weekly' | 'biweekly' | 'monthly' | 'quarterly';
  startDate: Date;
  endDate?: Date;
  nextDeliveryDate: Date;
  status: 'active' | 'paused' | 'cancelled';
  autoRenew: boolean;
  notes?: string;
  createdAt: Date;
}

export interface ChronicDiseaseProfile {
  userId: string;
  diseases: Array<{
    name: string;
    diagnosisDate: Date;
    medications: string[];
    notes?: string;
  }>;
  allergies: string[];
  doctorName?: string;
  doctorPhone?: string;
  lastCheckup?: Date;
  nextCheckup?: Date;
}

export interface SubscriptionReminder {
  id: string;
  subscriptionId: string;
  userId: string;
  medicineId: string;
  medicineName: string;
  reminderDate: Date;
  reminderType: 'upcoming_delivery' | 'refill_needed' | 'medication_reminder';
  message: string;
  sent: boolean;
  sentAt?: Date;
}

/**
 * Create a new subscription for a patient
 */
export async function createSubscription(
  userId: string,
  medicineId: string,
  medicineName: string,
  quantity: number,
  frequency: 'weekly' | 'biweekly' | 'monthly' | 'quarterly'): Promise<MedicineSubscription> {
  const subscription: MedicineSubscription = {
    id: `SUB-${Date.now()}`,
    userId,
    medicineId,
    medicineName,
    quantity,
    frequency,
    startDate: new Date(),
    nextDeliveryDate: calculateNextDeliveryDate(new Date(), frequency),
    status: 'active',
    autoRenew: true,
    createdAt: new Date(),
  };

  console.log('Subscription created:', subscription);
  return subscription;
}

/**
 * Calculate next delivery date based on frequency
 */
function calculateNextDeliveryDate(
  startDate: Date,
  frequency: string
): Date {
  const nextDate = new Date(startDate);

  switch (frequency) {
    case 'weekly':
      nextDate.setDate(nextDate.getDate() + 7);
      break;
    case 'biweekly':
      nextDate.setDate(nextDate.getDate() + 14);
      break;
    case 'monthly':
      nextDate.setMonth(nextDate.getMonth() + 1);
      break;
    case 'quarterly':
      nextDate.setMonth(nextDate.getMonth() + 3);
      break;
  }

  return nextDate;
}

/**
 * Get all active subscriptions for a user
 */
export async function getUserSubscriptions(
  userId: string
): Promise<MedicineSubscription[]> {
  // Mock data - replace with database query
  const mockSubscriptions: MedicineSubscription[] = [
    {
      id: 'SUB-001',
      userId,
      medicineId: 'MED-001',
      medicineName: 'أنسولين',
      quantity: 1,
      frequency: 'weekly',
      startDate: new Date('2025-01-01'),
      nextDeliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      status: 'active',
      autoRenew: true,
      createdAt: new Date('2025-01-01'),
    },
    {
      id: 'SUB-002',
      userId,
      medicineId: 'MED-002',
      medicineName: 'أدوية الضغط',
      quantity: 1,
      frequency: 'monthly',
      startDate: new Date('2025-02-01'),
      nextDeliveryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      status: 'active',
      autoRenew: true,
      createdAt: new Date('2025-02-01'),
    },
  ];

  return mockSubscriptions;
}

/**
 * Update subscription details
 */
export async function updateSubscription(
  subscriptionId: string,
  updates: Partial<MedicineSubscription>
): Promise<MedicineSubscription | null> {
  // In production, update in database
  const subscription: MedicineSubscription = {
    id: subscriptionId,
    userId: updates.userId || '',
    medicineId: updates.medicineId || '',
    medicineName: updates.medicineName || '',
    quantity: updates.quantity || 0,
    frequency: updates.frequency || 'monthly',
    startDate: updates.startDate || new Date(),
    nextDeliveryDate: updates.nextDeliveryDate || new Date(),
    status: updates.status || 'active',
    autoRenew: updates.autoRenew !== undefined ? updates.autoRenew : true,
    createdAt: updates.createdAt || new Date(),
  };

  console.log('Subscription updated:', subscription);
  return subscription;
}

/**
 * Cancel a subscription
 */
export async function cancelSubscription(
  subscriptionId: string,
  reason?: string
): Promise<boolean> {
  console.log(`Subscription ${subscriptionId} cancelled. Reason: ${reason || 'No reason provided'}`);
  return true;
}

/**
 * Pause a subscription temporarily
 */
export async function pauseSubscription(
  subscriptionId: string,
  pauseUntil: Date
): Promise<boolean> {
  console.log(`Subscription ${subscriptionId} paused until ${pauseUntil}`);
  return true;
}

/**
 * Resume a paused subscription
 */
export async function resumeSubscription(
  subscriptionId: string
): Promise<boolean> {
  console.log(`Subscription ${subscriptionId} resumed`);
  return true;
}

/**
 * Create chronic disease profile
 */
export async function createChronicDiseaseProfile(
  userId: string,
  diseases: Array<{ name: string; diagnosisDate: Date; medications: string[] }>,
  allergies: string[] = []
): Promise<ChronicDiseaseProfile> {
  const profile: ChronicDiseaseProfile = {
    userId,
    diseases,
    allergies,
  };

  console.log('Chronic disease profile created:', profile);
  return profile;
}

/**
 * Get chronic disease profile
 */
export async function getChronicDiseaseProfile(
  userId: string
): Promise<ChronicDiseaseProfile | null> {
  // Mock data
  const mockProfile: ChronicDiseaseProfile = {
    userId,
    diseases: [
      {
        name: 'السكري من النوع الثاني',
        diagnosisDate: new Date('2020-01-15'),
        medications: ['أنسولين', 'ميتفورمين'],
      },
      {
        name: 'ارتفاع ضغط الدم',
        diagnosisDate: new Date('2018-06-20'),
        medications: ['ليسينوبريل', 'أملوديبين'],
      },
    ],
    allergies: ['البنسلين', 'الأسبرين'],
  };

  return mockProfile;
}

/**
 * Get recommended subscriptions based on disease profile
 */
export async function getRecommendedSubscriptions(
  userId: string
): Promise<MedicineSubscription[]> {
  const profile = await getChronicDiseaseProfile(userId);

  if (!profile) return [];

  const recommendedSubscriptions: MedicineSubscription[] = [];

  for (const disease of profile.diseases) {
    for (const medication of disease.medications) {
      recommendedSubscriptions.push({
        id: `SUB-REC-${Date.now()}`,
        userId,
        medicineId: `MED-${medication}`,
        medicineName: medication,
        quantity: 1,
        frequency: 'monthly',
        startDate: new Date(),
        nextDeliveryDate: calculateNextDeliveryDate(new Date(), 'monthly'),
        status: 'active',
        autoRenew: true,
        notes: `موصى به لـ ${disease.name}`,
        createdAt: new Date(),
      });
    }
  }

  return recommendedSubscriptions;
}

/**
 * Create subscription reminders
 */
export async function createSubscriptionReminder(
  subscriptionId: string,
  userId: string,
  medicineId: string,
  medicineName: string,
  reminderDate: Date,
  reminderType: 'upcoming_delivery' | 'refill_needed' | 'medication_reminder'): Promise<SubscriptionReminder> {
  const messages = {
    upcoming_delivery: `تذكير: سيتم توصيل ${medicineName} في ${reminderDate.toLocaleDateString('ar-SA')}`,
    refill_needed: `تنبيه: يجب تجديد ${medicineName} قريباً`,
    medication_reminder: `تذكير: حان وقت تناول ${medicineName}`,
  };

  const reminder: SubscriptionReminder = {
    id: `REM-${Date.now()}`,
    subscriptionId,
    userId,
    medicineId,
    medicineName,
    reminderDate,
    reminderType,
    message: messages[reminderType],
    sent: false,
  };

  console.log('Reminder created:', reminder);
  return reminder;
}

/**
 * Get upcoming deliveries for a user
 */
export async function getUpcomingDeliveries(
  userId: string,
  daysAhead: number = 30
): Promise<MedicineSubscription[]> {
  const subscriptions = await getUserSubscriptions(userId);
  const now = new Date();
  const futureDate = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000);

  return subscriptions.filter(
    (sub) =>
      sub.status === 'active' &&
      sub.nextDeliveryDate >= now &&
      sub.nextDeliveryDate <= futureDate
  );
}

/**
 * Process automatic subscription orders
 */
export async function processAutomaticSubscriptionOrders(): Promise<{
  processed: number;
  failed: number;
  errors: string[];
}> {
  const result = {
    processed: 0,
    failed: 0,
    errors: [] as string[],
  };

  // In production, fetch all active subscriptions with nextDeliveryDate <= today
  const mockSubscriptions: MedicineSubscription[] = [
    {
      id: 'SUB-001',
      userId: 'USER-001',
      medicineId: 'MED-001',
      medicineName: 'أنسولين',
      quantity: 1,
      frequency: 'weekly',
      startDate: new Date('2025-01-01'),
      nextDeliveryDate: new Date(),
      status: 'active',
      autoRenew: true,
      createdAt: new Date('2025-01-01'),
    },
  ];

  for (const subscription of mockSubscriptions) {
    try {
      // Create order
      console.log(`Creating order for subscription ${subscription.id}`);

      // Update next delivery date
      const nextDate = calculateNextDeliveryDate(
        subscription.nextDeliveryDate,
        subscription.frequency
      );
      await updateSubscription(subscription.id, {
        nextDeliveryDate: nextDate,
      });

      result.processed++;
    } catch (error) {
      result.failed++;
      result.errors.push(`Failed to process subscription ${subscription.id}`);
    }
  }

  console.log('Automatic subscription processing completed:', result);
  return result;
}

/**
 * Get subscription statistics
 */
export async function getSubscriptionStats(userId: string): Promise<{
  totalSubscriptions: number;
  activeSubscriptions: number;
  pausedSubscriptions: number;
  totalMonthlySpend: number;
  nextDeliveryDate: Date | null;
}> {
  const subscriptions = await getUserSubscriptions(userId);

  const active = subscriptions.filter((s) => s.status === 'active').length;
  const paused = subscriptions.filter((s) => s.status === 'paused').length;
  const nextDelivery = subscriptions
    .filter((s) => s.status === 'active')
    .sort((a, b) => a.nextDeliveryDate.getTime() - b.nextDeliveryDate.getTime())[0]?.nextDeliveryDate || null;

  // Assume 50 per unit for calculation
  const totalMonthlySpend = subscriptions
    .filter((s) => s.status === 'active')
    .reduce((sum, s) => sum + s.quantity * 50, 0);

  return {
    totalSubscriptions: subscriptions.length,
    activeSubscriptions: active,
    pausedSubscriptions: paused,
    totalMonthlySpend,
    nextDeliveryDate: nextDelivery,
  };
}
