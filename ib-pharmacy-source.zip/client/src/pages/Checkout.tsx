import React, { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface CheckoutPageParams {
  orderId: string;
}

export default function Checkout() {
  const [, params] = useRoute("/checkout/:orderId");
  const orderId = params?.orderId ? parseInt(params.orderId) : null;

  const [isLoading, setIsLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const createPayPalOrderMutation = trpc.payments.createPayPalOrder.useMutation();
  const capturePaymentMutation = trpc.payments.capturePayPalPayment.useMutation();
  const getPaymentStatusQuery = trpc.payments.getOrderPaymentStatus.useQuery(
    { orderId: orderId || 0 },
    { enabled: !!orderId }
  );

  useEffect(() => {
    // Check if returning from PayPal
    const params = new URLSearchParams(window.location.search);
    const paypalOrderId = params.get("token");

    if (paypalOrderId && orderId) {
      handlePayPalReturn(paypalOrderId);
    }
  }, [orderId]);

  const handlePayPalReturn = async (paypalOrderId: string) => {
    setIsLoading(true);
    setPaymentStatus("processing");

    try {
      const result = await capturePaymentMutation.mutateAsync({
        orderId: orderId!,
        paypalOrderId,
      });

      if (result.success) {
        setPaymentStatus("success");
        toast.success("تم استقبال الدفعة بنجاح!");
        setTimeout(() => {
          window.location.href = `/orders/${orderId}`;
        }, 2000);
      } else {
        setPaymentStatus("error");
        setErrorMessage(result.error || "حدث خطأ أثناء معالجة الدفعة");
        toast.error(result.error || "فشل معالجة الدفعة");
      }
    } catch (error) {
      setPaymentStatus("error");
      setErrorMessage(String(error));
      toast.error("خطأ: " + String(error));
    } finally {
      setIsLoading(false);
    }
  };

  const handlePayWithPayPal = async () => {
    if (!orderId) {
      toast.error("رقم الطلب غير صحيح");
      return;
    }

    setIsLoading(true);
    setPaymentStatus("processing");

    try {
      const result = await createPayPalOrderMutation.mutateAsync({
        orderId,
        amount: getPaymentStatusQuery.data?.totalPrice || "0",
        currency: "USD",
      });

      if (result.success && result.approvalUrl) {
        // Redirect to PayPal
        window.location.href = result.approvalUrl;
      } else {
        setPaymentStatus("error");
        setErrorMessage(result.error || "فشل إنشاء الطلب");
        toast.error(result.error || "فشل إنشاء الطلب");
      }
    } catch (error) {
      setPaymentStatus("error");
      setErrorMessage(String(error));
      toast.error("خطأ: " + String(error));
    } finally {
      setIsLoading(false);
    }
  };

  if (!orderId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-xl font-semibold mb-2">خطأ</h2>
          <p className="text-gray-600">رقم الطلب غير صحيح</p>
        </Card>
      </div>
    );
  }

  if (getPaymentStatusQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const orderData = getPaymentStatusQuery.data;

  if (paymentStatus === "success") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
          <h2 className="text-2xl font-semibold mb-2">تم الدفع بنجاح!</h2>
          <p className="text-gray-600 mb-4">جاري إعادة التوجيه إلى صفحة الطلب...</p>
          <Loader2 className="w-6 h-6 mx-auto animate-spin" />
        </Card>
      </div>
    );
  }

  if (paymentStatus === "error") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-semibold mb-2">خطأ في الدفع</h2>
          <p className="text-gray-600 mb-4">{errorMessage}</p>
          <Button onClick={() => window.location.href = `/orders/${orderId}`}>
            العودة إلى الطلب
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-md mx-auto">
        <Card className="p-8">
          <h1 className="text-2xl font-bold mb-6 text-center">الدفع</h1>

          {/* Order Summary */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold mb-3">ملخص الطلب</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>رقم الطلب:</span>
                <span className="font-semibold">#{orderId}</span>
              </div>
              <div className="flex justify-between">
                <span>المبلغ:</span>
                <span className="font-semibold">${orderData?.totalPrice}</span>
              </div>
              <div className="flex justify-between">
                <span>حالة الطلب:</span>
                <span className="font-semibold">{orderData?.orderStatus}</span>
              </div>
              <div className="flex justify-between">
                <span>حالة الدفع:</span>
                <span className="font-semibold text-orange-600">{orderData?.paymentStatus}</span>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="space-y-4">
            <h3 className="font-semibold">طرق الدفع</h3>

            {/* PayPal Button */}
            <Button
              onClick={handlePayWithPayPal}
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white h-12 text-lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  جاري المعالجة...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9.5 2C5.36 2 2 5.36 2 9.5S5.36 17 9.5 17h5v-2h-5c-2.76 0-5-2.24-5-5s2.24-5 5-5h5V2h-5zm5 0v2h5c2.76 0 5 2.24 5 5s-2.24 5-5 5h-5v2h5c4.14 0 7.5-3.36 7.5-7.5S18.64 2 14.5 2h-5z" />
                  </svg>
                  الدفع عبر PayPal
                </>
              )}
            </Button>

            <p className="text-xs text-gray-500 text-center">
              سيتم تحويلك إلى PayPal لإتمام عملية الدفع بأمان
            </p>
          </div>

          {/* Security Info */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg text-sm text-blue-700">
            <p className="font-semibold mb-2">🔒 معلومات الأمان</p>
            <p>جميع معاملات الدفع محمية بتشفير SSL آمن. لن نحتفظ ببيانات بطاقتك.</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
