import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";
import { TRPCError } from "@trpc/server";

/**
 * Pharmacist Dashboard Router
 * Provides endpoints for pharmacist to manage orders, prescriptions, and inventory
 */
export const pharmacistRouter = router({
  // ============ DASHBOARD STATS ============
  getDashboardStats: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can access dashboard" });
    }

    try {
      const allOrders = await db.getUserOrders(ctx.user.id);
      const pendingOrders = allOrders.filter(o => o.status === "pending");
      const preparingOrders = allOrders.filter(o => o.status === "preparing");
      const completedOrders = allOrders.filter(o => o.status === "completed");
      const totalRevenue = completedOrders.reduce((sum, o) => sum + Number(o.totalPrice), 0);

      const lowStockMedicines = await db.getLowStockMedicines(10);
      const allMedicines = await db.getAllMedicines();

      return {
        totalOrders: allOrders.length,
        pendingOrders: pendingOrders.length,
        preparingOrders: preparingOrders.length,
        completedOrders: completedOrders.length,
        totalRevenue: totalRevenue.toFixed(2),
        lowStockCount: lowStockMedicines.length,
        totalMedicines: allMedicines.length,
      };
    } catch (error) {
      console.error("[Pharmacist] Error fetching dashboard stats:", error);
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch stats" });
    }
  }),

  // ============ ORDERS MANAGEMENT ============
  getAllOrders: protectedProcedure
    .input(z.object({
      status: z.enum(["pending", "preparing", "ready", "completed", "cancelled"]).optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can view all orders" });
      }

      try {
        const allOrders = await db.getUserOrders(ctx.user.id);
        let filtered = allOrders;

        if (input.status) {
          filtered = filtered.filter(o => o.status === input.status);
        }

        const paginated = filtered.slice(input.offset, input.offset + input.limit);

        // Enrich with items
        const enriched = await Promise.all(
          paginated.map(async (order) => {
            const items = await db.getOrderItems(order.id);
            return { ...order, items };
          })
        );

        return {
          orders: enriched,
          total: filtered.length,
          limit: input.limit,
          offset: input.offset,
        };
      } catch (error) {
        console.error("[Pharmacist] Error fetching orders:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch orders" });
      }
    }),

  updateOrderStatus: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      status: z.enum(["pending", "preparing", "ready", "completed", "cancelled"]),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can update orders" });
      }

      try {
        const order = await db.getOrderById(input.orderId);
        if (!order) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
        }

        await db.updateOrderStatus(input.orderId, input.status);
        return { success: true, message: `Order status updated to ${input.status}` };
      } catch (error) {
        console.error("[Pharmacist] Error updating order status:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to update order" });
      }
    }),

  // ============ PRESCRIPTIONS MANAGEMENT ============
  getAllPrescriptions: protectedProcedure
    .input(z.object({
      status: z.enum(["pending", "reviewed", "quoted", "completed", "rejected"]).optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can view prescriptions" });
      }

      try {
        const allPrescriptions = await db.getPendingPrescriptions();
        let filtered = allPrescriptions;

        if (input.status) {
          filtered = filtered.filter(p => p.status === input.status);
        }

        const paginated = filtered.slice(input.offset, input.offset + input.limit);

        // Enrich with images
        const enriched = await Promise.all(
          paginated.map(async (prescription) => {
            const images = await db.getPrescriptionImages(prescription.id);
            return { ...prescription, images };
          })
        );

        return {
          prescriptions: enriched,
          total: filtered.length,
          limit: input.limit,
          offset: input.offset,
        };
      } catch (error) {
        console.error("[Pharmacist] Error fetching prescriptions:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch prescriptions" });
      }
    }),

  reviewPrescription: protectedProcedure
    .input(z.object({
      prescriptionId: z.number(),
      status: z.enum(["reviewed", "quoted", "rejected"]),
      pharmacistNotes: z.string().optional(),
      quotedPrice: z.number().optional(),
      quotedMedicines: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can review prescriptions" });
      }

      try {
        const prescription = await db.getPrescriptionById(input.prescriptionId);
        if (!prescription) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Prescription not found" });
        }

        const updateData: any = {
          status: input.status,
          pharmacistNotes: input.pharmacistNotes,
        };

        if (input.quotedPrice !== undefined) {
          updateData.quotedPrice = input.quotedPrice.toString();
        }

        if (input.quotedMedicines) {
          updateData.quotedMedicines = JSON.stringify(input.quotedMedicines);
        }

        await db.updatePrescriptionStatus(input.prescriptionId, input.status, updateData);
        return { success: true, message: `Prescription ${input.status}` };
      } catch (error) {
        console.error("[Pharmacist] Error reviewing prescription:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to review prescription" });
      }
    }),

  // ============ INVENTORY MANAGEMENT ============
  getInventoryStatus: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can view inventory" });
    }

    try {
      const lowStock = await db.getLowStockMedicines(10);
      const allMedicines = await db.getAllMedicines();

      const inventoryStatus = await Promise.all(
        allMedicines.map(async (medicine) => {
          const inv = await db.getInventoryByMedicineId(medicine.id);
          return {
            medicineId: medicine.id,
            medicineName: medicine.name,
            arabicName: medicine.arabicName,
            quantity: inv?.quantity || 0,
            minThreshold: inv?.minThreshold || 10,
            maxThreshold: inv?.maxThreshold || 1000,
            status: inv && inv.quantity <= (inv.minThreshold || 10) ? "low" : "ok",
          };
        })
      );

      return {
        inventory: inventoryStatus,
        lowStockCount: lowStock.length,
      };
    } catch (error) {
      console.error("[Pharmacist] Error fetching inventory:", error);
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch inventory" });
    }
  }),

  updateInventoryQuantity: protectedProcedure
    .input(z.object({
      medicineId: z.number(),
      quantity: z.number().min(0),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can update inventory" });
      }

      try {
        const medicine = await db.getMedicineById(input.medicineId);
        if (!medicine) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Medicine not found" });
        }

        await db.updateInventoryQuantity(input.medicineId, input.quantity);
        return { success: true, message: `Inventory updated for ${medicine.name}` };
      } catch (error) {
        console.error("[Pharmacist] Error updating inventory:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to update inventory" });
      }
    }),

  // ============ SALES ANALYTICS ============
  getSalesAnalytics: protectedProcedure
    .input(z.object({
      days: z.number().default(30),
    }))
    .query(async ({ input, ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only pharmacists can view analytics" });
      }

      try {
        const allOrders = await db.getUserOrders(ctx.user.id);
        const completedOrders = allOrders.filter(o => o.status === "completed");

        const totalRevenue = completedOrders.reduce((sum, o) => sum + Number(o.totalPrice), 0);
        const averageOrderValue = completedOrders.length > 0 ? totalRevenue / completedOrders.length : 0;

        return {
          totalRevenue: totalRevenue.toFixed(2),
          totalOrders: completedOrders.length,
          averageOrderValue: averageOrderValue.toFixed(2),
          topMedicines: [], // Can be enhanced with actual medicine sales data
        };
      } catch (error) {
        console.error("[Pharmacist] Error fetching analytics:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to fetch analytics" });
      }
    }),
});
