import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { storagePut } from "./storage";
import { invokeLLM } from "./_core/llm";
import { TRPCError } from "@trpc/server";
import { notifyNewOrder, notifyNewPrescription, notifyLowInventory } from "./services/notifications";

import { notificationsRouter } from "./routers/notifications";
import { paymentsRouter } from "./routers/payments";
import { pharmacistRouter } from "./routers/pharmacist";
import { ratingsRouter } from "./routers/ratings";
import { loyaltyRouter } from "./routers/loyalty";

export const appRouter = router({
  system: systemRouter,
  notifications: notificationsRouter,
  payments: paymentsRouter,
  pharmacist: pharmacistRouter,
  ratings: ratingsRouter,
  loyalty: loyaltyRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ MEDICINES ROUTER ============
  medicines: router({
    list: publicProcedure.query(async () => {
      return db.getAllMedicines();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const medicine = await db.getMedicineById(input.id);
        if (!medicine) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Medicine not found" });
        }
        return medicine;
      }),

    getByIds: publicProcedure
      .input(z.object({ ids: z.array(z.number()) }))
      .query(async ({ input }) => {
        if (input.ids.length === 0) return [];
        return db.getMedicinesByIds(input.ids);
      }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return db.getMedicinesByCategory(input.category);
      }),

    search: publicProcedure
      .input(z.object({
        query: z.string(),
        category: z.string().optional(),
        minPrice: z.number().optional(),
        maxPrice: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return db.searchMedicines(input.query, input.category, input.minPrice, input.maxPrice);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        arabicName: z.string(),
        category: z.string(),
        price: z.number(),
        description: z.string().optional(),
        arabicDescription: z.string().optional(),
        dosage: z.string().optional(),
        sideEffects: z.string().optional(),
        arabicSideEffects: z.string().optional(),
        usage: z.string().optional(),
        arabicUsage: z.string().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can create medicines" });
        }
        const result = await db.createMedicine({
          ...input,
          price: input.price.toString(),
        });
        return result;
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          arabicName: z.string().optional(),
          category: z.string().optional(),
          price: z.number().optional(),
          description: z.string().optional(),
          arabicDescription: z.string().optional(),
          dosage: z.string().optional(),
          sideEffects: z.string().optional(),
          arabicSideEffects: z.string().optional(),
          usage: z.string().optional(),
          arabicUsage: z.string().optional(),
          imageUrl: z.string().optional(),
        }),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update medicines" });
        }
        const updateData: Record<string, any> = {};
        for (const [key, value] of Object.entries(input.data)) {
          if (value !== undefined) {
            if (key === "price" && typeof value === "number") {
              updateData[key] = value.toString();
            } else {
              updateData[key] = value;
            }
          }
        }
        return db.updateMedicine(input.id, updateData);
      }),
  }),

  // ============ INVENTORY ROUTER ============
  inventory: router({
    getByMedicineId: publicProcedure
      .input(z.object({ medicineId: z.number() }))
      .query(async ({ input }) => {
        return db.getInventoryByMedicineId(input.medicineId);
      }),

    getLowStock: publicProcedure
      .input(z.object({ threshold: z.number().optional() }))
      .query(async ({ input }) => {
        return db.getLowStockMedicines(input.threshold);
      }),

    updateQuantity: protectedProcedure
      .input(z.object({ medicineId: z.number(), quantity: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update inventory" });
        }
        return db.updateInventoryQuantity(input.medicineId, input.quantity);
      }),
  }),

  // ============ CART ROUTER ============
  cart: router({
    getCart: protectedProcedure.query(async ({ ctx }) => {
      const cartItems = await db.getUserCart(ctx.user.id);
      // Enrich with medicine details
      const enriched = await Promise.all(
        cartItems.map(async (item) => {
          const medicine = await db.getMedicineById(item.medicineId);
          return { ...item, medicine };
        })
      );
      return enriched;
    }),

    addItem: protectedProcedure
      .input(z.object({ medicineId: z.number(), quantity: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return db.addToCart(ctx.user.id, input.medicineId, input.quantity);
      }),

    updateItem: protectedProcedure
      .input(z.object({ medicineId: z.number(), quantity: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return db.updateCartItemQuantity(ctx.user.id, input.medicineId, input.quantity);
      }),

    removeItem: protectedProcedure
      .input(z.object({ medicineId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return db.removeFromCart(ctx.user.id, input.medicineId);
      }),

    clear: protectedProcedure.mutation(async ({ ctx }) => {
      return db.clearUserCart(ctx.user.id);
    }),
  }),

  // ============ ORDERS ROUTER ============
  orders: router({
    create: protectedProcedure
      .input(z.object({
        items: z.array(z.object({ medicineId: z.number(), quantity: z.number() })),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Calculate total price
        let totalPrice = 0;
        const medicineDetails: any[] = [];
        for (const item of input.items) {
          const medicine = await db.getMedicineById(item.medicineId);
          if (!medicine) throw new TRPCError({ code: "NOT_FOUND", message: "Medicine not found" });
          medicineDetails.push(medicine);
          totalPrice += Number(medicine.price) * item.quantity;
        }

        // Create order
        const orderResult = await db.createOrder({
          userId: ctx.user.id,
          totalPrice: totalPrice.toFixed(2),
          status: "pending",
          paymentStatus: "unpaid",
          notes: input.notes,
        });

        // Get the inserted order ID
        const orderId = (orderResult as any)[0]?.insertId || (orderResult as any).insertId;

        // Create order items
        for (const item of input.items) {
          const medicine = medicineDetails.find(m => m.id === item.medicineId);
          if (medicine) {
            const priceStr = typeof medicine.price === "string" ? medicine.price : String(medicine.price);
            await db.createOrderItem({
              orderId,
              medicineId: item.medicineId,
              quantity: item.quantity,
              price: priceStr,
            });
          }
        }

        // Clear cart
        await db.clearUserCart(ctx.user.id);

        // Send notification to owner (pharmacist)
        try {
          await notifyNewOrder(orderId, totalPrice.toFixed(2), input.items.length);
        } catch (error) {
          console.error("[Orders] Failed to send notification:", error);
        }

        return { orderId, totalPrice };
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.id);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
        if (order.userId !== ctx.user.id && ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
        }
        const items = await db.getOrderItems(input.id);
        return { ...order, items };
      }),

    getUserOrders: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserOrders(ctx.user.id);
    }),

    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.string() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update order status" });
        }
        return db.updateOrderStatus(input.id, input.status);
      }),

    updatePaymentStatus: protectedProcedure
      .input(z.object({ id: z.number(), paymentStatus: z.string(), stripePaymentId: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update payment status" });
        }
        return db.updateOrderPaymentStatus(input.id, input.paymentStatus, input.stripePaymentId);
      }),
  }),

  // ============ PRESCRIPTIONS ROUTER ============
  prescriptions: router({
    create: protectedProcedure
      .input(z.object({
        imageUrl: z.string(),
        userNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Create prescription
        const prescriptionResult = await db.createPrescription({
          userId: ctx.user.id,
          status: "pending",
          userNotes: input.userNotes,
        });

        const prescriptionId = (prescriptionResult as any).insertId;

        // Store image in S3
        try {
          const base64Data = input.imageUrl.split(",")[1];
          const buffer = Buffer.from(base64Data, "base64");
          const s3Key = `prescriptions/${ctx.user.id}/${prescriptionId}-${Date.now()}.jpg`;
          const { url } = await storagePut(s3Key, buffer, "image/jpeg");

          // Save image reference
          await db.createPrescriptionImage({
            prescriptionId,
            imageUrl: url,
            s3Key,
          });
        } catch (error) {
          console.error("Error uploading prescription image:", error);
        }

        // Send notification to owner (pharmacist)
        try {
          await notifyNewPrescription(prescriptionId, ctx.user?.name || undefined);
        } catch (error) {
          console.error("[Prescriptions] Failed to send notification:", error);
        }

        return { prescriptionId };
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const prescription = await db.getPrescriptionById(input.id);
        if (!prescription) throw new TRPCError({ code: "NOT_FOUND", message: "Prescription not found" });
        if (prescription.userId !== ctx.user.id && ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
        }
        const images = await db.getPrescriptionImages(input.id);
        return { ...prescription, images };
      }),

    getUserPrescriptions: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserPrescriptions(ctx.user.id);
    }),

    getPending: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can view pending prescriptions" });
      }
      return db.getPendingPrescriptions();
    }),

    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.string(),
        pharmacistNotes: z.string().optional(),
        quotedPrice: z.number().optional(),
        quotedMedicines: z.array(z.string()).optional(),
        extractedMedicines: z.array(z.object({ name: z.string(), dosage: z.string().optional() })).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update prescriptions" });
        }

        const updateData: any = {
          status: input.status,
          pharmacistNotes: input.pharmacistNotes,
        };

        if (input.quotedPrice !== undefined) {
          updateData.quotedPrice = input.quotedPrice.toString();
        }

        if (input.quotedMedicines) {
          updateData.quotedMedicines = JSON.stringify(input.quotedMedicines);
        }

        if (input.extractedMedicines) {
          updateData.extractedMedicines = JSON.stringify(input.extractedMedicines);
        }

        return db.updatePrescriptionStatus(input.id, input.status, updateData);
      }),

    extractFromImage: protectedProcedure
      .input(z.object({ prescriptionId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can extract medicines" });
        }

        const prescription = await db.getPrescriptionById(input.prescriptionId);
        if (!prescription) throw new TRPCError({ code: "NOT_FOUND", message: "Prescription not found" });

        const images = await db.getPrescriptionImages(input.prescriptionId);
        if (images.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "No images found" });

        try {
          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: "You are a medical expert. Extract medicine names and dosages from prescription images. Return a JSON array of objects with 'name' and 'dosage' fields.",
              },
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: "Please extract all medicines from this prescription image:",
                  },
                  {
                    type: "image_url",
                    image_url: {
                      url: images[0].imageUrl,
                    },
                  },
                ],
              },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "medicines_extraction",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    medicines: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          dosage: { type: "string" },
                        },
                        required: ["name"],
                      },
                    },
                  },
                  required: ["medicines"],
                },
              },
            },
          });

          const content = response.choices[0]?.message.content;
          if (typeof content === "string") {
            const parsed = JSON.parse(content);
            return parsed.medicines || [];
          }
          return [];
        } catch (error) {
          console.error("Error extracting medicines from image:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to extract medicines" });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
