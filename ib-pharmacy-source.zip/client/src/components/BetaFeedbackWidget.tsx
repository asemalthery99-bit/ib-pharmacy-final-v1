import React, { useState } from 'react';
import { MessageSquare, X, Send, Smile, AlertCircle } from 'lucide-react';

interface FeedbackData {
  type: 'bug' | 'suggestion' | 'praise';
  rating: number;
  message: string;
  email?: string;
  page: string;
}

const BetaFeedbackWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [feedbackType, setFeedbackType] = useState<'bug' | 'suggestion' | 'praise'>('suggestion');
  const [rating, setRating] = useState(5);
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const feedbackData: FeedbackData = {
        type: feedbackType,
        rating,
        message,
        email: email || undefined,
        page: window.location.pathname,
      };

      const response = await fetch('/api/beta/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
      });

      if (response.ok) {
        setSubmitSuccess(true);
        setMessage('');
        setEmail('');
        setRating(5);

        setTimeout(() => {
          setSubmitSuccess(false);
          setIsOpen(false);
        }, 2000);
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRatingEmoji = (rate: number) => {
    switch (rate) {
      case 1:
        return '😞';
      case 2:
        return '😕';
      case 3:
        return '😐';
      case 4:
        return '😊';
      case 5:
        return '😍';
      default:
        return '😐';
    }
  };

  return (
    <div className="fixed bottom-24 right-6 z-40">
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 relative"
          aria-label="إرسال ملاحظات"
        >
          <MessageSquare size={24} />
          <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            β
          </span>
        </button>
      )}

      {/* Feedback Widget */}
      {isOpen && (
        <div className="bg-white rounded-lg shadow-2xl w-96 max-h-[500px] flex flex-col animate-in fade-in slide-in-from-bottom-4">
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-4 flex justify-between items-center rounded-t-lg">
            <div>
              <h3 className="font-bold text-lg">ملاحظات النسخة التجريبية</h3>
              <p className="text-sm text-purple-100">ساعدنا في تحسين الموقع</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-purple-700 p-1 rounded transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4">
            <form onSubmit={handleSubmitFeedback} className="space-y-4">
              {submitSuccess && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm flex items-center gap-2">
                  <Smile size={18} />
                  شكراً لملاحظاتك! سنعمل على تحسينها.
                </div>
              )}

              {/* Feedback Type */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  نوع الملاحظة
                </label>
                <div className="space-y-2">
                  {[
                    { value: 'bug', label: 'تبليغ عن خطأ / مشكلة', icon: AlertCircle },
                    { value: 'suggestion', label: 'اقتراح تطويري' },
                    { value: 'praise', label: 'كلمة شكر' },
                  ].map((option) => (
                    <label key={option.value} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="feedbackType"
                        value={option.value}
                        checked={feedbackType === option.value}
                        onChange={(e) => setFeedbackType(e.target.value as any)}
                        className="w-4 h-4 text-purple-500"
                      />
                      <span className="text-gray-700">{option.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Rating */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  التقييم: {getRatingEmoji(rating)}
                </label>
                <div className="flex gap-2 justify-between">
                  {[1, 2, 3, 4, 5].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setRating(rate)}
                      className={`w-10 h-10 rounded-lg font-bold text-lg transition-all ${
                        rating === rate
                          ? 'bg-purple-500 text-white scale-110'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      {rate}
                    </button>
                  ))}
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  الملاحظة
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="اكتب ملاحظتك هنا..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  required
                />
              </div>

              {/* Email (Optional) */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  البريد الإلكتروني (اختياري)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="لنتواصل معك في حال وجود تحديث"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting || !message}
                className="w-full bg-purple-500 hover:bg-purple-600 disabled:bg-gray-400 text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Send size={18} />
                {isSubmitting ? 'جاري الإرسال...' : 'إرسال الملاحظة'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BetaFeedbackWidget;
