import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { toast } from "sonner";

interface RatingComponentProps {
  medicineId: number;
  medicineName: string;
  onRatingAdded?: () => void;
}

export default function RatingComponent({
  medicineId,
  medicineName,
  onRatingAdded,
}: RatingComponentProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch ratings for this medicine
  const { data: medicineRatings = [] } = trpc.ratings.getMedicineRatings.useQuery({
    medicineId,
  });

  // Fetch average rating
  const { data: averageRating = 0 } = trpc.ratings.getAverageRating.useQuery({
    medicineId,
  });

  // Add rating mutation
  const { mutate: addRating } = trpc.ratings.create.useMutation({
    onSuccess: () => {
      toast.success("شكراً على تقييمك!");
      setRating(0);
      setComment("");
      onRatingAdded?.();
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ");
    },
  });

  const handleSubmitRating = () => {
    if (rating === 0) {
      toast.error("يرجى اختيار تقييم");
      return;
    }

    addRating({
      ratingType: "medicine",
      medicineId,
      score: rating,
      comment: comment || undefined,
    });
  };

  return (
    <div className="space-y-6">
      {/* Add Rating Section */}
      <Card className="p-6 bg-emerald-50 border-emerald-200">
        <h3 className="text-lg font-semibold mb-4 text-emerald-900">أضف تقييمك</h3>

        {/* Star Rating */}
        <div className="flex gap-2 mb-4">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoveredRating(star)}
              onMouseLeave={() => setHoveredRating(0)}
              className="transition-transform hover:scale-110"
            >
              <Star
                className={`w-8 h-8 ${
                  star <= (hoveredRating || rating)
                    ? "fill-yellow-400 text-yellow-400"
                    : "text-gray-300"
                }`}
              />
            </button>
          ))}
        </div>

        {/* Comment */}
        <Textarea
          placeholder="شارك رأيك عن هذا الدواء (اختياري)"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="mb-4 resize-none"
          rows={3}
        />

        {/* Submit Button */}
        <Button
          onClick={handleSubmitRating}
          disabled={isSubmitting || rating === 0}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          {isSubmitting ? "جاري الإرسال..." : "إرسال التقييم"}
        </Button>
      </Card>

      {/* Ratings Summary */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">التقييمات ({medicineRatings.length})</h3>
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-4 h-4 ${
                    star <= Math.round(Number(averageRating))
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="font-semibold text-lg">{averageRating}</span>
          </div>
        </div>

        {/* Ratings List */}
        <div className="space-y-3">
          {medicineRatings && medicineRatings.length > 0 ? (
            medicineRatings.map((r: any) => (
              <Card key={r.id} className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= (r.score || r.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">
                    {new Date(r.createdAt).toLocaleDateString("ar-SA")}
                  </span>
                </div>
                {r.comment && (
                  <p className="text-gray-700 text-sm">{r.comment}</p>
                )}
              </Card>
            ))
          ) : (
            <Card className="p-4 text-center text-gray-600">
              <p>لا توجد تقييمات حتى الآن. كن أول من يقيّم!</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
