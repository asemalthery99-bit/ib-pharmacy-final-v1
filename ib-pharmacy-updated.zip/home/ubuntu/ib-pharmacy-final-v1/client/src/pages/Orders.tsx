import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Package, Clock, CheckCircle, Truck } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

const statusConfig: Record<string, { label: string; icon: any; color: string }> = {
  pending: { label: "قيد الانتظار", icon: Clock, color: "text-yellow-600" },
  confirmed: { label: "مؤكد", icon: CheckCircle, color: "text-blue-600" },
  preparing: { label: "جاري التحضير", icon: Package, color: "text-blue-600" },
  ready: { label: "جاهز للتوصيل", icon: Package, color: "text-green-600" },
  shipped: { label: "قيد التوصيل", icon: Truck, color: "text-purple-600" },
  delivered: { label: "تم التسليم", icon: CheckCircle, color: "text-green-600" },
  cancelled: { label: "ملغى", icon: Clock, color: "text-red-600" },
};

export default function Orders() {
  const [, navigate] = useLocation();
  const { data: orders = [] } = trpc.orders.getUserOrders.useQuery();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="container max-w-6xl mx-auto px-4 py-4">
          <h1 className="text-3xl font-bold text-gray-900">طلباتي</h1>
        </div>
      </div>

      <div className="container max-w-6xl mx-auto px-4 py-8">
        {orders.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg mb-4">لا توجد طلبات حتى الآن</p>
              <Button onClick={() => navigate("/catalog")} className="bg-green-600 hover:bg-green-700">
                ابدأ التسوق
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => {
              const statusInfo = statusConfig[order.status as string] || statusConfig.pending;
              const StatusIcon = statusInfo.icon;

              return (
                <Card key={order.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">الطلب #{order.id}</CardTitle>
                        <CardDescription>
                          {format(new Date(order.createdAt), "d MMMM yyyy, HH:mm", { locale: ar })}
                        </CardDescription>
                      </div>
                      <div className={`flex items-center gap-2 ${statusInfo.color}`}>
                        <StatusIcon className="w-5 h-5" />
                        <span className="font-semibold">{statusInfo.label}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-gray-600">الإجمالي</p>
                        <p className="text-lg font-bold text-green-600">
                          {parseFloat(order.totalPrice as any).toFixed(2)} ر.ي
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">الخصم</p>
                        <p className="text-lg font-bold text-blue-600">
                          {parseFloat((order.discountAmount as any) || "0").toFixed(2)} ر.ي
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">حالة الدفع</p>
                        <p className="text-lg font-semibold">
                          {order.paymentStatus === "paid" ? "✓ مدفوع" : "قيد الانتظار"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">عدد العناصر</p>
                        <p className="text-lg font-semibold">-</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => navigate(`/orders/${order.id}`)}
                      >
                        عرض التفاصيل
                      </Button>
                      {order.status === "delivered" && (
                        <Button
                          variant="outline"
                          onClick={() => navigate(`/orders/${order.id}/rate`)}
                        >
                          تقييم الطلب
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
