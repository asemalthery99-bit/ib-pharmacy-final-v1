import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { createPayPalOrder, capturePayPalPayment, getPayPalOrderDetails } from "../services/paypal";
import { notifyPaymentSuccess, notifyPaymentFailure } from "../services/notifications";
import * as db from "../db";

export const paymentsRouter = router({
  /**
   * Create PayPal order
   */
  createPayPalOrder: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      amount: z.string(),
      currency: z.string().default("USD"),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // Verify order belongs to user
        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found or unauthorized");
        }

        // Create PayPal order
        const paypalOrderId = await createPayPalOrder(
          input.orderId,
          input.amount,
          input.currency,
          ctx.user?.email || undefined,
          ctx.user?.name || undefined
        );

        // Store PayPal order ID
        await db.updateOrderPaymentStatus(input.orderId, "pending", paypalOrderId);

        return {
          success: true,
          paypalOrderId,
          approvalUrl: `https://www.${process.env.NODE_ENV === "production" ? "" : "sandbox."}paypal.com/checkoutnow?token=${paypalOrderId}`,
        };
      } catch (error) {
        console.error("[Payments] Error creating PayPal order:", error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Capture PayPal payment
   */
  capturePayPalPayment: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      paypalOrderId: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // Verify order belongs to user
        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found or unauthorized");
        }

        // Capture payment
        const paymentDetails = await capturePayPalPayment(input.paypalOrderId);

        if (paymentDetails.status === "COMPLETED") {
          // Update order status
          await db.updateOrderStatus(input.orderId, "preparing", "paid");

          // Send success notification
          try {
            await notifyPaymentSuccess(
              input.orderId,
              paymentDetails.purchase_units[0].amount.value,
              "PayPal"
            );
          } catch (notifyError) {
            console.error("[Payments] Error sending notification:", notifyError);
          }

          return {
            success: true,
            message: "تم استقبال الدفعة بنجاح",
            orderStatus: "preparing",
          };
        } else {
          throw new Error(`Payment status: ${paymentDetails.status}`);
        }
      } catch (error) {
        console.error("[Payments] Error capturing payment:", error);

        // Send failure notification
        try {
          await notifyPaymentFailure(input.orderId, String(error));
        } catch (notifyError) {
          console.error("[Payments] Error sending failure notification:", notifyError);
        }

        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Get PayPal order details
   */
  getPayPalOrderDetails: protectedProcedure
    .input(z.object({
      paypalOrderId: z.string(),
    }))
    .query(async ({ input }) => {
      try {
        const details = await getPayPalOrderDetails(input.paypalOrderId);
        return {
          success: true,
          details,
        };
      } catch (error) {
        console.error("[Payments] Error getting order details:", error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * Get order payment status
   */
  getOrderPaymentStatus: protectedProcedure
    .input(z.object({
      orderId: z.number(),
    }))
    .query(async ({ input, ctx }) => {
      try {
        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found or unauthorized");
        }

        return {
          success: true,
          orderId: order.id,
          paymentStatus: order.paymentStatus,
          orderStatus: order.status,
          totalPrice: order.totalPrice,
        };
      } catch (error) {
        console.error("[Payments] Error getting payment status:", error);
        return {
          success: false,
          error: String(error),
        };
      }
    }),

  /**
   * List user payments
   */
  listUserPayments: protectedProcedure.query(async ({ ctx }) => {
    try {
      const orders = await db.getUserOrders(ctx.user.id);
      const payments = orders
        .filter(order => order.paymentStatus === "paid")
        .map(order => ({
          orderId: order.id,
          amount: order.totalPrice,
          status: order.paymentStatus,
          date: order.createdAt,
          orderStatus: order.status,
        }));

      return {
        success: true,
        payments,
        total: payments.length,
      };
    } catch (error) {
      console.error("[Payments] Error listing payments:", error);
      return {
        success: false,
        error: String(error),
      };
    }
  }),
});
