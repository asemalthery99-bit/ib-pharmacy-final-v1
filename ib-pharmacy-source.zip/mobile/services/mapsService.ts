import * as Location from 'expo-location';
import { Platform } from 'react-native';

/**
 * Google Maps Integration Service
 * Handles geocoding, reverse geocoding, and location tracking
 */

export interface LocationCoords {
  latitude: number;
  longitude: number;
}

export interface LocationAddress {
  street: string;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  formattedAddress: string;
}

export interface DistanceMatrix {
  distance: number; // in km
  duration: number; // in minutes
  polyline: string;
}

/**
 * Get current user location
 */
export async function getCurrentLocation(): Promise<LocationCoords | null> {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    
    if (status !== 'granted') {
      console.error('Location permission denied');
      return null;
    }

    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
    });

    return {
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
    };
  } catch (error) {
    console.error('Error getting location:', error);
    return null;
  }
}

/**
 * Watch user location in real-time
 */
export function watchUserLocation(
  callback: (location: LocationCoords) => void,
  errorCallback?: (error: Error) => void
) {
  return Location.watchPositionAsync(
    {
      accuracy: Location.Accuracy.High,
      timeInterval: 5000, // Update every 5 seconds
      distanceInterval: 10, // Or when moved 10 meters
    },
    (location) => {
      callback({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });
    }
  ).catch((error) => {
    if (errorCallback) errorCallback(error);
  });
}

/**
 * Reverse geocode: Get address from coordinates
 */
export async function reverseGeocode(
  coords: LocationCoords
): Promise<LocationAddress | null> {
  try {
    const results = await Location.reverseGeocodeAsync(coords);

    if (results.length === 0) {
      return null;
    }

    const address = results[0];

    return {
      street: `${address.street || ''} ${address.name || ''}`.trim(),
      city: address.city || '',
      region: address.region || '',
      postalCode: address.postalCode || '',
      country: address.country || '',
      formattedAddress: `${address.street || ''}, ${address.city || ''}, ${address.country || ''}`,
    };
  } catch (error) {
    console.error('Error reverse geocoding:', error);
    return null;
  }
}

/**
 * Geocode: Get coordinates from address
 */
export async function geocode(address: string): Promise<LocationCoords | null> {
  try {
    const results = await Location.geocodeAsync(address);

    if (results.length === 0) {
      return null;
    }

    const result = results[0];

    return {
      latitude: result.latitude,
      longitude: result.longitude,
    };
  } catch (error) {
    console.error('Error geocoding:', error);
    return null;
  }
}

/**
 * Calculate distance between two coordinates
 */
export function calculateDistance(
  from: LocationCoords,
  to: LocationCoords
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((to.latitude - from.latitude) * Math.PI) / 180;
  const dLng = ((to.longitude - from.longitude) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((from.latitude * Math.PI) / 180) *
      Math.cos((to.latitude * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
}

/**
 * Estimate delivery time based on distance
 */
export function estimateDeliveryTime(distanceKm: number): number {
  // Assume average speed of 30 km/h in city
  const timeMinutes = Math.round((distanceKm / 30) * 60);
  return Math.max(timeMinutes, 15); // Minimum 15 minutes
}

/**
 * Generate map URL for opening in maps app
 */
export function generateMapUrl(
  coords: LocationCoords,
  label: string = 'Location'): string {
  const { latitude, longitude } = coords;

  if (Platform.OS === 'ios') {
    return `maps://maps.apple.com/?q=${label}&ll=${latitude},${longitude}&z=16`;
  } else {
    return `geo:${latitude},${longitude}?q=${label}`;
  }
}

/**
 * Generate directions URL
 */
export function generateDirectionsUrl(
  from: LocationCoords,
  to: LocationCoords,
  mode: 'driving' | 'walking' | 'transit' = 'driving'): string {
  if (Platform.OS === 'ios') {
    return `maps://maps.apple.com/?saddr=${from.latitude},${from.longitude}&daddr=${to.latitude},${to.longitude}&dirflg=${mode === 'driving' ? 'd' : mode === 'walking' ? 'w' : 'r'}`;
  } else {
    return `google.navigation:q=${to.latitude},${to.longitude}`;
  }
}

/**
 * Get nearby pharmacies (mock implementation)
 * In production, this would call a real API
 */
export async function getNearbyPharmacies(
  userLocation: LocationCoords,
  radiusKm: number = 5
): Promise<
  Array<{
    id: string;
    name: string;
    location: LocationCoords;
    distance: number;
    address: string;
    rating: number;
  }>
> {
  // Mock data - replace with real API call
  const mockPharmacies = [
    {
      id: 'PHARM-001',
      name: 'صيدلية إب الرقمية - الفرع الرئيسي',
      location: { latitude: 15.3694, longitude: 44.2039 },
      distance: 2.5,
      address: 'شارع الثورة، إب',
      rating: 4.9,
    },
    {
      id: 'PHARM-002',
      name: 'صيدلية إب الرقمية - فرع الشرقية',
      location: { latitude: 15.3750, longitude: 44.2100 },
      distance: 3.2,
      address: 'شارع السلام، إب',
      rating: 4.7,
    },
  ];

  // Filter by radius
  return mockPharmacies.filter((pharmacy) => {
    const distance = calculateDistance(userLocation, pharmacy.location);
    return distance <= radiusKm;
  });
}

/**
 * Track delivery in real-time
 */
export async function trackDeliveryLocation(
  deliveryId: string,
  callback: (location: LocationCoords) => void
) {
  // Mock implementation - in production, this would connect to a real-time service
  const mockLocation = {
    latitude: 15.3720,
    longitude: 44.2070,
  };

  callback(mockLocation);

  // Simulate location updates
  const interval = setInterval(() => {
    const newLat = mockLocation.latitude + (Math.random() - 0.5) * 0.01;
    const newLng = mockLocation.longitude + (Math.random() - 0.5) * 0.01;

    callback({
      latitude: newLat,
      longitude: newLng,
    });
  }, 5000);

  return () => clearInterval(interval);
}

/**
 * Get route between two points
 */
export async function getRoute(
  from: LocationCoords,
  to: LocationCoords
): Promise<DistanceMatrix | null> {
  try {
    // Mock implementation
    const distance = calculateDistance(from, to);
    const duration = estimateDeliveryTime(distance);

    return {
      distance,
      duration,
      polyline: '', // Would contain actual polyline from Google Maps API
    };
  } catch (error) {
    console.error('Error getting route:', error);
    return null;
  }
}
