import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, foreignKey } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Medicines table - stores all medicines/products in the pharmacy
 */
export const medicines = mysqlTable("medicines", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  arabicName: varchar("arabicName", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  description: text("description"),
  arabicDescription: text("arabicDescription"),
  dosage: varchar("dosage", { length: 255 }),
  sideEffects: text("sideEffects"),
  arabicSideEffects: text("arabicSideEffects"),
  usage: text("usage"),
  arabicUsage: text("arabicUsage"),
  imageUrl: varchar("imageUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Medicine = typeof medicines.$inferSelect;
export type InsertMedicine = typeof medicines.$inferInsert;

/**
 * Inventory table - tracks stock levels for each medicine
 */
export const inventory = mysqlTable("inventory", {
  id: int("id").autoincrement().primaryKey(),
  medicineId: int("medicineId").notNull(),
  quantity: int("quantity").notNull().default(0),
  minThreshold: int("minThreshold").notNull().default(10),
  maxThreshold: int("maxThreshold").notNull().default(1000),
  lastRestocked: timestamp("lastRestocked"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = typeof inventory.$inferInsert;

/**
 * Orders table - stores customer orders
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "preparing", "ready", "completed", "cancelled"]).default("pending").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["unpaid", "paid", "failed"]).default("unpaid").notNull(),
  stripePaymentId: varchar("stripePaymentId", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * OrderItems table - stores individual items in an order
 */
export const orderItems = mysqlTable("orderItems", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  medicineId: int("medicineId").notNull(),
  quantity: int("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;

/**
 * Prescriptions table - stores uploaded prescriptions
 */
export const prescriptions = mysqlTable("prescriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["pending", "reviewed", "quoted", "completed", "rejected"]).default("pending").notNull(),
  userNotes: text("userNotes"),
  pharmacistNotes: text("pharmacistNotes"),
  quotedPrice: decimal("quotedPrice", { precision: 10, scale: 2 }),
  quotedMedicines: text("quotedMedicines"), // JSON array stored as text
  extractedMedicines: text("extractedMedicines"), // JSON array from LLM
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Prescription = typeof prescriptions.$inferSelect;
export type InsertPrescription = typeof prescriptions.$inferInsert;

/**
 * PrescriptionImages table - stores images for prescriptions in S3
 */
export const prescriptionImages = mysqlTable("prescriptionImages", {
  id: int("id").autoincrement().primaryKey(),
  prescriptionId: int("prescriptionId").notNull(),
  imageUrl: varchar("imageUrl", { length: 500 }).notNull(),
  s3Key: varchar("s3Key", { length: 500 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PrescriptionImage = typeof prescriptionImages.$inferSelect;
export type InsertPrescriptionImage = typeof prescriptionImages.$inferInsert;

/**
 * Cart table - stores shopping cart items per user
 */
export const carts = mysqlTable("carts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  medicineId: int("medicineId").notNull(),
  quantity: int("quantity").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Cart = typeof carts.$inferSelect;
export type InsertCart = typeof carts.$inferInsert;

/**
 * Update users table to support pharmacist role
 */
export const usersRelations = relations(users, ({ many }) => ({
  orders: many(orders),
  prescriptions: many(prescriptions),
  cartItems: many(carts),
}));

export const medicinesRelations = relations(medicines, ({ one, many }) => ({
  inventory: one(inventory),
  orderItems: many(orderItems),
  cartItems: many(carts),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(users),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders),
  medicine: one(medicines),
}));

export const prescriptionsRelations = relations(prescriptions, ({ one, many }) => ({
  user: one(users),
  images: many(prescriptionImages),
}));

export const prescriptionImagesRelations = relations(prescriptionImages, ({ one }) => ({
  prescription: one(prescriptions),
}));

export const cartsRelations = relations(carts, ({ one }) => ({
  user: one(users),
  medicine: one(medicines),
}));